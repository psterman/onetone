const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
  '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

async function probe() {
  const url = 'https://api.tvmaze.com/schedule?country=US&date=2026-11-16';
  const r = await fetch(url, { headers: { 'User-Agent': UA } });
  console.log('TVMAZE status', r.status);
  const j = await r.json();
  console.log('TVMAZE len', Array.isArray(j) ? j.length : 'not array');
  if (Array.isArray(j) && j[0]) console.log('TVMAZE item0', JSON.stringify(j[0], null, 1));

  for (const c of ['CN', 'JP', 'KR', 'HK']) {
    const rr = await fetch(`https://api.tvmaze.com/schedule?country=${c}&date=2026-11-16`, {
      headers: { 'User-Agent': UA },
    });
    const jj = await rr.json();
    console.log('TVMAZE', c, rr.status, Array.isArray(jj) ? jj.length : 'n/a');
  }
}

probe().catch((e) => console.error('ERR', e && e.message));
