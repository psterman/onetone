﻿import https from 'node:https';
function get(url, headers={}) {
  return new Promise((res)=>{
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)','Accept':'*/*'},headers)},r=>{
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(20000,()=>{req.destroy();res({s:0,body:'TIMEOUT'})});
  });
}
const urls=[
  ['tvmaze-updates-day','https://api.tvmaze.com/updates/shows?since=day'],
  ['tvmaze-updates-week','https://api.tvmaze.com/updates/shows?since=week'],
  ['tvmaze-schedule-full','https://api.tvmaze.com/schedule/full'],
  ['tvmaze-shows-webchannel','https://api.tvmaze.com/shows?page=0'],
  ['justwatch-graphql','https://apis.justwatch.com/graphql'],
  ['netflix-tudum-v2','https://www.netflix.com/tudum/top10/data/tudum-top10-global-tv?week=2026-11-09'],
  ['netflix-shakti','https://www.netflix.com/api/shakti/'],
  ['mydramalist','https://mydramalist.com/'],
];
for(const [n,u] of urls){
  const r=await get(u);
  console.log('['+n+'] status='+r.s+' len='+(r.body||'').length+' head='+(r.body||'').slice(0,150).replace(/\s+/g,' '));
}
