const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
const r = await fetch("https://movie.douban.com/top250", { headers: { "User-Agent": UA, Referer: "https://movie.douban.com/" } });
const t = await r.text();
console.log("status", r.status, "len", t.length);
const i = t.indexOf("rating_num");
console.log("--- around rating_num ---");
console.log(JSON.stringify(t.slice(i - 1600, i + 1000)));