﻿import https from 'node:https';
function post(q,v){
  return new Promise((res)=>{
    const body=JSON.stringify({query:q,variables:v});
    const r=https.request('https://apis.justwatch.com/graphql',{method:'POST',headers:{'Content-Type':'application/json','X-Client-Id':'justwatch','Origin':'https://www.justwatch.com','Referer':'https://www.justwatch.com/','User-Agent':'Mozilla/5.0','Content-Length':Buffer.byteLength(body)}},(resp)=>{
      let d='';resp.on('data',c=>d+=c);resp.on('end',()=>res({s:resp.statusCode,body:d}));
    });
    r.on('error',e=>res({s:0,body:'ERR '+e.message}));
    r.setTimeout(25000,()=>{r.destroy();res({s:0,body:'TIMEOUT'})});
    r.write(body); r.end();
  });
}
const JH={'Content-Type':'application/json','X-Client-Id':'justwatch','Origin':'https://www.justwatch.com','Referer':'https://www.justwatch.com/'};
async function p(label,q,v){ const r=await post(q,v); console.log('['+label+'] status='+r.s); console.log('   '+r.body.slice(0,700).replace(/\s+/g,' ')+'\n'); }
await p('newTitles 参数反推','query($c:Country!){ newTitles(first:1,country:$c,zzz:1){ edges { node { id } } } }',{c:'HK'});
await p('searchTitles 字段','query($c:Country!){ searchTitles(first:2,country:$c,expression:"cantonese"){ edges { node { id objectType } } } }',{c:'HK'});
await p('title 单查','query{ title(id:"tss461316"){ id } }',{});
console.log('=== content API（JustWatch 自有 id） ===');
import('node:https').then(async ({default:https2})=>{
  const get=(url,h={})=>new Promise(res=>{const q=https2.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0','Accept':'application/json'},h)},r=>{let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d}));});q.on('error',e=>res({s:0,body:'ERR '+e.message}));q.setTimeout(20000,()=>{q.destroy();res({s:0,body:'TIMEOUT'})});});
  for(const u of [
    'https://apis.justwatch.com/content/titles/tss461316?country=HK&language=ZH',
    'https://apis.justwatch.com/content/titles/tss461316?country=HK&language=ZH&IncludeTrailers=false',
  ]){
    const r=await get(u,{'X-Client-Id':'justwatch','Origin':'https://www.justwatch.com','Referer':'https://www.justwatch.com/'});
    console.log('  status='+r.s+' len='+r.body.length+' ct='+(r.ct||'').slice(0,30));
    if(r.s===200){ try{ const j=JSON.parse(r.body); console.log('   keys='+Object.keys(j).join(','));
      console.log('   title='+JSON.stringify(j.title||j.titleText||null).slice(0,200));
      console.log('   poster='+JSON.stringify(j.poster||j.image||j.images||null).slice(0,250));
      console.log('   release='+JSON.stringify(j.releaseDate||j.releaseYear||null));
    }catch(e){ console.log('   '+r.body.slice(0,200)); } }
    else console.log('   '+r.body.slice(0,200));
  }
});
