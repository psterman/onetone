﻿import https from 'node:https';
function get(url, headers={}) {
  return new Promise((res)=>{
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)','Accept':'text/html,*/*'},headers)},r=>{
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(20000,()=>{req.destroy();res({s:0,body:'TIMEOUT'})});
  });
}
console.log('=== A. 豆瓣同城条目结构（找区/场馆/分类字段） ===');
const r=await get('https://beijing.douban.com/events/week-all',{Referer:'https://www.douban.com/location/beijing/'});
console.log('status='+r.s+' len='+r.body.length);
const it=r.body.match(/<li[^>]*>[\s\S]{0,2200}?<\/li>/g)||[];
console.log('  li 数='+it.length);
const withSummary=it.filter(x=>/itemprop="summary"/.test(x));
console.log('  含 summary 的 li='+withSummary.length);
if(withSummary[0]){
  console.log('  首条:\n'+withSummary[0].replace(/\n\s*\n/g,'\n').slice(0,1600));
}
console.log('\n=== B. 页面里的分类/类型入口 ===');
const cats=[...new Set((r.body.match(/href="([^"]*events[^"]*)"[^>]*>\s*([^<]{1,20})/g)||[]).map(x=>x.replace(/\s+/g,' ')))];
console.log('  '+JSON.stringify(cats.slice(0,25),null,0));
console.log('\n=== C. 页面上的「类型」词（演出/展览/电影/音乐…） ===');
const types=[...new Set((r.body.match(/>([^<>]{2,6})<\/a>/g)||[]).map(x=>x.replace(/[><]/g,'')))];
console.log('  '+JSON.stringify(types.filter(t=>/演出|展览|电影|音乐|戏剧|讲座|活动|亲子|体育|旅行/.test(t)).slice(0,25)));
console.log('\n=== D. TVB 节目表背后的 API ===');
const t=await get('https://programme.tvb.com/');
console.log('  status='+t.s+' len='+t.body.length);
console.log('  '+t.body.replace(/\s+/g,' ').slice(0,900));
