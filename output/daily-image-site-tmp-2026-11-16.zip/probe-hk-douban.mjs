﻿import https from 'node:https';
function get(url, headers={}) {
  return new Promise((res)=>{
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)','Accept':'*/*'},headers)},r=>{
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(20000,()=>{req.destroy();res({s:0,body:'TIMEOUT'})});
  });
}
console.log('=== TVmaze 香港/台湾频道（schedule country=HK） ===');
for(const cc of ['HK','TW','CN']){
  const r=await get('https://api.tvmaze.com/schedule?country='+cc+'&date=2026-11-17');
  if(r.s!==200){ console.log('  '+cc+' status='+r.s); continue; }
  try{
    const j=JSON.parse(r.body);
    const nets={};
    for(const e of j){ const n=e.show.network; const k=n?n.name:'('+(e.show.webChannel?e.show.webChannel.name:'none')+')'; nets[k]=(nets[k]||0)+1; }
    console.log('  '+cc+' 条数='+j.length+' 网络分布: '+Object.entries(nets).map(([k,v])=>k+'×'+v).join(', '));
    const langs={}; for(const e of j){ langs[e.show.language]=(langs[e.show.language]||0)+1; }
    console.log('     语言: '+Object.entries(langs).map(([k,v])=>k+'×'+v).join(', '));
  }catch(e){ console.log('  '+cc+' parse fail status='+r.s+' '+r.body.slice(0,120)); }
}
console.log('\n=== 豆瓣同城：城市页有没有区级子标签 ===');
for(const u of ['https://www.douban.com/event/list/?city=%E5%8C%97%E4%BA%AC','https://www.douban.com/event/list/?city=%E6%AD%A6%E6%B1%89']){
  const r=await get(u,{'Referer':'https://www.douban.com/event/'});
  if(r.s!==200){ console.log('  status='+r.s+' '+u); continue; }
  const m=r.body.match(/class="sub[^"]*"[^>]*>([^<]{1,12})</g)||[];
  const m2=r.body.match(/href="[^"]*city=[^"]*"[^>]*>([^<]{1,20})</g)||[];
  console.log('  '+u.split('?')[1]+' status='+r.s+' len='+r.body.length);
  console.log('     sub类片段: '+JSON.stringify(m.slice(0,12)));
  console.log('     city链接: '+JSON.stringify(m2.slice(0,15)));
}
