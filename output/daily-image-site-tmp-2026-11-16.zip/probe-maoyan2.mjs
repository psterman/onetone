﻿import https from 'node:https';
function get(url, headers={}) {
  return new Promise((res)=>{
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','Accept':'*/*','Accept-Language':'zh-CN,zh;q=0.9'},headers)},r=>{
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(25000,()=>{try{req.destroy();}catch(e){} res({s:0,body:'TIMEOUT'})});
  });
}
console.log('=== A. 猫眼 hot 数组里有没有「即将上映/预售」 ===');
let r=await get('https://api.maoyan.com/mmdb/movie/v5/list/hot.json?ci=1',{Referer:'https://www.maoyan.com/'});
const j=JSON.parse(r.body); const hot=j.data.hot||[];
console.log('  hot 条数='+hot.length+'  total='+j.data.total);
for(const h of hot){
  console.log('   rt='+String(h.rt).padEnd(11)+' nm='+String(h.nm).slice(0,16).padEnd(18)+' sc='+String(h.sc).padEnd(5)+' wish='+String(h.wish).padEnd(8)+' preShow='+h.preShow+' preSale='+h.preSale+' globalReleased='+h.globalReleased+' comingTitle='+(h.comingTitle||'-')+' showInfo='+(h.showInfo||'-'));
}
console.log('\n=== B. 猫眼「即将上映」其他接口 ===');
for(const u of [
  'https://api.maoyan.com/mmdb/movie/v5/list/coming.json?ci=1',
  'https://api.maoyan.com/mmdb/movie/v5/list/hot.json?ci=1&showType=2',
  'https://api.maoyan.com/mmdb/movie/v5/list/hot.json?ci=1&limit=30',
  'https://api.maoyan.com/mmdb/movie/v5/list/coming-soon.json?ci=1',
  'https://api.maoyan.com/mmdb/movie/v5/list/comingsoon.json?ci=1',
  'https://api.maoyan.com/mmdb/movie/v5/list/hot.json?ci=1&area=1',
]){
  const rr=await get(u,{Referer:'https://www.maoyan.com/'});
  let o='status='+rr.s+' len='+rr.body.length;
  try{ const k=JSON.parse(rr.body); o+=' hot='+((k.data&&k.data.hot||[]).length)+' coming='+((k.data&&k.data.coming||[]).length)+' total='+(k.data&&k.data.total); }catch(e){ o+=' '+rr.body.slice(0,80); }
  console.log('  '+u.replace('https://api.maoyan.com/mmdb/movie/v5/list/','')+' -> '+o);
}
console.log('\n=== C. 猫眼预告片接口 ===');
for(const u of ['https://api.maoyan.com/mmdb/movie/v5/list/coming.json?ci=1&token=','https://www.maoyan.com/ajax/coming?ci=1']){
  const rr=await get(u,{Referer:'https://www.maoyan.com/'});
  console.log('  '+u.slice(30,90)+' -> status='+rr.s+' len='+rr.body.length+' '+rr.body.slice(0,120).replace(/\s+/g,' '));
}
