/* 临时探针 2：扫宽国家列表，找 Netflix / HBO Max 这类流媒体频道到底在哪些国家出现 */
const DAY = '2026-11-17';
const COUNTRIES = [
  'US', 'GB', 'CA', 'AU', 'NZ', 'IE', 'DE', 'FR', 'IT', 'ES', 'PT', 'NL', 'BE', 'CH', 'AT',
  'SE', 'NO', 'DK', 'FI', 'PL', 'CZ', 'HU', 'RO', 'GR', 'TR', 'RU', 'UA', 'IN', 'PK', 'BD',
  'CN', 'HK', 'TW', 'JP', 'KR', 'SG', 'MY', 'TH', 'VN', 'ID', 'PH', 'BR', 'MX', 'AR', 'CL',
  'CO', 'PE', 'ZA', 'NG', 'KE', 'EG', 'SA', 'AE', 'IL',
];

async function main() {
  const web = new Map();
  const net = new Map();
  let total = 0;
  for (const c of COUNTRIES) {
    let j = [];
    try {
      j = await fetch(`https://api.tvmaze.com/schedule?country=${c}&date=${DAY}`).then((r) => r.json());
    } catch (e) {
      console.log(`${c} ERR ${e.message}`);
      continue;
    }
    if (!Array.isArray(j)) { console.log(`${c} 非数组: ${JSON.stringify(j).slice(0, 120)}`); continue; }
    total += j.length;
    let w = 0;
    for (const e of j) {
      const s = e.show || {};
      if (s.webChannel && s.webChannel.name) {
        web.set(s.webChannel.name, (web.get(s.webChannel.name) || 0) + 1);
        w++;
      } else if (s.network && s.network.name) {
        net.set(s.network.name, (net.get(s.network.name) || 0) + 1);
      }
    }
    if (w > 0) console.log(`${c} 共 ${j.length} 条，其中 webChannel ${w} 条`);
  }
  console.log(`\n合计 ${total} 条 · webChannel 种类 ${web.size}`);
  console.log('webChannel 分布: ' + [...web.entries()].sort((a, b) => b[1] - a[1])
    .map(([k, v]) => `${k}=${v}`).join(' | '));
  console.log('network 种类: ' + net.size);

  /* 试 /schedule/full：条目更细，看 webChannel 是否更全 */
  try {
    const j = await fetch(`https://api.tvmaze.com/schedule/full?country=US&date=${DAY}`).then((r) => r.json());
    console.log(`\n/schedule/full?country=US → ${Array.isArray(j) ? j.length : '非数组'} 条`);
  } catch (e) { console.log('full ERR ' + e.message); }
}

main().catch((e) => { console.error(e); process.exit(1); });
