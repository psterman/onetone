﻿import https from 'node:https';
function get(url, headers={}) {
  return new Promise((res)=>{
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)','Accept':'*/*'},headers)},r=>{
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(20000,()=>{req.destroy();res({s:0,body:'TIMEOUT'})});
  });
}
const urls=[
  ['baseline-schedule','https://api.tvmaze.com/schedule?country=US&date=2026-11-16'],
  ['shows/1','https://api.tvmaze.com/shows/1'],
  ['networks/1','https://api.tvmaze.com/networks/1'],
  ['search-netflix','https://api.tvmaze.com/search/shows?q=netflix'],
  ['shows-list','https://api.tvmaze.com/shows?page=0'],
  ['schedule-web-54','https://api.tvmaze.com/schedule/web/54?date=2026-11-16'],
];
for(const [n,u] of urls){
  const r=await get(u);
  console.log('['+n+'] status='+r.s+' len='+(r.body||'').length+' head='+(r.body||'').slice(0,200).replace(/\s+/g,' '));
}
// 剖析 schedule 里 show 的字段，看有没有 webChannel
const r=await get('https://api.tvmaze.com/schedule?country=US&date=2026-11-16');
try{
  const j=JSON.parse(r.body);
  console.log('\nschedule entries='+j.length);
  if(j.length){
    console.log('episode keys: '+Object.keys(j[0]).join(','));
    console.log('show keys: '+Object.keys(j[0].show).join(','));
    console.log('show.webChannel: '+JSON.stringify(j[0].show.webChannel));
    console.log('show.network: '+JSON.stringify(j[0].show.network));
  }
}catch(e){ console.log('parse fail '+e.message); }
