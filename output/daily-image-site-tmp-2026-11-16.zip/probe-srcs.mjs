﻿import https from 'node:https';
function get(url, headers={}) {
  return new Promise((res)=>{
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)','Accept':'text/html,application/json,*/*'},headers)},r=>{
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(20000,()=>{req.destroy();res({s:0,body:'TIMEOUT'})});
  });
}
console.log('=== A. 豆瓣「港剧」标签（中文源，直给封面） ===');
for(const tag of ['港剧','TVB','香港']){
  const u='https://movie.douban.com/j/search_subjects?type=tv&tag='+encodeURIComponent(tag)+'&page_limit=20&page_start=0&sort=time';
  const r=await get(u,{Referer:'https://movie.douban.com/'});
  if(r.s!==200){ console.log('  tag='+tag+' status='+r.s); continue; }
  try{ const j=JSON.parse(r.body); const subs=j.subjects||[];
    console.log('  tag='+tag+' 条数='+subs.length+' total='+j.total);
    subs.slice(0,5).forEach(s=>console.log('     '+s.title+' | '+(s.rate||'-')+' | '+(s.url||'').slice(0,42)+' | cover='+(s.cover||'').slice(0,60)));
  }catch(e){ console.log('  tag='+tag+' parse fail status='+r.s+' '+r.body.slice(0,100)); }
}
console.log('\n=== B. B站番剧：按「最新更新」而非时间线 ===');
for(const u of [
  'https://api.bilibili.com/pgc/web/timeline?types=1&day=3',
  'https://api.bilibili.com/pgc/web/timeline?types=1&day=1',
]){
  const r=await get(u,{Referer:'https://www.bilibili.com/'});
  try{ const j=JSON.parse(r.body); const res=j.result||[];
    let eps=0; for(const d of res) eps+=(d.episodes||[]).length;
    console.log('  '+u.split('?')[1]+' code='+j.code+' 天数='+res.length+' 总集数='+eps);
    const f=res[0]&&res[0].episodes&&res[0].episodes[0];
    if(f) console.log('     首集: '+JSON.stringify({title:f.title||(f.ep&&f.ep.title),pub_index:f.pub_index,pub_time:f.pub_time,cover:(f.cover||f.ep_cover||'').slice(0,60),square:f.square||f.cover||''}).slice(0,320));
  }catch(e){ console.log('  '+u+' status='+r.s+' '+r.body.slice(0,120)); }
}
console.log('\n=== C. 豆瓣同城：某城市的区级链接是否解析得到（武汉） ===');
const w=await get('https://wuhan.douban.com/events/week-all',{Referer:'https://www.douban.com/location/wuhan/'});
const ds=[...new Set((w.body.match(/href="(https:\/\/wuhan\.douban\.com\/events\/week-all-\d+)"[^>]*>\s*([^<]{1,12})/g)||[]))];
console.log('  status='+w.s+' 区级链接('+ds.length+'): '+JSON.stringify(ds.slice(0,30)));
