const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
const cases = [
  ["netease http", "http://p1.music.126.net/Enhy6dPn4gpyqrKhVEQvgA==/109951170483249998.jpg"],
  ["netease https", "https://p1.music.126.net/Enhy6dPn4gpyqrKhVEQvgA==/109951170483249998.jpg"],
  ["bili http", "http://i1.hdslb.com/bfs/archive/5a202db2daa18fc4ffbdef57b233b587dad063e7.jpg"],
  ["bili https", "https://i1.hdslb.com/bfs/archive/5a202db2daa18fc4ffbdef57b233b587dad063e7.jpg"],
];
for (const [label, u] of cases) {
  for (const [refLabel, extra] of [["3rd-party-ref", { Referer: "https://example.com/" }], ["no-ref", {}]]) {
    try {
      const r = await fetch(u, { headers: { "User-Agent": UA, Accept: "image/*,*/*;q=0.8", ...extra } });
      console.log(label.padEnd(15), refLabel.padEnd(15), "->", r.status, r.headers.get("content-type"));
    } catch (e) { console.log(label.padEnd(15), refLabel.padEnd(15), "-> ERR", e.message); }
  }
}