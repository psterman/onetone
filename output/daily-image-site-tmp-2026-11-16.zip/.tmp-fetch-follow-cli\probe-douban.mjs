/** 临时探针：看豆瓣同城城市页的真实结构（类型分类锚点 + 条目上下文） */
import https from 'node:https';

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
  '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

function once(u, depth = 0) {
  return new Promise((resolve) => {
    const req = https.get(
      u,
      { headers: { 'User-Agent': UA, Accept: '*/*', 'Accept-Language': 'zh-CN,zh;q=0.9' } },
      (res) => {
        if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && depth < 6) {
          res.resume();
          once(new URL(res.headers.location, u).href, depth + 1).then(resolve);
          return;
        }
        let text = '';
        res.setEncoding('utf8');
        res.on('data', (c) => { text += c; });
        res.on('end', () => resolve({ status: res.statusCode, text, url: u }));
      },
    );
    req.on('error', (e) => resolve({ status: 0, text: '', url: u, error: e.message }));
    req.setTimeout(30000, () => { try { req.destroy(); } catch { /* ignore */ } });
  });
}

const url = process.argv[2] || 'https://www.douban.com/location/beijing/events';
const r = await once(url);
console.log('status', r.status, 'url', r.url, 'len', r.text.length);
const html = r.text;

console.log('\n=== 类型锚点 (week-xxx) ===');
for (const m of html.matchAll(/href="([^"]*\/events\/week-([a-z]+))"[^>]*>\s*([^<]{1,80})</g)) {
  console.log(' ', m[2], '=>', JSON.stringify(m[3]));
}

console.log('\n=== 区级锚点 ===');
let n = 0;
for (const m of html.matchAll(/href="([^"]*\/events\/week-all-(\d+))"[^>]*>\s*([^<]{1,80})</g)) {
  if (n++ < 8) console.log(' ', m[2], '=>', JSON.stringify(m[3]));
}
console.log('  区总数 =', (html.match(/\/events\/week-all-\d+/g) || []).length);

console.log('\n=== list-entry 数量 ===');
console.log(' ', (html.split('<li class="list-entry"').length - 1));

console.log('\n=== 第一个条目前后 1500 字符 ===');
const i = html.indexOf('<li class="list-entry"');
console.log(html.slice(Math.max(0, i - 1500), i + 1500));

console.log('\n=== h2/h3 标题 ===');
for (const m of html.matchAll(/<h[234][^>]*>([\s\S]{0,120}?)<\/h[234]>/g)) {
  console.log(' ', JSON.stringify(m[1].replace(/\s+/g, ' ').trim()));
}
