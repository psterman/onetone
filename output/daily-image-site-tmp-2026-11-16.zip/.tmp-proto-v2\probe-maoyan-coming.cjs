/* 临时探针 13：猫眼 movieOnInfoList 顶层的 coming / total 字段是什么 */
const https = require('node:https');
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

function get(url) {
  return new Promise((resolve) => {
    const req = https.get(url, { headers: { 'User-Agent': UA, Referer: 'https://m.maoyan.com/', Accept: '*/*' } }, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { body += c; });
      res.on('end', () => resolve({ status: res.statusCode, body }));
    });
    req.on('error', (e) => resolve({ status: 0, body: '', err: e.message }));
    req.setTimeout(20000, () => { try { req.destroy(); } catch { /* ignore */ } });
  });
}

(async () => {
  const hot = await get('https://api.maoyan.com/mmdb/movie/v5/list/hot.json?ci=1');
  const hj = JSON.parse(hot.body);
  const ids = (hj.data && hj.data.movieIds) || [];
  const r = await get(`https://m.maoyan.com/ajax/movieOnInfoList?token=&movieIds=${ids.slice(0, 30).join(',')}`);
  const j = JSON.parse(r.body);
  console.log('coming = ' + JSON.stringify(j.coming).slice(0, 400));
  console.log('total = ' + JSON.stringify(j.total).slice(0, 300));
  console.log('stids = ' + JSON.stringify(j.stids).slice(0, 200));
  console.log('abbreviation = ' + JSON.stringify(j.abbreviation).slice(0, 300));
  console.log('schemaUrl = ' + JSON.stringify(j.schemaUrl).slice(0, 200));
  console.log('movieIds = ' + JSON.stringify(j.movieIds).slice(0, 300));

  /* 试另一个入口：猫眼「即将上映」列表页的 ajax */
  for (const u of [
    'https://m.maoyan.com/ajax/movieComingList?token=&ci=1',
    'https://m.maoyan.com/ajax/comingList?token=&ci=1',
    'https://api.maoyan.com/mmdb/movie/v5/list/coming.json?ci=1',
    'https://api.maoyan.com/mmdb/movie/v5/list/coming.json?ci=1&token=',
  ]) {
    const rr = await get(u);
    console.log(`\n${u} → HTTP ${rr.status} · ${rr.body.length} 字节`);
    console.log('  ' + rr.body.slice(0, 220).replace(/\s+/g, ' '));
  }
})();
