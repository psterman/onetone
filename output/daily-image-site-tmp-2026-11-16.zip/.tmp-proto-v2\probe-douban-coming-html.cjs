/* 临时探针 11：豆瓣 /coming 页面 HTML 里有没有海报缩略图 */
const https = require('node:https');
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

function get(url, depth) {
  return new Promise((resolve) => {
    const req = https.get(url, { headers: { 'User-Agent': UA, Referer: 'https://movie.douban.com/' } }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && depth < 6) {
        res.resume();
        get(new URL(res.headers.location, url).href, depth + 1).then(resolve);
        return;
      }
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { body += c; });
      res.on('end', () => resolve({ status: res.statusCode, body, url }));
    });
    req.on('error', (e) => resolve({ status: 0, body: '', err: e.message }));
    req.setTimeout(20000, () => { try { req.destroy(); } catch { /* ignore */ } });
  });
}

(async () => {
  const r = await get('https://movie.douban.com/coming', 0);
  console.log(`HTTP ${r.status} · ${r.body.length} 字节 · 最终 URL ${r.url}`);
  const imgs = [...r.body.matchAll(/<img[^>]+src=["']([^"']+)["']/gi)].map((m) => m[1]);
  console.log(`<img> 共 ${imgs.length} 个`);
  const doubanImgs = imgs.filter((u) => /doubanio/.test(u));
  console.log(`其中 doubanio 图 ${doubanImgs.length} 个:`);
  for (const u of doubanImgs.slice(0, 8)) console.log('  ' + u.slice(0, 110));
  const subjectLinks = [...r.body.matchAll(/href=["'](https:\/\/movie\.douban\.com\/subject\/(\d+)\/?)["']/gi)];
  console.log(`subject 链接 ${subjectLinks.length} 个（前 5）: ${subjectLinks.slice(0, 5).map((m) => m[2]).join(', ')}`);
  /* 表格行里有没有 poster 字段 */
  const rows = (r.body.match(/<tr[^>]*>[\s\S]*?<\/tr>/g) || []);
  console.log(`表格 ${rows.length} 行`);
  if (rows[1]) {
    console.log('第 2 行片段: ' + rows[1].replace(/\s+/g, ' ').slice(0, 400));
  }
})();
