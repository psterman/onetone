﻿import https from 'node:https';
function post(q,v){
  return new Promise((res)=>{
    const body=JSON.stringify({query:q,variables:v});
    const r=https.request('https://apis.justwatch.com/graphql',{method:'POST',headers:{'Content-Type':'application/json','X-Client-Id':'justwatch','Origin':'https://www.justwatch.com','Referer':'https://www.justwatch.com/','User-Agent':'Mozilla/5.0','Content-Length':Buffer.byteLength(body)}},(resp)=>{
      let d='';resp.on('data',c=>d+=c);resp.on('end',()=>res({s:resp.statusCode,body:d}));
    });
    r.on('error',e=>res({s:0,body:'ERR '+e.message}));
    r.setTimeout(25000,()=>{r.destroy();res({s:0,body:'TIMEOUT'})});
    r.write(body); r.end();
  });
}
const JH={'Content-Type':'application/json','X-Client-Id':'justwatch','Origin':'https://www.justwatch.com','Referer':'https://www.justwatch.com/'};
const C=['id','objectType','label','originalTitle','sortTitle','productionCountry','showType','seriesLength','seasonLength','episodeLength','firstAirDate','lastAirDate','posterPath','backdropPath','logoPath','logo','mainPoster','packageOption','offers','providers','seasonsCount','hasFutureEpisodes','shortenedTitle','titleText','titles','texts','availablePackages','packageOptions','packages','contentRatings','genres','credits','images','posterUrl','imageUrl','titleTextOriginal','sortTitleText','releaseDateText'];
const r=await post('query($c:Country!){ newTitles(first:2,country:$c){ edges { node { '+C.join(' ')+' } } } }',{c:'HK'});
console.log('[MovieOrSeason 大候选] status='+r.s);
try{
  const j=JSON.parse(r.body);
  const bad=(j.errors||[]).map(e=>(e.message.match(/field "([^"]+)"/)||[])[1]).filter(Boolean);
  const valid=C.filter(c=>!bad.includes(c));
  console.log('   合法字段: '+JSON.stringify(valid));
  const other=(j.errors||[]).filter(e=>!e.message.startsWith('Cannot query field')).map(e=>e.message);
  if(other.length) console.log('   其他: '+JSON.stringify(other).slice(0,400));
  if(j.data) console.log('   DATA: '+JSON.stringify(j.data).slice(0,800));
}catch(e){ console.log(r.body.slice(0,400)); }

console.log('\n=== packages: HK / US / CN 各市场的平台 ===');
for(const c of ['HK','US','CN']){
  const rr=await post('query($c:Country!,$p:Platform!){ packages(country:$c,platform:$p){ id technicalName icon slug } }',{c,p:'WEB'});
  if(rr.s===200){ try{ const j=JSON.parse(rr.body); console.log('  '+c+' ('+j.data.packages.length+'): '+j.data.packages.map(x=>x.technicalName).join(', ')); }catch(e){ console.log('  '+c+' parse fail'); } }
  else console.log('  '+c+' status='+rr.s+' '+rr.body.slice(0,200));
}
