﻿import https from 'node:https';
function get(url, headers={}, depth=0){
  return new Promise((res)=>{
    if(depth>6) return res({s:0,body:'TOO_MANY_REDIRECT'});
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','Accept':'text/html,*/*','Accept-Language':'en-US,en;q=0.9'},headers)},r=>{
      if([301,302,303,307,308].includes(r.statusCode)&&r.headers.location){
        return get(new URL(r.headers.location,url).href,headers,depth+1).then(x=>res({...x,chain:(x.chain||[]).concat(url+' -> '+r.headers.location)}));
      }
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(25000,()=>{try{req.destroy();}catch(e){} res({s:0,body:'TIMEOUT'})});
  });
}
const r=await get('https://www.tiktok.com/trending',{Referer:'https://www.tiktok.com/'});
console.log('status='+r.s+' len='+r.body.length+' chain='+JSON.stringify(r.chain||[]));
const m=r.body.match(/__UNIVERSAL_DATA_FOR_REHYDRATION\s*=\s*(\{[\s\S]*?\});/);
if(!m){ console.log('未匹配 UNIVERSAL_DATA；片段搜索 hashtag/challenge:');
  console.log('  "challengeInfo"='+r.body.includes('challengeInfo')+'  "hashtagName"='+r.body.includes('hashtagName')+'  "viewCount"='+r.body.includes('viewCount')+'  "videoCount"='+r.body.includes('videoCount'));
  const hn=[...r.body.matchAll(/"hashtagName":"([^"]{1,60})"/g)].map(x=>x[1]);
  console.log('  hashtagName 样例: '+JSON.stringify([...new Set(hn)].slice(0,12)));
  const vc=[...r.body.matchAll(/"viewCount":(\d+)/g)].map(x=>x[1]);
  console.log('  viewCount 样例: '+JSON.stringify(vc.slice(0,8)));
  const cv=[...r.body.matchAll(/"videoCount":(\d+)/g)].map(x=>x[1]);
  console.log('  videoCount 样例: '+JSON.stringify(cv.slice(0,8)));
  const th=[...r.body.matchAll(/"(https?:\\?\/\\?\/[^"]{20,120}(?:tiktokcdn|byteimg)[^"]{0,80})"/g)].map(x=>x[1]);
  console.log('  CDN 图 URL 样例: '+JSON.stringify([...new Set(th)].slice(0,3)));
} else {
  try{
    const j=JSON.parse(m[1]);
    const dump=(o,path,d)=>{ if(d>4||!o||typeof o!=='object')return;
      for(const k of Object.keys(o)){ const v=o[k];
        if(Array.isArray(v)&&v.length&&typeof v[0]==='object'){ console.log('  '+path+'.'+k+' = 数组['+v.length+'] 首项键: '+Object.keys(v[0]).slice(0,14).join(',')); dump(v[0],path+'.'+k+'[0]',d+1); }
        else if(v&&typeof v==='object'){ console.log('  '+path+'.'+k+' = {'+Object.keys(v).slice(0,10).join(',')+'}'); dump(v,path+'.'+k,d+1); } } };
    console.log('顶层键: '+Object.keys(j).join(','));
    dump(j,'',0);
  }catch(e){ console.log('parse fail '+e.message); }
}
