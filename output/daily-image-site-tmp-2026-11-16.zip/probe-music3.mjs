﻿import https from 'node:https';
function get(url, headers={}, depth=0){
  return new Promise((res)=>{
    if(depth>6) return res({s:0,body:'TOO_MANY_REDIRECT'});
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)','Accept':'*/*'},headers)},r=>{
      if([301,302,303,307,308].includes(r.statusCode)&&r.headers.location){
        return get(new URL(r.headers.location,url).href,headers,depth+1).then(x=>res({...x,chain:(x.chain||[]).concat(r.headers.location)}));
      }
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(20000,()=>{try{req.destroy();}catch(e){} res({s:0,body:'TIMEOUT'})});
  });
}
console.log('=== A. Apple Music RSS 新域名（逐路径试） ===');
for(const p of ['us/music/most-played/30/songs.json','us/music/most-played/30/albums.json','us/music/new-music/30/songs.json','us/music/playlists.json','cn/music/most-played/30/songs.json']){
  const u='https://rss.marketingtools.apple.com/api/v2/'+p;
  const r=await get(u);
  let out='status='+r.s+' len='+r.body.length;
  if(r.s===200){ try{ const j=JSON.parse(r.body); out+=' feed='+(j.feed&&j.feed.title)+' 条数='+(j.feed&&j.feed.results?j.feed.results.length:'?'); }catch(e){ out+=' '+r.body.slice(0,70); } }
  else out+=' '+r.body.slice(0,60);
  console.log('  '+p+' -> '+out);
}

console.log('\n=== B. iTunes 歌单查询（用真实 playlist id） ===');
for(const id of ['1440833098','1373475605','pl.u-abc123']){
  const r=await get('https://itunes.apple.com/lookup?id='+id+'&entity=song&limit=3');
  let out='status='+r.s;
  try{ const j=JSON.parse(r.body); out+=' count='+j.resultCount+' kinds='+JSON.stringify([...new Set(j.results.map(x=>x.kind))]); }catch(e){ out+=' '+r.body.slice(0,60); }
  console.log('  lookup id='+id+' -> '+out);
}
const r2=await get('https://itunes.apple.com/search?term=%E5%8F%8D%E5%85%89&entity=musicArtist&limit=2');
console.log('  search artist -> status='+r2.s+' '+(r2.body.match(/"artistName":"([^"]+)"/)||[])[1]);

console.log('\n=== C. 网易云 UGC 歌单（用户自建歌单能否取到） ===');
for(const [n,id] of [['某公开歌单',1748095669],['官方歌单',3778678]]){
  const rr=await get('https://music.163.com/api/playlist/detail?id='+id,{Referer:'https://music.163.com/'});
  let out='status='+rr.s+' len='+rr.body.length;
  try{ const j=JSON.parse(rr.body); const p=j.result||j.playlist;
    out+=' name='+(p&&p.name)+' tracks='+(p&&p.trackCount)+' creator='+(p&&p.creator&&p.creator.nickname)+' cover='+((p&&p.coverImgUrl||'').slice(0,50)); }catch(e){ out+=' '+rr.body.slice(0,80); }
  console.log('  '+n+' ('+id+'): '+out);
}

console.log('\n=== D. QQ音乐 topid 全表探测 ===');
for(const [n,topid] of [['热歌榜',26],['新歌榜',27],['飙升榜',28],['内地榜',16],['香港榜',17],['台湾榜',18],['欧美榜',19],['日韩榜',22],['网络歌曲',23],['说唱榜',24],['原创榜',25],['音悦台',6]]){
  const rr=await get('https://c.y.qq.com/v8/fcg-bin/fcg_v8_toplist_cp.fcg?topid='+topid+'&format=json',{Referer:'https://y.qq.com/'});
  let out='status='+rr.s;
  try{ const j=JSON.parse(rr.body); out+=' code='+j.code+' date='+j.date+' songs='+j.cur_song_num+' group='+(j.toplist&&j.toplist[0]?j.toplist[0].ListName:''); }catch(e){ out+=' '+rr.body.slice(0,60); }
  console.log('  '+n+' (topid='+topid+'): '+out);
}
