﻿import https from 'node:https';
function get(url, headers={}) {
  return new Promise((res)=>{
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','Accept':'text/html,application/json,*/*','Accept-Language':'zh-CN,zh;q=0.9'},headers)},r=>{
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(20000,()=>{try{req.destroy();}catch(e){} res({s:0,body:'TIMEOUT'})});
  });
}
console.log('=== A. 豆瓣 /coming 到底有没有片名 ===');
const r=await get('https://movie.douban.com/coming',{Referer:'https://movie.douban.com/'});
const subj=[...r.body.matchAll(/\/subject\/(\d+)/g)].map(m=>m[1]);
console.log('  subject 链接数='+subj.length+' 唯一='+new Set(subj).size);
const anyTitle=[...r.body.matchAll(/<h2[^>]*>([\s\S]{0,160}?)<\/h2>/g)].map(m=>m[1].replace(/<[^>]+>/g,'').trim()).filter(Boolean);
console.log('  h2 标题: '+JSON.stringify(anyTitle.slice(0,10)));
console.log('  含"subject"字样='+r.body.includes('subject')+' 含"wish"='+r.body.includes('wish')+' 含"date"='+r.body.includes('release'));
console.log('  含 __DATA__='+r.body.includes('__DATA__')+' 含 window.__='+r.body.includes('window.__'));
console.log('  片段: '+r.body.replace(/\s+/g,' ').slice(1400,2400));

console.log('\n=== B. 猫眼 movieOnInfoList 结构 ===');
const m=await get('https://m.maoyan.com/ajax/movieOnInfoList?token=&movieIds=1552906,1586199,1566940',{Referer:'https://m.maoyan.com/'});
try{ const j=JSON.parse(m.body); console.log('  顶层: '+Object.keys(j).join(','));
  console.log('  data: '+Object.keys(j.data||{}).join(','));
  for(const k of Object.keys(j.data||{})){ const v=j.data[k]; if(Array.isArray(v)) console.log('   data.'+k+' = 数组['+v.length+'] 首项键: '+(v[0]&&Object.keys(v[0]).slice(0,16).join(','))); }
  if(j.data&&j.data.movieList&&j.data.movieList[0]) console.log('  首项: '+JSON.stringify(j.data.movieList[0]).slice(0,400));
}catch(e){ console.log('  '+m.body.slice(0,200)); }
