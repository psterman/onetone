﻿import https from 'node:https';
function get(url, headers={}) {
  return new Promise((res)=>{
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)','Accept':'*/*'},headers)},r=>{
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(20000,()=>{try{req.destroy();}catch(e){} res({s:0,body:'TIMEOUT'})});
  });
}
console.log('=== iTunes：playlist lookup / 新歌榜 ===');
for(const u of [
  'https://itunes.apple.com/lookup?id=1373475605&entity=song&limit=5',
  'https://itunes.apple.com/lookup?id=1&entity=song',
  'https://itunes.apple.com/search?term=%E5%91%A8%E6%9D%B0%E4%BC%A6&country=cn&media=music&limit=3',
]){
  const r=await get(u);
  let out=r.body.slice(0,150).replace(/\s+/g,' ');
  if(r.s===200){ try{ const j=JSON.parse(r.body); out='count='+j.resultCount+' '+(j.results[0]?JSON.stringify({name:j.results[0].collectionName||j.results[0].trackName,artist:j.results[0].artistName,kind:j.results[0].kind,url:j.results[0].collectionViewUrl}).slice(0,220):''); }catch(e){} }
  console.log('  '+u.slice(0,72)+'\n     status='+r.s+' '+out);
}
console.log('\n=== Apple Music 官方 RSS 变体 ===');
for(const u of [
  'https://rss.applemarketingtools.com/api/v2/us/music/most-played/30/songs.json',
  'https://rss.applemarketingtools.com/api/v2/us/music/new-music/30/songs.json',
  'https://rss.applemarketingtools.com/api/v2/cn/music/most-played/30/songs.json',
  'https://rss.applemarketingtools.com/api/v2/us/music/playlists.json',
  'https://rss.applemarketingtools.com/api/v2/us/music/new-albums/30/albums.json',
]){
  const r=await get(u);
  console.log('  '+u.replace('https://rss.applemarketingtools.com/api/v2/','')+' -> status='+r.s+' len='+r.body.length+' '+r.body.slice(0,90).replace(/\s+/g,' '));
}
console.log('\n=== 网易云各榜单 id ===');
for(const [name,id] of [['热歌榜',3778678],['新歌榜',3779629],['飙升榜',19723756],['原创榜',3778679],['DJ榜',3778690]]){
  const r=await get('https://music.163.com/api/playlist/detail?id='+id,{'Referer':'https://music.163.com/'});
  let out='status='+r.s+' len='+r.body.length;
  if(r.s===200){ try{ const j=JSON.parse(r.body); out+=' name='+(j.result&&j.result.name)+' tracks='+(j.result&&j.result.trackCount); }catch(e){ out+=' '+r.body.slice(0,80); } }
  console.log('  '+name+' ('+id+'): '+out);
}
