/* 临时探针 6：豆瓣同城封面图热链到底能不能直出（418 是谁挡的） */
const fs = require('node:fs');
const s = fs.readFileSync('E:/voice-pilot/daily-image-site/tools/.tmp-proto-v2/data.js', 'utf8');
const j = JSON.parse(s.slice(s.indexOf('{'), s.lastIndexOf('}') + 1));
const items = (j.follow.cities.find((c) => c.name === '武汉') || {}).items || [];
const withCover = items.filter((i) => i.cover);
console.log(`武汉 ${items.length} 条 · 带封面 ${withCover.length} 条`);
if (!withCover.length) { console.log('没有封面 URL —— 说明解析时根本没抓到图'); process.exit(0); }
const u = withCover[0].cover;
console.log('URL: ' + u);

const https = require('node:https');
function probe(name, headers) {
  return new Promise((resolve) => {
    const req = https.get(u, { headers }, (res) => {
      let n = 0;
      res.on('data', (c) => { n += c.length; });
      res.on('end', () => {
        console.log(`${name}: HTTP ${res.statusCode} · ${res.headers['content-type']} · ${n} 字节`);
        resolve();
      });
    });
    req.on('error', (e) => { console.log(`${name}: ERR ${e.message}`); resolve(); });
    req.setTimeout(15000, () => { try { req.destroy(); } catch { /* ignore */ } });
  });
}

(async () => {
  await probe('裸连（无 referer/UA）', {});
  await probe('带 Referer=douban.com', { Referer: 'https://movie.douban.com/' });
  await probe('带 Referer=www.douban.com', { Referer: 'https://www.douban.com/' });
  await probe('带浏览器 UA + 无 referer', {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
  });
  await probe('带 UA + Referer=douban', {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
    Referer: 'https://www.douban.com/',
  });
})();
