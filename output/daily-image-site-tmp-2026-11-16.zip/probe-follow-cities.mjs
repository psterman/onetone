const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
  '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

const SLUGS = [
  'beijing', 'shanghai', 'guangzhou', 'shenzhen', 'hangzhou', 'chengdu',
  'wuhan', 'nanjing', 'chongqing', 'xian', 'suzhou', 'tianjin',
];

async function main() {
  for (const slug of SLUGS) {
    const url = `https://www.douban.com/location/${slug}/events`;
    try {
      const r = await fetch(url, {
        headers: { 'User-Agent': UA, Referer: `https://www.douban.com/location/${slug}/` },
      });
      const html = await r.text();
      const n = (html.split('<li class="list-entry"').length - 1);
      const st = (html.match(/<time itemprop="startDate" datetime="([^"]*)"/) || [])[1] || 'NO-TIME';
      const dl = (html.match(/data-lazy="([^"]*)"/) || [])[1] || 'NO-LAZY';
      const li = (html.match(/<li title="([^"]*)"/) || [])[1] || 'NO-LI';
      console.log(slug, r.status, 'items=' + n, '| start=' + st, '| loc=' + li);
      console.log('    poster=' + dl);
    } catch (e) {
      console.log(slug, 'ERR', e && e.message);
    }
  }

  // 防盗链探测
  const p = 'https://img9.doubanio.com/pview/event_poster/median/public/fd83cd573ebb195.jpg';
  for (const [label, headers] of [
    ['no-referer', { 'User-Agent': UA }],
    ['our-site-referer', { 'User-Agent': UA, Referer: 'https://da-la-pi.github.io/' }],
    ['douban-referer', { 'User-Agent': UA, Referer: 'https://www.douban.com/' }],
  ]) {
    try {
      const r = await fetch(p, { headers });
      console.log('poster', label, r.status, r.headers.get('content-type'));
    } catch (e) {
      console.log('poster', label, 'ERR', e && e.message);
    }
  }
}

main().catch((e) => console.error('ERR', e && e.message));
