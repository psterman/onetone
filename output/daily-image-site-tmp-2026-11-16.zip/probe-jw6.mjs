﻿import https from 'node:https';
function post(q,v){
  return new Promise((res)=>{
    const body=JSON.stringify({query:q,variables:v});
    const r=https.request('https://apis.justwatch.com/graphql',{method:'POST',headers:{'Content-Type':'application/json','X-Client-Id':'justwatch','Origin':'https://www.justwatch.com','Referer':'https://www.justwatch.com/','User-Agent':'Mozilla/5.0','Content-Length':Buffer.byteLength(body)}},(resp)=>{
      let d='';resp.on('data',c=>d+=c);resp.on('end',()=>res({s:resp.statusCode,body:d}));
    });
    r.on('error',e=>res({s:0,body:'ERR '+e.message}));
    r.setTimeout(25000,()=>{r.destroy();res({s:0,body:'TIMEOUT'})});
    r.write(body); r.end();
  });
}
const JH={'Content-Type':'application/json','X-Client-Id':'justwatch','Origin':'https://www.justwatch.com','Referer':'https://www.justwatch.com/'};
console.log('=== A. JustWatch newTitles(HK) 到底给不给得出条目 ===');
let r=await post('query($c:Country!){ newTitles(first:5,country:$c){ edges { node { id objectType } } } }',{c:'HK'});
console.log('status='+r.s+' '+(r.s===200?r.body.slice(0,500):r.body.slice(0,300)));

console.log('\n=== B. offers 字段反推 ===');
r=await post('query($c:Country!,$p:Platform!){ newTitles(first:1,country:$c){ edges { node { id objectType offers(country:$c,platform:$p){ zzz } } } } }',{c:'HK',p:'WEB'});
try{ const j=JSON.parse(r.body); const bad=(j.errors||[]).map(e=>(e.message.match(/field "([^"]+)"/)||[])[1]).filter(Boolean);
 const C=['id','package','monetizationType','price','packageOption','technicalName','offerType','isStreamable','deeplink','availableFrom','availableUntil'];
 console.log('   Offer 合法字段: '+JSON.stringify(C.filter(c=>!bad.includes(c)))+'  非法: '+JSON.stringify(bad));
 const other=(j.errors||[]).filter(e=>!e.message.startsWith('Cannot query field')).map(e=>e.message);
 if(other.length) console.log('   其他: '+JSON.stringify(other).slice(0,300));
 if(j.data) console.log('   DATA: '+JSON.stringify(j.data).slice(0,600));
}catch(e){ console.log(r.body.slice(0,400)); }

console.log('\n=== C. 用合法字段实取一条 HK 新片 ===');
r=await post('query($c:Country!,$p:Platform!){ newTitles(first:3,country:$c){ edges { node { id objectType offers(country:$c,platform:$p){ id package { id technicalName } monetizationType } } } } }',{c:'HK',p:'WEB'});
console.log('status='+r.s+'\n   '+(r.s===200?r.body.slice(0,900):r.body.slice(0,400)));
