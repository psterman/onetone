﻿import https from 'node:https';
function get(url, headers={}) {
  return new Promise((res)=>{
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)','Accept':'*/*'},headers)},r=>{
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(25000,()=>{try{req.destroy();}catch(e){} res({s:0,body:'TIMEOUT'})});
  });
}
console.log('=== A. TVB network id + 能否按 network 拉剧集清单 ===');
let r=await get('https://api.tvmaze.com/shows/7329');
// 先用使徒行者
r=await get('https://api.tvmaze.com/search/shows?q='+encodeURIComponent('使徒行者'));
const j=JSON.parse(r.body); const show=j[0].show;
console.log('  使徒行者 id='+show.id+' network='+JSON.stringify(show.network)+' web='+JSON.stringify(show.webChannel));
const netId=show.network&&show.network.id;
if(netId){
  const r2=await get('https://api.tvmaze.com/networks/'+netId+'/shows');
  console.log('  /networks/'+netId+'/shows status='+r2.s+' len='+r2.body.length);
  if(r2.s===200){ try{ const arr=JSON.parse(r2.body); console.log('    TVB 剧集数='+arr.length+' 前10: '+arr.slice(0,10).map(s=>s.name+'('+s.language+')').join(', ')); }catch(e){ console.log('    '+r2.body.slice(0,200)); } }
  const r3=await get('https://api.tvmaze.com/shows?network='+netId);
  console.log('  /shows?network='+netId+' status='+r3.s+' len='+r3.body.length);
  if(r3.s===200){ try{ const arr=JSON.parse(r3.body); console.log('    条数='+arr.length+' 前12: '+arr.slice(0,12).map(s=>s.name).join(', ')); }catch(e){} }
}

console.log('\n=== B. updates/shows?since=day → 按频道分组的可行性 ===');
r=await get('https://api.tvmaze.com/updates/shows?since=day');
const ids=Object.keys(JSON.parse(r.body));
console.log('  当天更新的 show 数='+ids.length);
const wc={},nw={},langs={}; const sample=[];
for(const id of ids.slice(0,40)){
  const rr=await get('https://api.tvmaze.com/shows/'+id);
  if(rr.s!==200) continue;
  const s=JSON.parse(rr.body);
  const k=s.webChannel?s.webChannel.name:(s.network?s.network.name:'无');
  nw[k]=(nw[k]||0)+1;
  langs[s.language]=(langs[s.language]||0)+1;
  if(sample.length<12) sample.push(s.name+' ['+k+']');
}
console.log('  前40个的频道分布: '+JSON.stringify(nw));
console.log('  语言分布: '+JSON.stringify(langs));
console.log('  样例: '+sample.join(' | '));

console.log('\n=== C. TVmaze /shows 总页数 ===');
for(const p of [100,250,251,300]){
  const rr=await get('https://api.tvmaze.com/shows?page='+p);
  let n=0; try{ n=JSON.parse(rr.body).length; }catch(e){}
  console.log('  page='+p+' status='+rr.s+' 条数='+n+' bytes='+rr.body.length);
}
