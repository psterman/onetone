// 临时排查：为什么两处变异没被护栏抓住
import fs from 'node:fs';

const B = fs.readFileSync('E:/voice-pilot/daily-image-site/tools/build.mjs', 'utf8');

const scaleFrom = '`scale=${COVER_MAX_EDGE}:${COVER_MAX_EDGE}:force_original_aspect_ratio=decrease:flags=lanczos`';
console.log('scale 锚点命中:', B.includes(scaleFrom));
console.log('decrease 出现次数:', (B.match(/force_original_aspect_ratio=decrease/g) || []).length);

const nameFrom = "  let name = `${nonce}_${String(seq).padStart(3, '0')}.webp`;";
console.log('name 锚点命中:', B.includes(nameFrom));
console.log('name 模式出现次数:', (B.match(/\$\{nonce\}_\$\{String\(seq\)\.padStart\(3, '0'\)\}\.webp/g) || []).length);

console.log('--- 护栏正则实测 ---');
console.log('命名正则:', /\$\{nonce\}_\$\{String\(seq\)\.padStart\(3,\s*'0'\)\}\.webp/.test(B));
console.log('等比正则:', /force_original_aspect_ratio=decrease/.test(B));

const mutated = B.replace(scaleFrom, '`scale=${COVER_MAX_EDGE}:${COVER_MAX_EDGE}:flags=lanczos`');
console.log('--- 变异后 ---');
console.log('等比正则:', /force_original_aspart/.test(mutated), /force_original_aspect_ratio=decrease/.test(mutated));
