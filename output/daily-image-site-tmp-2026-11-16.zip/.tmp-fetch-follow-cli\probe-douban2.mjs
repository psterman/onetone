/** 临时探针 2：看单个条目的完整 HTML + 页面里有没有逐条的类型标记 */
import https from 'node:https';

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
  '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

function once(u, depth = 0) {
  return new Promise((resolve) => {
    const req = https.get(
      u,
      { headers: { 'User-Agent': UA, Accept: '*/*', 'Accept-Language': 'zh-CN,zh;q=0.9' } },
      (res) => {
        if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && depth < 6) {
          res.resume();
          once(new URL(res.headers.location, u).href, depth + 1).then(resolve);
          return;
        }
        let text = '';
        res.setEncoding('utf8');
        res.on('data', (c) => { text += c; });
        res.on('end', () => resolve({ status: res.statusCode, text, url: u }));
      },
    );
    req.on('error', (e) => resolve({ status: 0, text: '', url: u, error: e.message }));
    req.setTimeout(30000, () => { try { req.destroy(); } catch { /* ignore */ } });
  });
}

const r = await once(process.argv[2] || 'https://www.douban.com/location/beijing/events');
const html = r.text;
console.log('status', r.status, 'url', r.url, 'len', html.length);

/** 切出每个 list-entry 块 */
const blocks = html.split('<li class="list-entry"').slice(1);
console.log('条目数 =', blocks.length);

console.log('\n=== 第 1 条完整块 ===');
const b = blocks[0];
console.log(b.slice(0, b.indexOf('</li>\n') + 6 > 0 ? Math.min(b.length, 3000) : 3000));

console.log('\n=== 每条的 location title 属性 ===');
for (const blk of blocks) {
  const m = blk.match(/<li title="([^"]*)"/);
  const s = blk.match(/<span itemprop="summary"[^>]*>([\s\S]*?)<\/span>/);
  console.log('  loc=', JSON.stringify(m ? m[1] : null), ' title=', JSON.stringify(s ? s[1].trim() : null));
}

console.log('\n=== 页面里有没有逐条类型标记（eventType / category / tag 标签） ===');
console.log('  itemprop="eventType" 次数 =', (html.match(/itemprop="eventType"/g) || []).length);
console.log('  "活动类型" 次数 =', (html.match(/活动类型/g) || []).length);
console.log('  class="tag" 次数 =', (html.match(/class="tag"/g) || []).length);

console.log('\n=== 条目块里出现的所有 class 名 ===');
const classes = new Set();
for (const blk of blocks) {
  for (const m of blk.matchAll(/class="([^"]+)"/g)) classes.add(m[1]);
}
console.log(' ', [...classes].join(' | '));

console.log('\n=== 除导航外，页面上「音乐」「展览」等词出现在哪 ===');
for (const w of ['音乐', '展览', '戏剧', '讲座']) {
  const idx = [];
  let i = -1;
  while ((i = html.indexOf(w, i + 1)) >= 0) idx.push(i);
  console.log(' ', w, '出现', idx.length, '次，前几处上下文：');
  for (const p of idx.slice(0, 4)) console.log('    ...', JSON.stringify(html.slice(Math.max(0, p - 90), p + 30)));
}
