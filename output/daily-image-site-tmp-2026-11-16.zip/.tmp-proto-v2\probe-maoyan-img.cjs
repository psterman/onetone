/* 临时探针 7：猫眼封面 CDN 到底能不能直出 */
const https = require('node:https');
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
const URLS = [
  'https://p0.pipi.cn/mediaplus/friday_image_fe/e429589aea4b81e327392a78653c491a0764b.jpg?imageMogr2/quality/80',
  'https://p0.pipi.cn/mediaplus/friday_image_fe/e429589aea4b81e327392a78653c491a0764b.jpg',
];

function probe(name, url, headers) {
  return new Promise((resolve) => {
    const req = https.get(url, { headers }, (res) => {
      let n = 0;
      res.on('data', (c) => { n += c.length; });
      res.on('end', () => {
        console.log(`${name}: HTTP ${res.statusCode} · ${res.headers['content-type']} · ${n} 字节`);
        resolve();
      });
    });
    req.on('error', (e) => { console.log(`${name}: ERR ${e.message}`); resolve(); });
    req.setTimeout(15000, () => { try { req.destroy(); } catch { /* ignore */ } });
  });
}

(async () => {
  await probe('裸连（带 query）', URLS[0], {});
  await probe('裸连（去 query）', URLS[1], {});
  await probe('带 UA（带 query）', URLS[0], { 'User-Agent': UA });
  await probe('带 UA + Referer=maoyan', URLS[0], { 'User-Agent': UA, Referer: 'https://www.maoyan.com/' });
})();
