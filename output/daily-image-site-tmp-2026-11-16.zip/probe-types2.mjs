﻿import https from 'node:https';
const UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
function once(u,depth){
  return new Promise((resolve)=>{
    const req=https.get(u,{headers:{'User-Agent':UA,'Accept':'*/*','Accept-Language':'zh-CN,zh;q=0.9','Referer':'https://www.douban.com/location/wuhan/'}},(res)=>{
      if([301,302,303,307,308].includes(res.statusCode)&&res.headers.location&&depth<6){
        res.resume();
        const next=new URL(res.headers.location,u).href;
        console.log('  hop '+depth+': '+u+' -> '+res.headers.location);
        once(next,depth+1).then(resolve); return;
      }
      let t=''; res.setEncoding('utf8'); res.on('data',c=>t+=c); res.on('end',()=>resolve({s:res.statusCode,body:t,url:u}));
    });
    req.on('error',e=>resolve({s:0,body:'ERR '+e.message,url:u}));
    req.setTimeout(20000,()=>{try{req.destroy();}catch(e){} resolve({s:0,body:'TIMEOUT',url:u})});
  });
}
const r=await once('https://www.douban.com/location/wuhan/events',0);
console.log('最终 status='+r.s+' url='+r.url+' len='+r.body.length);
const i=r.body.indexOf('week-music');
console.log('week-music 位置='+i);
if(i>0) console.log('片段:\n'+r.body.slice(i-300,i+400));
else {
  console.log('页面里所有 events/week- 出现:');
  for(const m of r.body.matchAll(/.{0,60}events\/week-[a-z-]+.{0,50}/g)){ console.log('   '+m[0].replace(/\s+/g,' ')); }
}
