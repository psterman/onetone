/* 临时探针 4：验证 /schedule/full?date= 的条目是否都属于该日期，以及 payload 体积 */
const DAY = '2026-11-17';

async function main() {
  const t0 = Date.now();
  const r = await fetch(`https://api.tvmaze.com/schedule/full?date=${DAY}`);
  const text = await r.text();
  const j = JSON.parse(text);
  console.log(`字节 ${text.length} · 条目 ${j.length} · 耗时 ${Date.now() - t0}ms`);

  const airdates = new Map();
  const shows = new Map();
  let missingShow = 0;
  for (const e of j) {
    const d = e.airdate || '(none)';
    airdates.set(d, (airdates.get(d) || 0) + 1);
    const s = (e._embedded && e._embedded.show) || e.show;
    if (!s) { missingShow++; continue; }
    if (!shows.has(s.id)) shows.set(s.id, s);
  }
  console.log('airdate 分布: ' + [...airdates.entries()].sort((a, b) => b[1] - a[1]).slice(0, 10)
    .map(([k, v]) => `${k}=${v}`).join(' | '));
  console.log(`去重剧 ${shows.size} · 缺 show 的条目 ${missingShow}`);

  /* 有多少剧带 webChannel / network，以及语言分布 */
  const lang = new Map();
  let withWeb = 0;
  for (const s of shows.values()) {
    if (s.webChannel && s.webChannel.name) withWeb++;
    const l = s.language || '(none)';
    lang.set(l, (lang.get(l) || 0) + 1);
  }
  console.log(`带 webChannel 的剧 ${withWeb} / ${shows.size}`);
  console.log('语言 top10: ' + [...lang.entries()].sort((a, b) => b[1] - a[1]).slice(0, 10)
    .map(([k, v]) => `${k}=${v}`).join(' | '));

  /* 中文剧 / 港剧检查 */
  const zh = [...shows.values()].filter((s) => s.language === 'Chinese');
  console.log(`\n中文剧 ${zh.length} 部，示例:`);
  for (const s of zh.slice(0, 12)) {
    const w = s.webChannel && s.webChannel.name;
    const n = s.network && s.network.name;
    console.log(`  ${s.name} | ${w || n || '(none)'} | ${s.status} | ${s.premiered || ''}`);
  }
}

main().catch((e) => { console.error(e); process.exit(1); });
