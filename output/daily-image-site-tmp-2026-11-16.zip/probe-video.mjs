﻿import https from 'node:https';
function get(url, headers={}, depth=0){
  return new Promise((res)=>{
    if(depth>6) return res({s:0,body:'TOO_MANY_REDIRECT'});
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','Accept':'*/*','Accept-Language':'zh-CN,zh;q=0.9'},headers)},r=>{
      if([301,302,303,307,308].includes(r.statusCode)&&r.headers.location){
        return get(new URL(r.headers.location,url).href,headers,depth+1).then(x=>res({...x,chain:(x.chain||[]).concat(url+' -> '+r.headers.location)}));
      }
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(20000,()=>{try{req.destroy();}catch(e){} res({s:0,body:'TIMEOUT'})});
  });
}
console.log('=== B站热门（复核） ===');
let r=await get('https://api.bilibili.com/x/web-interface/popular?ps=50&pn=1',{Referer:'https://www.bilibili.com/'});
console.log('  status='+r.s+' len='+r.body.length);
try{ const j=JSON.parse(r.body); const l=j.data&&j.data.list||[]; console.log('  code='+j.code+' 条数='+l.length);
  if(l[0]) console.log('  首条: '+JSON.stringify({title:l[0].title,author:l[0].owner&&l[0].owner.name,pic:(l[0].pic||'').slice(0,60),view:l[0].stat&&l[0].stat.view,bvid:l[0].bvid}).slice(0,260));
}catch(e){ console.log('  '+r.body.slice(0,120)); }

console.log('\n=== YouTube 热门（多个候选路径） ===');
for(const u of [
  'https://www.youtube.com/feeds/videos.xml?chart=mostPopular',
  'https://www.youtube.com/feed/trending',
  'https://rss.youtube.com/feeds/videos.xml?chart=mostPopular',
  'https://www.youtube.com/feeds/videos.xml?channel_id=UCF0uVdsI8ilkQ4FgY3FhVg',
  'https://www.youtube.com/',
]){
  const rr=await get(u);
  console.log('  '+u.slice(8,70).padEnd(64)+' status='+rr.s+' len='+rr.body.length+' '+rr.body.slice(0,60).replace(/\s+/g,' '));
}

console.log('\n=== 抖音热榜 ===');
for(const [n,u,h] of [
  ['抖音web热榜','https://www.douyin.com/aweme/v1/web/hot/search/list/?device_platform=webapp&aid=6383&channel=channel_pc_web&detail_list=1',{Referer:'https://www.douyin.com/'}],
  ['抖音iesdouyin热词','https://www.iesdouyin.com/web/api/v2/hotsearch/billboard/word/',{Referer:'https://www.douyin.com/'}],
  ['抖音iesdouyin作品','https://www.iesdouyin.com/web/api/v2/hotsearch/billboard/aweme/',{Referer:'https://www.douyin.com/'}],
  ['抖音热榜页','https://www.douyin.com/hot',{Referer:'https://www.douyin.com/'}],
]){
  const rr=await get(u,h);
  console.log('  ['+n+'] status='+rr.s+' len='+rr.body.length+' '+rr.body.slice(0,110).replace(/\s+/g,' '));
}

console.log('\n=== TikTok 热门 ===');
for(const [n,u,h] of [
  ['TikTok explore item_list','https://www.tiktok.com/api/explore/item_list/?WebIdLastTime=1&aid=1988&count=30',{Referer:'https://www.tiktok.com/'}],
  ['TikTok Creative Center','https://ads.tiktok.com/business/creativecenter/inspiration/popular/hashtag/pc/en?period=7',{Referer:'https://ads.tiktok.com/'}],
  ['TikTok tag API','https://www.tiktok.com/api/explore/item_list/?aid=1988&app_language=zh-Hant&region=HK&count=20',{Referer:'https://www.tiktok.com/'}],
]){
  const rr=await get(u,h);
  console.log('  ['+n+'] status='+rr.s+' len='+rr.body.length+' '+rr.body.slice(0,110).replace(/\s+/g,' '));
}
