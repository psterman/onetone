/* 临时探针 14：猫眼 comingList（即将上映）完整结构 + 找「正在放映」入口 */
const https = require('node:https');
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

function get(url) {
  return new Promise((resolve) => {
    const req = https.get(url, { headers: { 'User-Agent': UA, Referer: 'https://m.maoyan.com/', Accept: '*/*' } }, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { body += c; });
      res.on('end', () => resolve({ status: res.statusCode, body }));
    });
    req.on('error', (e) => resolve({ status: 0, body: '', err: e.message }));
    req.setTimeout(20000, () => { try { req.destroy(); } catch { /* ignore */ } });
  });
}

(async () => {
  const r = await get('https://m.maoyan.com/ajax/comingList?token=&ci=1');
  const j = JSON.parse(r.body);
  console.log('顶层 key: ' + Object.keys(j).join(', '));
  const c = j.coming || [];
  console.log(`coming ${c.length} 条`);
  console.log('元素字段: ' + Object.keys(c[0] || {}).join(', '));
  for (const m of c.slice(0, 8)) {
    console.log(`  ${m.nm} | rt=${m.rt || ''} | globalReleased=${m.globalReleased} | preShow=${m.preShow} | wish=${m.wish} | img=${String(m.img).slice(0, 60)}`);
  }
  console.log(`\n带 img 的: ${c.filter((x) => x.img).length}/${c.length}`);
  console.log(`globalReleased=false 的: ${c.filter((x) => x.globalReleased === false).length}`);
  console.log(`comingTitle 样例: ${c.slice(0, 4).map((x) => x.comingTitle).join(' | ')}`);

  console.log('\n--- 找「正在放映」入口 ---');
  for (const u of [
    'https://m.maoyan.com/ajax/onshowList?token=&ci=1',
    'https://m.maoyan.com/ajax/showingList?token=&ci=1',
    'https://m.maoyan.com/ajax/movieList?token=&ci=1&index=onshow',
    'https://m.maoyan.com/ajax/nowShowingList?token=&ci=1',
    'https://m.maoyan.com/ajax/hotList?token=&ci=1',
  ]) {
    const rr = await get(u);
    let head = rr.body.slice(0, 150).replace(/\s+/g, ' ');
    let n = '';
    try { const jj = JSON.parse(rr.body); n = ' · keys=' + Object.keys(jj).join(','); } catch (e) { /* ignore */ }
    console.log(`${u.replace('https://m.maoyan.com', '')} → HTTP ${rr.status} · ${rr.body.length}B${n}`);
    if (rr.status === 200 && rr.body.length < 30000) console.log('   ' + head);
  }
})();
