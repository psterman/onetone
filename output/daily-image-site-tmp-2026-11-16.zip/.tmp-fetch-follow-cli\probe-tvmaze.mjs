/** 临时探针 4：/schedule/full 的真实结构（language 字段？_embedded.show？） */
const url = process.argv[2] || 'https://api.tvmaze.com/schedule/full?date=2026-11-16';
const t0 = Date.now();
const res = await fetch(url, {
  headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36' },
});
const buf = Buffer.from(await res.arrayBuffer());
console.log('status', res.status, 'bytes', buf.length, 'ms', Date.now() - t0);
const arr = JSON.parse(buf.toString('utf8'));
console.log('条目数', arr.length);

const days = new Map();
for (const e of arr) days.set(e.airdate, (days.get(e.airdate) || 0) + 1);
console.log('airdate 分布:', [...days.entries()].sort().map(([d, n]) => `${d}=${n}`).join(' '));

const target = '2026-11-16';
const same = arr.filter((e) => e.airdate === target);
console.log(`\n${target} 条数 = ${same.length}`);

console.log('\n=== 第 1 条（顶层字段 + _embedded.show 字段） ===');
const e = same[0];
console.log('顶层:', JSON.stringify(Object.keys(e)));
console.log('airdate/airtime/airstamp/season/number/name:', e.airdate, e.airtime, e.airstamp, e.season, e.number, JSON.stringify(e.name));
console.log('show 字段:', JSON.stringify(Object.keys(e._embedded.show)));
console.log('show.language =', JSON.stringify(e._embedded.show.language));
console.log('show.type =', JSON.stringify(e._embedded.show.type));
console.log('show.webChannel =', JSON.stringify(e._embedded.show.webChannel));
console.log('show.network =', JSON.stringify(e._embedded.show.network));
console.log('show.officialSite =', JSON.stringify(e._embedded.show.officialSite));
console.log('show.url =', JSON.stringify(e._embedded.show.url));
console.log('show.image =', JSON.stringify(e._embedded.show.image));

console.log('\n=== 频道分布（webChannel 优先，其次 network） ===');
const chan = new Map();
const lang = new Map();
const seenShow = new Set();
for (const x of same) {
  const s = x._embedded.show;
  const raw = s.webChannel ? s.webChannel.name : s.network ? s.network.name : '';
  chan.set(raw, (chan.get(raw) || 0) + 1);
  lang.set(String(s.language || '(none)'), (lang.get(String(s.language || '(none)')) || 0) + 1);
  seenShow.add(s.id);
}
console.log('去重剧数 =', seenShow.size);
console.log('频道:', [...chan.entries()].sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k}=${v}`).join(' '));
console.log('语言:', [...lang.entries()].sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k}=${v}`).join(' '));

console.log('\n=== 类型分布 ===');
const types = new Map();
for (const x of same) types.set(String(x._embedded.show.type || '(none)'), (types.get(String(x._embedded.show.type || '(none)')) || 0) + 1);
console.log(' ', [...types.entries()].sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k}=${v}`).join(' '));

console.log('\n=== 官方站点是 http:// 的比例 ===');
let http = 0, total = 0;
for (const x of same) { total++; const u = x._embedded.show.officialSite || ''; if (u.startsWith('http://')) http++; }
console.log(`  ${http}/${total}`);
