/** 临时探针 3：页面里有没有「按类型分组」的模块 / 逐条类型标记 */
import https from 'node:https';

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
  '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

function once(u, depth = 0) {
  return new Promise((resolve) => {
    const req = https.get(
      u,
      { headers: { 'User-Agent': UA, Accept: '*/*', 'Accept-Language': 'zh-CN,zh;q=0.9' } },
      (res) => {
        if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && depth < 6) {
          res.resume();
          once(new URL(res.headers.location, u).href, depth + 1).then(resolve);
          return;
        }
        let text = '';
        res.setEncoding('utf8');
        res.on('data', (c) => { text += c; });
        res.on('end', () => resolve({ status: res.statusCode, text, url: u }));
      },
    );
    req.on('error', (e) => resolve({ status: 0, text: '', url: u, error: e.message }));
    req.setTimeout(30000, () => { try { req.destroy(); } catch { /* ignore */ } });
  });
}

const r = await once(process.argv[2] || 'https://www.douban.com/location/beijing/events');
const html = r.text;

console.log('=== 侧栏模块 event-mod / aside 附近 ===');
const i = html.indexOf('event-mod');
if (i >= 0) console.log(html.slice(Math.max(0, i - 400), i + 2500));

console.log('\n=== 所有 event/<id> 链接（去重）+ 后面 120 字 ===');
const seen = new Set();
for (const m of html.matchAll(/href="(https:\/\/www\.douban\.com\/event\/\d+\/)"[^>]*title="([^"]*)"/g)) {
  if (seen.has(m[1])) continue;
  seen.add(m[1]);
  console.log(' ', m[1], '|', m[2].slice(0, 30), '| 后文:', JSON.stringify(html.slice(m.index + m[0].length, m.index + m[0].length + 120).replace(/\s+/g, ' ')));
}

console.log('\n=== 「正在热演」/「热门」等模块标题 ===');
for (const m of html.matchAll(/class="hd"[^>]*>([\s\S]{0,200}?)<\/h[23]>/g)) {
  console.log(' ', JSON.stringify(m[1].replace(/\s+/g, ' ').trim()));
}

console.log('\n=== 顶层 h2/h3/h4 全量（含 class）===');
for (const m of html.matchAll(/<(h[1-6])([^>]*)>([\s\S]{0,200}?)<\/\1>/g)) {
  console.log(' ', m[1], m[2].trim(), '=>', JSON.stringify(m[3].replace(/\s+/g, ' ').trim()));
}
