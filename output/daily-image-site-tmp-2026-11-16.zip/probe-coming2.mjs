﻿import https from 'node:https';
function get(url, headers={}) {
  return new Promise((res)=>{
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','Accept':'text/html,*/*','Accept-Language':'zh-CN,zh;q=0.9'},headers)},r=>{
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(20000,()=>{try{req.destroy();}catch(e){} res({s:0,body:'TIMEOUT'})});
  });
}
const r=await get('https://movie.douban.com/coming',{Referer:'https://movie.douban.com/'});
const b=r.body;
const ti=b.indexOf('coming_list');
console.log('coming_list 位置='+ti);
console.log('--- 表格片段 ---');
console.log(b.slice(ti-200, ti+2600).replace(/\n\s*\n/g,'\n'));
