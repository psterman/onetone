﻿import https from 'node:https';
function req(url, method='GET', headers={}, body=null) {
  return new Promise((res)=>{
    const h=Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)','Accept':'*/*'},headers);
    const r=https.request(url,{method,headers:h},(resp)=>{
      let d='';resp.on('data',c=>d+=c);resp.on('end',()=>res({s:resp.statusCode,ct:resp.headers['content-type'],body:d}));
    });
    r.on('error',e=>res({s:0,body:'ERR '+e.message}));
    r.setTimeout(25000,()=>{r.destroy();res({s:0,body:'TIMEOUT'})});
    if(body) r.write(body);
    r.end();
  });
}
const GQL=(q,v)=>JSON.stringify({query:q,variables:v});
const JH={'Content-Type':'application/json','X-Client-Id':'justwatch','Origin':'https://www.justwatch.com','Referer':'https://www.justwatch.com/'};

console.log('=== A. JustWatch introspection ===');
let r=await req('https://apis.justwatch.com/graphql','POST',JH,GQL('{ __schema { queryType { fields { name args { name type { name kind ofType { name } } } } } } }'));
if(r.s===200){
  try{
    const j=JSON.parse(r.body);
    const f=(j.data&&j.data.__schema&&j.data.__schema.queryType.fields)||[];
    console.log('Query 字段('+f.length+'): '+f.map(x=>x.name).join(', '));
    for(const want of ['newTitles','searchTitles','packages','episodes']){
      const hit=f.find(x=>x.name===want);
      if(hit) console.log('  '+want+' args: '+hit.args.map(a=>a.name+':'+(a.type.name||(a.type.ofType&&a.type.ofType.name)||'?')).join(', '));
    }
  }catch(e){ console.log('parse fail: '+r.body.slice(0,300)); }
} else { console.log('status='+r.s+' '+r.body.slice(0,300)); }

console.log('\n=== B. JustWatch packages（看平台 id） ===');
r=await req('https://apis.justwatch.com/graphql','POST',JH,GQL('query($c:Country!){ packages(country:$c){ edges { node { id technicalName name } } } }',{c:'CN'}));
console.log('status='+r.s+' '+(r.s===200?r.body.slice(0,400):r.body.slice(0,200)));

console.log('\n=== C. JustWatch newTitles ===');
r=await req('https://apis.justwatch.com/graphql','POST',JH,GQL('query($c:Country!,$l:Language!,$f:Int!){ newTitles(first:$f,country:$c,language:$l){ edges { node { id title { id titleText { text } releaseYear } } } } }',{c:'CN',l:'ZH',f:5}));
console.log('status='+r.s+' '+(r.s===200?r.body.slice(0,500):r.body.slice(0,250)));
