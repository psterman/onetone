﻿import https from 'node:https';
function post(q,v){
  return new Promise((res)=>{
    const body=JSON.stringify({query:q,variables:v});
    const r=https.request('https://apis.justwatch.com/graphql',{method:'POST',headers:{'Content-Type':'application/json','X-Client-Id':'justwatch','Origin':'https://www.justwatch.com','Referer':'https://www.justwatch.com/','User-Agent':'Mozilla/5.0','Content-Length':Buffer.byteLength(body)}},(resp)=>{
      let d='';resp.on('data',c=>d+=c);resp.on('end',()=>res({s:resp.statusCode,body:d}));
    });
    r.on('error',e=>res({s:0,body:'ERR '+e.message}));
    r.setTimeout(25000,()=>{req_destroy(r);res({s:0,body:'TIMEOUT'})});
    r.write(body); r.end();
  });
}
function req_destroy(r){ try{r.destroy();}catch(e){} }
const JH={'Content-Type':'application/json','X-Client-Id':'justwatch','Origin':'https://www.justwatch.com','Referer':'https://www.justwatch.com/'};

console.log('=== A. Title 接口字段（非法=没报错的即合法） ===');
const C=['id','titleText','title','name','releaseYear','releaseDate','originalTitleText','contentRating','productionStatus','posterUrl','imageUrl','poster','mainPoster','shortDescription','description','genres','countries','episodes','seasons','slug','objectType'];
let r=await post('query($c:Country!){ newTitles(first:1,country:$c){ edges { node { id ... on Title { '+C.join(' ')+' } } } } }',{c:'HK'});
try{ const j=JSON.parse(r.body); const bad=(j.errors||[]).map(e=>(e.message.match(/field "([^"]+)"/)||[])[1]).filter(Boolean);
  console.log('   合法: '+JSON.stringify(C.filter(x=>!bad.includes(x))));
  console.log('   非法: '+JSON.stringify(bad));
  const other=(j.errors||[]).filter(e=>!e.message.startsWith('Cannot query field')).map(e=>e.message);
  if(other.length) console.log('   其他: '+JSON.stringify(other).slice(0,300));
  if(j.data) console.log('   DATA: '+JSON.stringify(j.data).slice(0,900));
}catch(e){ console.log(r.body.slice(0,400)); }

console.log('\n=== B. newTitles 能否按平台过滤（试参数名） ===');
for(const arg of ['package','packageIds','includeStreamingPackages','contentType','genre','excludeStreamingPackages']){
  const rr=await post('query($c:Country!){ newTitles(first:1,country:$c,'+arg+':"netflix"){ edges { node { id } } } }',{c:'HK'});
  const msg=(rr.body.match(/"message":"([^"]+)"/)||[])[1]||'OK';
  console.log('   '+arg+' -> '+(msg.startsWith('Unknown argument')?'✗ 不存在':msg.slice(0,120)));
}
