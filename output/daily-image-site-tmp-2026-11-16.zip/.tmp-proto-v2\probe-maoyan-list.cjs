/* 临时探针 10：猫眼 movieOnInfoList 能不能给出带海报的「正在放映 + 即将上映」列表 */
const https = require('node:https');
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

function get(url) {
  return new Promise((resolve) => {
    const req = https.get(url, { headers: { 'User-Agent': UA, Referer: 'https://m.maoyan.com/', Accept: '*/*' } }, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { body += c; });
      res.on('end', () => resolve({ status: res.statusCode, body }));
    });
    req.on('error', (e) => resolve({ status: 0, body: '', err: e.message }));
    req.setTimeout(20000, () => { try { req.destroy(); } catch { /* ignore */ } });
  });
}

(async () => {
  const hot = await get('https://api.maoyan.com/mmdb/movie/v5/list/hot.json?ci=1');
  const hj = JSON.parse(hot.body);
  const ids = (hj.data && hj.data.movieIds) || [];
  console.log(`hot.json → ${(hj.data && hj.data.hot || []).length} 条 hot · ${ids.length} 个 movieIds`);

  const url = `https://m.maoyan.com/ajax/movieOnInfoList?token=&movieIds=${ids.slice(0, 40).join(',')}`;
  const r = await get(url);
  console.log(`movieOnInfoList → HTTP ${r.status} · ${r.body.length} 字节`);
  if (r.status !== 200) { console.log(r.body.slice(0, 300)); return; }
  let j;
  try { j = JSON.parse(r.body); } catch (e) { console.log('不是 JSON: ' + r.body.slice(0, 300)); return; }
  console.log('顶层 key: ' + Object.keys(j).join(', '));
  const list = j.movieList || (j.data && j.data.movieList) || [];
  console.log(`movieList ${Array.isArray(list) ? list.length : '(不是数组)'} 条`);
  if (Array.isArray(list) && list.length) {
    console.log('元素字段: ' + Object.keys(list[0]).join(', '));
    for (const m of list.slice(0, 6)) {
      const img = m.cover || m.img || m.poster || (m.imgList && m.imgList[0]) || '';
      console.log(`  ${m.name || m.title || '?'} | ${m.releaseDate || m.rt || ''} | globalReleased=${m.globalReleased} | ${String(img).slice(0, 80)}`);
    }
  }
})();
