﻿import https from 'node:https';
function get(url, headers={}, depth=0) {
  return new Promise((res)=>{
    if(depth>4) return res({s:0,body:'TOO_MANY_REDIRECT'});
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)','Accept':'text/html,*/*'},headers)},r=>{
      if([301,302,303,307,308].includes(r.statusCode) && r.headers.location){
        return get(new URL(r.headers.location,url).href, headers, depth+1).then(x=>res({...x,chain:(x.chain||[]).concat(url+' -> '+r.headers.location)}));
      }
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(25000,()=>{req.destroy();res({s:0,body:'ERR/TIMEOUT '+e})});
  });
}
const slugs=['beijing','shanghai','guangzhou','shenzhen','hangzhou','chengdu','wuhan','nanjing','chongqing','xian','suzhou','tianjin'];
console.log('=== 各城市：重定向目标 + 区级链接数 ===');
for(const s of slugs){
  const r=await get('https://www.douban.com/location/'+s+'/events',{Referer:'https://www.douban.com/location/'+s+'/'});
  const target=(r.chain&&r.chain.length)?r.chain[r.chain.length-1].split(' -> ')[1]:'(无重定向)';
  const ds=[...new Set((r.body.match(/events\/week-all-(\d+)"[^>]*>\s*([^<]{1,14})/g)||[]))];
  console.log('  '+s.padEnd(11)+' status='+String(r.s).padEnd(4)+' len='+String(r.body.length).padEnd(7)+' -> '+target.replace('https://','')+'  区='+ds.length+(ds.length?' ['+ds.slice(0,4).map(x=>x.split('>').pop().trim()).join(',')+']':''));
}
