﻿import https from 'node:https';
function get(url, headers={}, depth=0){
  return new Promise((res)=>{
    if(depth>5) return res({s:0,body:'REDIR'});
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','Accept':'text/html,application/json,*/*','Accept-Language':'zh-CN,zh;q=0.9'},headers)},r=>{
      if([301,302,303,307,308].includes(r.statusCode)&&r.headers.location){
        return get(new URL(r.headers.location,url).href,headers,depth+1).then(x=>res({...x,chain:(x.chain||[]).concat(r.headers.location)}));
      }
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(20000,()=>{try{req.destroy();}catch(e){} res({s:0,body:'TIMEOUT'})});
  });
}
console.log('=== A. 豆瓣「即将上映」候选路径 ===');
for(const u of ['https://movie.douban.com/cinema/coming','https://movie.douban.com/coming','https://movie.douban.com/cinema/coming?city=%E5%8C%97%E4%BA%AC','https://movie.douban.com/explore']){
  const r=await get(u,{Referer:'https://movie.douban.com/'});
  let o='status='+r.s+' len='+r.body.length+' t='+(r.body.match(/<title>([^<]*)<\/title>/)||[])[1];
  console.log('  '+u.replace('https://movie.douban.com','')+' -> '+o);
}
console.log('\n=== B. 猫眼扩量 / 移动端接口 ===');
for(const u of [
  'https://api.maoyan.com/mmdb/movie/v5/list/hot.json?ci=1&token=',
  'https://m.maoyan.com/ajax/movieOnInfoList?token=',
  'https://api.maoyan.com/mmdb/movie/v5/list/preview.json?ci=1',
  'https://api.maoyan.com/mmdb/movie/v5/list/hot.json?ci=1&movieIds=',
  'https://api.maoyan.com/mmdb/movie/v5/list/hot.json?ci=1&stids=',
]){
  const r=await get(u,{Referer:'https://www.maoyan.com/'});
  let o='status='+r.s+' len='+r.body.length+' '+r.body.slice(0,100).replace(/\s+/g,' ');
  try{ const j=JSON.parse(r.body); o+=' hot='+((j.data&&j.data.hot||[]).length)+' total='+(j.data&&j.data.total); }catch(e){}
  console.log('  '+u.replace('https://api.maoyan.com','').replace('https://m.maoyan.com','')+' -> '+o);
}
console.log('\n=== C. 猫眼 movieIds 参数能否换页 ===');
const base=await get('https://api.maoyan.com/mmdb/movie/v5/list/hot.json?ci=1',{Referer:'https://www.maoyan.com/'});
const j=JSON.parse(base.body);
console.log('  movieIds 字段: '+JSON.stringify(j.data.movieIds||j.data.stids||'').slice(0,200));
console.log('  total='+j.data.total+' hot.len='+j.data.hot.length);
const ids=(j.data.movieIds||'');
if(typeof ids==='string'&&ids.length){
  const r2=await get('https://api.maoyan.com/mmdb/movie/v5/list/hot.json?ci=1&movieIds='+ids,{Referer:'https://www.maoyan.com/'});
  let o='status='+r2.s+' len='+r2.body.length;
  try{ const k=JSON.parse(r2.body); o+=' hot='+((k.data&&k.data.hot||[]).length); }catch(e){}
  console.log('  带 movieIds -> '+o);
}
