﻿import https from 'node:https';
function get(url, headers={}) {
  return new Promise((res)=>{
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','Accept':'*/*','Accept-Language':'zh-CN,zh;q=0.9'},headers)},r=>{
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(25000,()=>{try{req.destroy();}catch(e){} res({s:0,body:'TIMEOUT'})});
  });
}
console.log('=== A. 猫眼分页/扩量参数 ===');
for(const q of ['ci=1&offset=12','ci=1&offset=40','ci=1&start=12','ci=1&page=2','ci=1&limit=50&offset=0','ci=1&count=50']){
  const r=await get('https://api.maoyan.com/mmdb/movie/v5/list/hot.json?'+q,{Referer:'https://www.maoyan.com/'});
  let o='status='+r.s+' len='+r.body.length;
  try{ const j=JSON.parse(r.body); const hot=j.data.hot||[];
    o+=' hot='+hot.length+' total='+j.data.total+' 首条nm='+(hot[0]&&hot[0].nm);
    const rel=hot.filter(h=>h.globalReleased===false).length;
    o+=' 未上映='+rel;
  }catch(e){ o+=' '+r.body.slice(0,60); }
  console.log('  ?'+q+' -> '+o);
}
console.log('\n=== B. 抖音非签名封面域名 ===');
const d=await get('https://www.douyin.com/aweme/v1/web/hot/search/list/?device_platform=webapp&aid=6383&channel=channel_pc_web&detail_list=1',{Referer:'https://www.douyin.com/'});
const j=JSON.parse(d.body); const cov=(j.data.word_list[0].word_cover||{}).url_list||[];
console.log('  原始域: '+cov.map(u=>u.match(/^https:\/\/([^/]+)/)[1]).join(', '));
if(cov[0]){
  const pathOnly=cov[0].replace(/^https:\/\/[^/]+/,'').replace(/\?.*$/,'');
  for(const host of ['p3.douyinpic.com','p3-sign.douyinpic.com','p26.douyinpic.com','p11.douyinpic.com']){
    const rr=await get('https://'+host+pathOnly,{Referer:'https://www.douyin.com/'});
    console.log('   ['+host+'] status='+rr.s+' len='+rr.body.length+' ct='+(rr.ct||'').slice(0,20));
  }
}
console.log('\n=== C. YouTube innertube（从页面取 key + context） ===');
const yt=await get('https://www.youtube.com/feed/trending',{Accept:'text/html'});
const keyM=yt.body.match(/"INNERTUBE_API_KEY":"([^"]+)"/);
const ctxM=yt.body.match(/"INNERTUBE_CONTEXT":(\{"client":\{.*?\}\})/);
console.log('  INNERTUBE_API_KEY='+(keyM?keyM[1].slice(0,12)+'…':'未找到'));
console.log('  有 INNERTUBE_CONTEXT='+!!ctxM);
if(keyM&&ctxM){
  let ctx=null; try{ ctx=JSON.parse(ctxM[1]); }catch(e){}
  console.log('  client 名='+(ctx&&ctx.client&&ctx.client.clientName)+' ver='+(ctx&&ctx.client&&ctx.client.clientVersion));
  const payload=JSON.stringify({context:ctx,browseId:'FEtrending'});
  const body=JSON.stringify({context:ctx.client,params:btoa('{"client":"WEB","originalUrl":"https://www.youtube.com/feed/trending"}')});
  // 正确用法：browseId=FEtrending 用 web client context
  const r2=await new Promise((res)=>{
    const data=JSON.stringify({context:ctx.client});
    const req=https.request('https://www.youtube.com/youtubei/v1/browse?key='+keyM[1]+'&prettyPrint=false',{method:'POST',headers:{'Content-Type':'application/json','User-Agent':'Mozilla/5.0','Origin':'https://www.youtube.com','Content-Length':Buffer.byteLength(data)},timeout:25000},(rp)=>{let dd='';rp.on('data',c=>dd+=c);rp.on('end',()=>res({s:rp.statusCode,body:dd}));});
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.write(data);req.end();
  });
  console.log('  innertube browse 缺 params status='+r2.s+' len='+r2.body.length+' '+r2.body.slice(0,160).replace(/\s+/g,' '));
  // 带正确 params（FEtrending 的 browseId 应为 FEwhat_to_watch）
  const params=Buffer.from('{"browseId":"FEwhat_to_watch"}').toString('base64');
  const data2=JSON.stringify({context:ctx.client,params});
  const r3=await new Promise((res)=>{
    const req=https.request('https://www.youtube.com/youtubei/v1/browse?key='+keyM[1]+'&prettyPrint=false',{method:'POST',headers:{'Content-Type':'application/json','User-Agent':'Mozilla/5.0','Origin':'https://www.youtube.com','Content-Length':Buffer.byteLength(data2)},timeout:25000},(rp)=>{let dd='';rp.on('data',c=>dd+=c);rp.on('end',()=>res({s:rp.statusCode,body:dd}));});
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.write(data2);req.end();
  });
  console.log('  innertube FEwhat_to_watch status='+r3.s+' len='+r3.body.length);
  if(r3.s===200){
    const vids=[...r3.body.matchAll(/"videoId":"([A-Za-z0-9_-]{11})"/g)].map(m=>m[1]);
    const tt=[...r3.body.matchAll(/"title":\{"runs":\[\{"text":"((?:[^"\\]|\\.){2,110})"/g)].map(m=>m[1]);
    console.log('   videoId 唯一数='+new Set(vids).size+' 标题数='+tt.length);
    console.log('   标题样例='+JSON.stringify(tt.slice(0,6)));
    const vc=[...r3.body.matchAll(/"viewCountText":\{"simpleText":"([^"]+)"/g)].map(m=>m[1]);
    console.log('   播放量='+JSON.stringify(vc.slice(0,6)));
    const ow=[...r3.body.matchAll(/"ownerText":\{"runs":\[\{"text":"([^"]+)"/g)].map(m=>m[1]);
    console.log('   作者='+JSON.stringify(ow.slice(0,6)));
  } else console.log('   '+r3.body.slice(0,200));
}
