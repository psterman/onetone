/* 临时探针 8：猫眼图床（qiniu 系）能不能用 imageMogr2 取小图 */
const https = require('node:https');
const BASE = 'https://p0.pipi.cn/mediaplus/friday_image_fe/e429589aea4b81e327392a78653c491a0764b.jpg';
const VARIANTS = [
  ['原图（现用）', '?imageMogr2/quality/80'],
  ['quality 80 + 缩到 200', '?imageMogr2/thumbnail/!200x200/quality/80'],
  ['quality 80 + 缩到 160', '?imageMogr2/thumbnail/!160x160/quality/80'],
  ['imageView2 w=200', '?imageView2/2/w/200'],
  ['imageMogr2 裁 200x200', '?imageMogr2/thumbnail/200x200^/gravity/center/crop/200x200/quality/80'],
  ['只要 quality', '?imageMogr2/quality/60'],
];

function probe(name, q) {
  return new Promise((resolve) => {
    const url = BASE + q;
    const req = https.get(url, { headers: { 'User-Agent': 'Mozilla/5.0' } }, (res) => {
      let n = 0;
      res.on('data', (c) => { n += c.length; });
      res.on('end', () => {
        console.log(`${name.padEnd(24)} HTTP ${res.statusCode} · ${String(res.headers['content-type']).padEnd(12)} ${(n / 1024).toFixed(1)} KB`);
        resolve();
      });
    });
    req.on('error', (e) => { console.log(`${name}: ERR ${e.message}`); resolve(); });
    req.setTimeout(15000, () => { try { req.destroy(); } catch { /* ignore */ } });
  });
}

(async () => {
  for (const [n, q] of VARIANTS) await probe(n, q);
})();
