/* 临时探针 5：/schedule/full 按精确 airdate 过滤后的剧集/频道/语言分布 */
const DAY = '2026-11-17';

async function main() {
  const j = await fetch(`https://api.tvmaze.com/schedule/full?date=${DAY}`).then((r) => r.json());

  for (const target of ['2026-11-16', '2026-11-17', '2026-11-18']) {
    const eps = j.filter((e) => e.airdate === target);
    const shows = new Map();
    for (const e of eps) {
      const s = (e._embedded && e._embedded.show) || e.show;
      if (s && !shows.has(s.id)) shows.set(s.id, s);
    }
    const web = new Map();
    const net = new Map();
    const lang = new Map();
    for (const s of shows.values()) {
      if (s.webChannel && s.webChannel.name) web.set(s.webChannel.name, (web.get(s.webChannel.name) || 0) + 1);
      else if (s.network && s.network.name) net.set(s.network.name, (net.get(s.network.name) || 0) + 1);
      const l = s.language || '(none)';
      lang.set(l, (lang.get(l) || 0) + 1);
    }
    console.log(`\n=== ${target} ===`);
    console.log(`集数 ${eps.length} · 去重剧 ${shows.size} · webChannel ${web.size} 种 / network ${net.size} 种`);
    console.log('webChannel: ' + [...web.entries()].sort((a, b) => b[1] - a[1]).slice(0, 14)
      .map(([k, v]) => `${k}=${v}`).join(' | '));
    console.log('network top8: ' + [...net.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8)
      .map(([k, v]) => `${k}=${v}`).join(' | '));
    console.log('语言: ' + [...lang.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8)
      .map(([k, v]) => `${k}=${v}`).join(' | '));
  }
}

main().catch((e) => { console.error(e); process.exit(1); });
