@echo off
cd /d "E:\voice-pilot\daily-image-site\tools\.tmp-proto-v2"
"C:\Users\pstem\AppData\Local\Programs\Python\Python312\python.exe" -m http.server 8808 --bind 127.0.0.1
