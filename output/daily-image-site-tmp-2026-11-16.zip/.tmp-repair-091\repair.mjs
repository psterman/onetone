#!/usr/bin/env node
/* 定点修复：2026-11-14 见她 tab 里 962bbae53f_091.webp 是 0 字节。
   用与 build.mjs 完全相同的参数从源图重转，**只写本地母本，不上传**。
   上传到 R2 需要用户确认，所以这一步单独做。 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';

const FFMPEG =
  'C:\\Users\\pstem\\AppData\\Local\\Microsoft\\WinGet\\Packages\\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\\ffmpeg-9.0.2-full_build\\bin\\ffmpeg.exe';
const FFPROBE =
  'C:\\Users\\pstem\\AppData\\Local\\Microsoft\\WinGet\\Packages\\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\\ffmpeg-9.0.2-full_build\\bin\\ffprobe.exe';

const ROOT = 'E:\\voice-pilot\\daily-image-site';
const SRC = 'D:\\daily-images\\src\\2026-11-14\\见她';
const DEST_DIR = 'D:\\daily-images\\r2\\2026-11-14\\jianshe';
const ID = '091';
const TAB_KEY = 'jianshe';
const QUALITY = 80; // 见她 tab 的 quality
const FULL_MAX_W = 1080;
const WEBP_COMPRESSION = 6;

const salt = fs.readFileSync(path.join(ROOT, '.img-salt'), 'utf8').trim();
const files = fs
  .readdirSync(SRC, { withFileTypes: true })
  .filter((d) => d.isFile() && /\.(jpe?g|png|gif|webp|bmp)$/i.test(d.name))
  .map((d) => d.name)
  .sort((a, b) => a.localeCompare(b, 'zh-CN', { numeric: true }));
const name = files[Number(ID) - 1];
const src = path.join(SRC, name);

const st = fs.statSync(src);
const buf = fs.readFileSync(src);
const h = crypto.createHash('sha256');
h.update(buf.subarray(0, 65536));
h.update(String(st.size));
const contentHash = h.digest('hex').slice(0, 16);
const nonce = crypto
  .createHash('sha256')
  .update(`${salt}|${TAB_KEY}|${ID}|${contentHash}`)
  .digest('hex')
  .slice(0, 10);

const dest = path.join(DEST_DIR, `${nonce}_${ID}.webp`);
console.log('源图      =', name, `(${st.size} B)`);
console.log('目标产物  =', dest);
if (path.basename(dest) !== '962bbae53f_091.webp') {
  console.error('✗ 随机段对不上，拒绝动手');
  process.exit(1);
}

// 尺寸：和 build.mjs 一样 —— ffprobe 读原图，按宽度上限等比缩放
const probe = spawnSync(
  FFPROBE,
  ['-v', 'quiet', '-select_streams', 'v:0', '-show_entries', 'stream=width,height', '-of', 'csv=p=0:s=x', src],
  { encoding: 'utf8' },
);
const [sw, sh] = String(probe.stdout).trim().split('x').map(Number);
if (!sw || !sh) {
  console.error('✗ ffprobe 读不出尺寸');
  process.exit(1);
}
const f = Math.min(1, FULL_MAX_W / sw);
const W = Math.max(1, Math.round(sw * f));
const H = Math.max(1, Math.round(sh * f));
console.log(`原图 ${sw}x${sh} -> 产物 ${W}x${H}（等比，不裁不拉）`);

/* 临时文件必须仍以 .webp 结尾 —— ffmpeg 靠扩展名挑封装器，
   写成 .repair-tmp 会报「Unable to choose an output format」。 */
const tmp = dest + '.repair.webp';
const args = [
  '-y', '-loglevel', 'error',
  '-i', src,
  '-vf', `scale=${W}:${H}:flags=lanczos`,
  '-c:v', 'libwebp',
  '-quality', String(QUALITY),
  '-compression_level', String(WEBP_COMPRESSION),
  '-frames:v', '1',
  tmp,
];
const r = spawnSync(FFMPEG, args, { encoding: 'utf8' });
if (r.status !== 0) {
  console.error('✗ ffmpeg 失败：', r.stderr || r.stdout);
  process.exit(1);
}

// 自检：必须是有效 WebP（非空 + 文件头能读出尺寸）
const outSt = fs.statSync(tmp);
console.log('新产物大小 =', outSt.size, 'B');
if (outSt.size === 0) {
  console.error('✗ 新产物是 0 字节');
  process.exit(1);
}
const outBuf = fs.readFileSync(tmp);
if (outBuf.subarray(0, 4).toString('ascii') !== 'RIFF' || outBuf.subarray(8, 12).toString('ascii') !== 'WEBP') {
  console.error('✗ 新产物不是 WebP');
  process.exit(1);
}
const probe2 = spawnSync(
  FFPROBE,
  ['-v', 'quiet', '-select_streams', 'v:0', '-show_entries', 'stream=width,height', '-of', 'csv=p=0:s=x', tmp],
  { encoding: 'utf8' },
);
console.log('新产物 ffprobe 尺寸 =', String(probe2.stdout).trim());

// 覆盖那个 0 字节文件（Windows 上 rename 会替换目标）
fs.renameSync(tmp, dest);
const final = fs.statSync(dest);
console.log(`✓ 已就地修复：${dest} = ${final.size} B`);
