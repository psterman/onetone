/** 临时复现：CLI 子进程卡在哪一步 */
import http from 'node:http';
import { spawn } from 'node:child_process';

const ROOT = 'E:/voice-pilot/daily-image-site';
const path = { join: (...a) => a.join('/').replace(/\/+/g, '/') };

const srv = http.createServer((req, res) => {
  const u = String(req.url);
  console.log('  [srv]', u);
  if (u.startsWith('/schedule/full')) {
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify([{ airdate: '2026-11-16', name: 'x', _embedded: { show: { id: 1, name: 'S', type: 'Scripted', language: 'English', webChannel: { name: 'Netflix' } } } }]));
    return;
  }
  if (u.startsWith('/pgc/web/timeline')) {
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ code: 0, result: [] }));
    return;
  }
  if (u.startsWith('/j/search_subjects')) {
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ subjects: [] }));
    return;
  }
  if (u.includes('/img3.doubanio.com/')) {
    res.writeHead(200, { 'content-type': 'image/jpeg' });
    res.end(Buffer.alloc(1024, 5));
    return;
  }
  if (u.includes('/events')) {
    res.writeHead(200, { 'content-type': 'text/html' });
    res.end('<ul class="events-list"><li class="list-entry" itemscope><div class="info"><div class="title"><a href="https://www.douban.com/event/1/" title="T"><span itemprop="summary">T</span></a></div></div></li></ul>');
    return;
  }
  res.writeHead(404);
  res.end('nope');
});

srv.listen(0, '127.0.0.1', () => {
  const base = `http://127.0.0.1:${srv.address().port}`;
  console.log('base', base);
  const env = {
    ...process.env,
    FETCH_FOLLOW_TVMAZE_BASE: base,
    FETCH_FOLLOW_DOUBAN_BASE: base,
    FETCH_FOLLOW_BILI_BASE: base,
    FETCH_FOLLOW_DOUBAN_MOVIE_BASE: base,
    FETCH_FOLLOW_CITY_DELAY_MS: '0',
    FETCH_FOLLOW_COVER_DELAY_MS: '0',
    IMAGE_ROOT: path.join(ROOT, 'tools/.tmp-fetch-follow-cli/repro'),
  };
  const child = spawn(process.execPath, [path.join(ROOT, 'tools/fetch-follow.mjs'), '--date', '2099-01-01'], { env, encoding: 'utf8' });
  child.stdout.on('data', (d) => process.stdout.write('  [out] ' + d));
  child.stderr.on('data', (d) => process.stdout.write('  [err] ' + d));
  const timer = setTimeout(() => {
    console.log('!!! 20s 还没退出 —— 卡住了');
    process.exit(2);
  }, 20000);
  child.on('close', (code) => {
    clearTimeout(timer);
    console.log('child exit', code);
    srv.close();
    process.exit(0);
  });
});
