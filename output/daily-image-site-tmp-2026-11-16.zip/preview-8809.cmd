@echo off
cd /d "E:\voice-pilot\daily-image-site\tools\.tmp-v2-build\2026-11-16"
"C:\Users\pstem\AppData\Local\Programs\Python\Python312\python.exe" -m http.server 8809 --bind 127.0.0.1
