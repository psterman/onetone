﻿import https from 'node:https';
function post(q,v){
  return new Promise((res)=>{
    const body=JSON.stringify({query:q,variables:v});
    const r=https.request('https://apis.justwatch.com/graphql',{method:'POST',headers:{'Content-Type':'application/json','X-Client-Id':'justwatch','Origin':'https://www.justwatch.com','Referer':'https://www.justwatch.com/','User-Agent':'Mozilla/5.0','Content-Length':Buffer.byteLength(body)}},(resp)=>{
      let d='';resp.on('data',c=>d+=c);resp.on('end',()=>res({s:resp.statusCode,body:d}));
    });
    r.on('error',e=>res({s:0,body:'ERR '+e.message}));
    r.setTimeout(25000,()=>{r.destroy();res({s:0,body:'TIMEOUT'})});
    r.write(body); r.end();
  });
}
const JH={'Content-Type':'application/json','X-Client-Id':'justwatch','Origin':'https://www.justwatch.com','Referer':'https://www.justwatch.com/'};
console.log('=== A. 正确的 inline fragment 探测 ===');
for(const frag of ['Title','Content','Movie','ShowSeason','Show','Season','TitleBase']){
  const rr=await post('query($c:Country!){ newTitles(first:1,country:$c){ edges { node { id ... on '+frag+' { id } } } } }',{c:'HK'});
  let s=rr.s===200?'OK(片段类型存在)':((rr.body.match(/"message":"([^"]+)"/)||[])[1]||rr.body.slice(0,120));
  console.log('   ... on '+frag+' -> '+s);
}
console.log('\n=== B. searchTitles 的 source 取值 ===');
for(const src of ['JUSTWATCH','justwatch','ZH','HK','ALL','']){
  const rr=await post('query($c:Country!){ searchTitles(country:$c,source:"'+src+'",first:2){ edges { node { id objectType } } } }',{c:'HK'});
  let s=rr.s===200?rr.body.slice(0,260):((rr.body.match(/"message":"([^"]+)"/)||[])[1]||'').slice(0,140);
  console.log('   source="'+src+'" status='+rr.s+' '+s);
}
console.log('\n=== C. searchTitles node 的字段（title/poster 在不在） ===');
const C=['id','objectType','titleText','title','name','releaseYear','posterUrl','imageUrl','poster','mainPoster','ids','contentRatings','originalTitleText','shortDescription','productionStatus','genres','countries'];
const rr=await post('query($c:Country!){ searchTitles(country:$c,source:"JUSTWATCH",first:1){ edges { node { '+C.join(' ')+' } } } }',{c:'HK'});
try{ const j=JSON.parse(rr.body); const bad=(j.errors||[]).map(e=>(e.message.match(/field "([^"]+)"/)||[])[1]).filter(Boolean);
  console.log('   合法: '+JSON.stringify(C.filter(x=>!bad.includes(x)))+' 非法: '+JSON.stringify(bad));
  if(j.data) console.log('   DATA: '+JSON.stringify(j.data).slice(0,400));
}catch(e){ console.log(rr.body.slice(0,300)); }
