const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

// 1) Netease
{
  const r = await fetch("https://music.163.com/api/playlist/detail?id=3778678", { headers: { "User-Agent": UA } });
  const t = await r.text();
  console.log("[netease] status", r.status, "len", t.length);
  const j = JSON.parse(t);
  const tracks = j && j.result && j.result.tracks;
  console.log("[netease] tracks", tracks ? tracks.length : "NULL", "code=", j.code);
  if (tracks && tracks.length) {
    const x = tracks[0];
    console.log("[netease] sample keys:", Object.keys(x).join(","));
    console.log("[netease] t0:", JSON.stringify({id:x.id,name:x.name,artists:(x.artists||[]).map(a=>a.name),album:x.album&&x.album.name,pic:x.album&&x.album.picUrl,duration:x.duration}, null, 1));
    const https = tracks.filter(t2 => t2.album && String(t2.album.picUrl||"").startsWith("https://")).length;
    console.log("[netease] picUrl already https:", https, "/", tracks.length);
  }
}

// 2) Bilibili
{
  const r = await fetch("https://api.bilibili.com/x/web-interface/popular?ps=50&pn=1", { headers: { "User-Agent": UA, Referer: "https://www.bilibili.com/" } });
  const t = await r.text();
  console.log("\n[bili] status", r.status, "len", t.length);
  const j = JSON.parse(t);
  console.log("[bili] code", j.code, "message", j.message, "list", j.data && j.data.list ? j.data.list.length : "NULL");
  if (j.data && j.data.list && j.data.list.length) {
    const x = j.data.list[0];
    console.log("[bili] sample:", JSON.stringify({title:x.title,pic:x.pic,bvid:x.bvid,owner:x.owner&&x.owner.name,view:x.stat&&x.stat.view,duration:x.duration,short_link_v2:x.short_link_v2,short_link:x.short_link}, null, 1));
    const https = j.data.list.filter(y => String(y.pic||"").startsWith("https://")).length;
    console.log("[bili] pic already https:", https, "/", j.data.list.length);
  }
}

// 3) Douban cover hotlink
{
  const base = "https://img3.doubanio.com/view/photo/";
  for (const v of ["s_ratio_poster", "m_ratio_poster", "l_ratio_poster"]) {
    const u = base + v + "/public/p2936346968.jpg";
    const r = await fetch(u, { headers: { "User-Agent": UA, Referer: "https://movie.douban.com/" } });
    console.log("[douban-img]", v, "status", r.status, "ct", r.headers.get("content-type"));
  }
  const u2 = "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2936346968.jpg";
  const r2 = await fetch(u2, { headers: { "User-Agent": UA } });
  console.log("[douban-img] no-referer status", r2.status);
}