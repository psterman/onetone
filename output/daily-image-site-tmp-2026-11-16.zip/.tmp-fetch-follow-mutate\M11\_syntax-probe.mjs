#!/usr/bin/env node
/**
 * 追更抓取（剧集播出表 + 城市演艺活动）—— 构建期抓外部源，写 JSON 给 build.mjs 读。
 *
 * 零依赖：只用 Node 内置 API（global fetch / fs / path / url）。
 *
 * 两个板块：
 *   1. 剧集更新（schedule）—— TVmaze 公开 API 的每日播出表（免费、无 key、合法开放）
 *      https://api.tvmaze.com/schedule?country=US&date=YYYY-MM-DD
 *      · 禁止用 /schedule/full（单日 11MB，太重）
 *      · country 实测每日条数：US≈570 CN≈85 JP≈62 KR≈21 HK≈9（按天浮动）
 *      · 抓「今天 + 明天」（--days 2），按 (airdate, airstamp) 升序
 *   2. 城市演艺活动（events）—— 豆瓣同城
 *      https://www.douban.com/location/<slug>/events   ← 必须带 Referer
 *
 * ⚠️ 只做**信息汇总**：不托管、不转码、不代理任何音视频。
 *    link 一律指向官方正版入口（show.officialSite）或豆瓣活动页；
 *    兜底通道的 link 一律指向豆瓣站内搜索 —— 站点上不会出现任何播放地址。
 *
 * 兜底通道（**默认关闭**）：
 *   读 tools/fetch-follow.local.json（文件不存在 = 整条通道关闭，不影响主流程）
 *   格式：{"fallbacks":[{"name":"<显示名>","url":"<列表页 URL>"}]}
 *   规矩：
 *     1) 只在主源对应板块失败时才启用（TVmaze 全挂 → 兜底填 schedule；豆瓣全城失败 → 兜底填 events）
 *     2) 只提取纯文本元数据（剧名 / 集数 / 日期），页面上所有 URL 一律丢弃
 *     3) link 统一填合法入口：https://search.douban.com/movie/subject_search?search_text=<标题>
 *     4) source = 配置里的 name；schedule 兜底 tag = 剧集更新，events 兜底 tag = 兜底
 *     5) 硬性自检：输出里出现 http:// 或 https://（豆瓣搜索链接除外）→ 直接 throw
 *
 * 用法：
 *   node tools/fetch-follow.mjs --date 2026-11-16              抓取并写文件
 *   node tools/fetch-follow.mjs --date 2026-11-16 --dry-run    只抓取并打印统计
 *   node tools/fetch-follow.mjs --help                         打印用法（exit 0）
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { SRC_LOCAL, srcSearchRoots } from './paths.mjs';

/** 顺手把路径解析也导出（别处要写/读同一个位置时不用再 import paths.mjs） */
export { SRC_LOCAL, srcSearchRoots };

const __dirname = path.dirname(fileURLToPath(import.meta.url));

/* ───────────────────────────── 常量 ───────────────────────────── */

/** 桌面 Chrome UA —— 豆瓣 / TVmaze 对非浏览器 UA 会挑食 */
export const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
  '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

/** 单次请求超时 20s */
export const HTTP_TIMEOUT_MS = 20000;

/** 失败重试 2 次，退避 1s / 3s（到境外链路会间歇 ECONNRESET） */
export const RETRY_BACKOFF_MS = [1000, 3000];

/** 总尝试次数 = 首次 + 重试 2 次 */
export const HTTP_ATTEMPTS = RETRY_BACKOFF_MS.length + 1;

export const SCHEDULE_SOURCE = 'TVmaze 播出表';
export const SCHEDULE_TAG = '剧集更新';
export const EVENTS_SOURCE = '豆瓣同城';
export const FALLBACK_EVENTS_TAG = '兜底';

/** 兜底 item 的唯一合法 link 前缀 */
export const DOUBAN_SEARCH_BASE = 'https://search.douban.com/movie/subject_search?search_text=';

/** 兜底输出里的 URL 探测器（自检用） */
const URL_RE = /https?:\/\//i;

/** 播出表抓哪些国家 */
export const COUNTRIES = ['US', 'CN', 'JP', 'KR', 'HK'];

/**
 * 只收「剧集」类型。
 *
 * 实测美国一天 81 条：Scripted 10 · News 37 · Talk Show 14 · Reality 13 ·
 * Game Show 3 · Documentary 2 · Sports 2 —— 不筛的话首页全是早间脱口秀。
 */
export const SERIES_TYPES = ['Scripted', 'Documentary'];

/** 已实测 200 的 12 个同城 slug（每个 11~15 条） */
export const CITIES = [
  { name: '北京', slug: 'beijing' },
  { name: '上海', slug: 'shanghai' },
  { name: '广州', slug: 'guangzhou' },
  { name: '深圳', slug: 'shenzhen' },
  { name: '杭州', slug: 'hangzhou' },
  { name: '成都', slug: 'chengdu' },
  { name: '武汉', slug: 'wuhan' },
  { name: '南京', slug: 'nanjing' },
  { name: '重庆', slug: 'chongqing' },
  { name: '西安', slug: 'xian' },
  { name: '苏州', slug: 'suzhou' },
  { name: '天津', slug: 'tianjin' },
];

/**
 * 源站基址。
 * 留 env 覆盖是为了让护栏能指向本机 fixture server（离线跑 CLI 用），
 * 默认值就是线上正式地址。
 */
const TVMAZE_BASE = String(process.env.FETCH_FOLLOW_TVMAZE_BASE || 'https://api.tvmaze.com').replace(/\/+$/, '');
const DOUBAN_BASE = String(process.env.FETCH_FOLLOW_DOUBAN_BASE || 'https://www.douban.com').replace(/\/+$/, '');

/** 兜底配置文件（不存在 = 通道关闭） */
export const FALLBACK_CONFIG_PATH = path.join(__dirname, 'fetch-follow.local.json');

/* ───────────────────────────── 小工具 ───────────────────────────── */

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function codePoint(n) {
  if (!Number.isFinite(n) || n < 0 || n > 0x10ffff) return '';
  try {
    return String.fromCodePoint(n);
  } catch {
    return '';
  }
}

/** 解 HTML 实体（&amp; 最后解，否则 &amp;lt; 会被解两次） */
function decodeEntities(s) {
  return String(s)
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => codePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, d) => codePoint(parseInt(d, 10)))
    .replace(/&nbsp;/gi, ' ')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&middot;/gi, '·')
    .replace(/&hellip;/gi, '…')
    .replace(/&mdash;/gi, '—')
    .replace(/&ldquo;|&rdquo;/gi, '"')
    .replace(/&lsquo;|&rsquo;/gi, "'")
    .replace(/&amp;/gi, '&');
}

/** 剥标签 + 压空白 */
function stripTags(s) {
  return String(s)
    .replace(/<[^>]*>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function textOf(html) {
  return stripTags(decodeEntities(html));
}

/** 校验 YYYY-MM-DD，且必须是真日子（2026-13-45 不算） */
export function isDate(s) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s || '').trim());
  if (!m) return false;
  const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
  return d.getUTCFullYear() === +m[1] && d.getUTCMonth() === +m[2] - 1 && d.getUTCDate() === +m[3];
}

/** 北京时区的今天（不能用本机时区 —— 差一天就是差一期） */
export function beijingToday() {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Shanghai',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(new Date());
  const get = (t) => (parts.find((p) => p.type === t) || { value: '' }).value;
  return `${get('year')}-${get('month')}-${get('day')}`;
}

/** 日期加天数（UTC 算，不受本机时区影响） */
export function addDays(date, n) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(date || ''));
  if (!m) return String(date || '');
  const t = Date.UTC(+m[1], +m[2] - 1, +m[3]) + Number(n || 0) * 86400000;
  return new Date(t).toISOString().slice(0, 10);
}

function errMsg(e) {
  return e && e.message ? String(e.message) : String(e);
}

/* ───────────────────────────── 网络层 ───────────────────────────── */

/** 网络层面的失败才值得重试（HTTP 4xx 是站点自己的回答） */
function isRetryable(err) {
  if (!err) return false;
  if (err.retryable) return true;
  if (err.name === 'AbortError') return true;
  return /fetch failed|ECONNRESET|ECONNREFUSED|ETIMEDOUT|EPIPE|socket hang up|terminated|network/i.test(
    String(err.message || err),
  );
}

/**
 * 带超时 + 重试的 GET（返回文本）。
 *
 * 退避表是 1s / 3s（失败重试 2 次）—— 到境外的链路会间歇 ECONNRESET，
 * 不退避直接重试基本还是撞同一个坑。
 */
export async function httpGet(
  url,
  {
    headers = {},
    timeoutMs = HTTP_TIMEOUT_MS,
    attempts = HTTP_ATTEMPTS,
    backoffMs = RETRY_BACKOFF_MS,
    fetchImpl = null,
  } = {},
) {
  const doFetch = fetchImpl || globalThis.fetch;
  let lastErr = null;
  for (let i = 0; i < attempts; i++) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await doFetch(url, {
        signal: ctrl.signal,
        redirect: 'follow',
        headers: { 'User-Agent': UA, Accept: '*/*', ...headers },
      });
      if (!res.ok) {
        const err = new Error(`HTTP ${res.status}`);
        err.status = res.status;
        // 429 / 5xx 是「限流 / 暂时挂了」，重试有意义；其它 4xx 重试没用
        err.retryable = res.status === 429 || res.status >= 500;
        throw err;
      }
      return await res.text();
    } catch (e) {
      lastErr = e;
      if (!isRetryable(e) || i === attempts - 1) throw e;
      await sleep(backoffMs[i] ?? backoffMs[backoffMs.length - 1]);
    } finally {
      clearTimeout(timer);
    }
  }
  throw lastErr;
}

/** 豆瓣同城页必须带的 Referer */
export function doubanReferer(slug) {
  return `${DOUBAN_BASE}/location/${slug}/`;
}

/* ───────────────────────────── 解析：TVmaze ───────────────────────────── */

/** 时间戳 → 毫秒（解析不了给 Infinity，排序时沉底） */
function tval(s) {
  const t = Date.parse(String(s || ''));
  return Number.isFinite(t) ? t : Number.POSITIVE_INFINITY;
}

/** 播出表排序：(airdate, airstamp) 升序；同刻按剧名排（稳定输出） */
function compareSchedule(a, b) {
  if (a.airdate !== b.airdate) return a.airdate < b.airdate ? -1 : 1;
  const ta = tval(a.airstamp);
  const tb = tval(b.airstamp);
  if (ta !== tb) return ta < tb ? -1 : 1;
  return a.title < b.title ? -1 : a.title > b.title ? 1 : 0;
}

/** 事件排序：开始时间升序；解析不出来的沉底 */
function compareEvent(a, b) {
  const ka = a.key;
  const kb = b.key;
  if (ka === kb) return 0;
  if (!Number.isFinite(ka)) return 1;
  if (!Number.isFinite(kb)) return -1;
  return ka - kb;
}

/**
 * 合并多个来源后重新排序用的通用比较器（读不可枚举的 _key）。
 *
 * _key 的形状：
 *   播出表 → [airdate, airstamp 绝对毫秒, title]
 *   活动   → [开始时间绝对毫秒]
 */
function compareKeys(a, b) {
  const ka = a._key || [];
  const kb = b._key || [];
  const n = Math.min(ka.length, kb.length);
  for (let i = 0; i < n; i++) {
    const x = ka[i];
    const y = kb[i];
    if (x === y) continue;
    if (typeof x === 'number' && typeof y === 'number') return x < y ? -1 : 1;
    return String(x) < String(y) ? -1 : 1;
  }
  return ka.length - kb.length;
}

/**
 * 挂一个排序键，但**不可枚举** —— 这样 JSON.stringify / Object.keys 都看不到它，
 * 契约里的 8 个字段一个不多一个不少，排序信息只在内存里跟着走。
 */
function withKey(item, key) {
  Object.defineProperty(item, '_key', { value: key, enumerable: false, writable: true, configurable: true });
  return item;
}

/**
 * 解析 TVmaze 播出表。
 *
 * ⚠️ **只留「剧集」**：TVmaze 的播出表把新闻、脱口秀、真人秀、体育节目全混在一起
 * （实测美国一天 81 条里 **只有 10 条是 Scripted**，37 条是 News、14 条是 Talk Show）。
 * 用户要的是「美剧更新」，不是「今天 CBS 早间秀」→ 按 show.type 过滤。
 * ⚠️ **type 缺失的条目照样保留**（判不出来就不丢数据）；真出了结构问题，
 *    外层「源返回了 N 条却解析出 0 条」的守卫会响。
 *
 * @param {string|Array} json  API 返回的 JSON 数组（或它的字符串）
 * @param {object} opts        { source, tag, types } —— 覆盖来源名 / 标签 / 类型白名单
 * @returns {Array} 契约条目（8 个字段），已按 (airdate, airstamp) 升序、rank 连号
 */
export function parseTvmazeSchedule(json, opts = {}) {
  const source = String(opts.source || SCHEDULE_SOURCE);
  const tag = String(opts.tag || SCHEDULE_TAG);
  const types = opts.types === null ? null : Array.isArray(opts.types) && opts.types.length ? opts.types : SERIES_TYPES;
  const arr = typeof json === 'string' ? JSON.parse(json) : json;
  if (!Array.isArray(arr)) return [];

  const rows = [];
  for (const ep of arr) {
    const show = ep && ep.show;
    if (!show || !show.name) continue;
    /* 类型过滤：types === null → 不过滤（结构自检用）；type 为空 → 保留（判不出来） */
    const showType = String(show.type || '').trim();
    if (types && showType && !types.includes(showType)) continue;

    const epName = String(ep.name || '').trim();
    const num = Number(ep.number);
    const hasNum = Number.isFinite(num) && num > 0;
    const subtitle = hasNum ? (epName ? `第${num}集 ${epName}` : `第${num}集`) : epName;

    const network =
      (show.network && show.network.name) || (show.webChannel && show.webChannel.name) || '';
    const airdate = String(ep.airdate || '').trim();
    const airtime = String(ep.airtime || '').trim();
    const head = [airdate, airtime].filter(Boolean).join(' ');
    const meta = network ? (head ? `${head} · ${network}` : network) : head;

    const img = show.image || {};
    const cover = img.medium || img.original || '';
    /* officialSite 原样带过来会是 http://（TVmaze 里 msnbc/nbc/cnn 都是 http），
       站点是 https → mixed content，浏览器可能直接拦。统一升成 https。 */
    const link = toHttps(
      (show.officialSite && String(show.officialSite).trim()) ||
        `https://www.tvmaze.com/shows/${show.id}`,
    );

    rows.push({
      title: String(show.name).trim(),
      subtitle,
      meta,
      cover,
      link,
      source,
      tag,
      airdate,
      airstamp: String(ep.airstamp || '').trim(),
    });
  }

  rows.sort(compareSchedule);
  return rows.map((r, i) =>
    withKey(
      {
        rank: i + 1,
        title: r.title,
        subtitle: r.subtitle,
        meta: r.meta,
        cover: r.cover,
        link: r.link,
        source: r.source,
        tag: r.tag,
      },
      [r.airdate, tval(r.airstamp), r.title],
    ),
  );
}

/* ───────────────────────────── 解析：豆瓣同城 ───────────────────────────── */

/** 行政区（静安区 / 上城区 …） */
const DISTRICT_RE = /^[一-龥]{1,6}(区|县)$/;

/** 地址关键词（路 / 街 / 号 / 楼 …） */
const ADDRESS_RE = /(路|街|号|栋|座|层|室|巷|弄|村|镇|园|大厦|广场|胡同|弄堂)/;

/**
 * 把豆瓣同城「地点」那一行拆成 场馆 / 地址。
 *
 * 豆瓣给的原始串是「城市 行政区 场馆 地址」四段拼的（见 <li title="...">），
 * 段与段之间是空格，但**场馆本身也可能带空格**（"中影国际影城天天中影CINITY LED店"），
 * 所以不能简单按空格切 —— 只有当最后一段长得像地址（带路/街/号/楼…）时才当地址。
 */
export function splitVenueAddress(raw, cityName = '') {
  const text = decodeEntities(String(raw || '')).replace(/\s+/g, ' ').trim();
  if (!text) return { venue: '', address: '' };
  let parts = text.split(' ').filter(Boolean);
  if (cityName && parts[0] === cityName) parts = parts.slice(1);
  if (parts.length && DISTRICT_RE.test(parts[0])) parts = parts.slice(1);
  if (!parts.length) return { venue: '', address: '' };
  if (parts.length >= 2 && ADDRESS_RE.test(parts[parts.length - 1])) {
    return { venue: parts.slice(0, -1).join(' '), address: parts[parts.length - 1] };
  }
  return { venue: parts.join(' '), address: '' };
}

/** ISO 时间戳 → 「2026-11-17 12:30」 */
function fmtStamp(s) {
  const m = /^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})/.exec(String(s || '').trim());
  if (m) return `${m[1]} ${m[2]}`;
  return String(s || '').trim();
}

/** 事件的时间描述：优先用 <time datetime>（机器可读），没有才退回可见文字 */
function eventMeta(block) {
  const startM = block.match(/<time itemprop="startDate" datetime="([^"]*)"/i);
  const endM = block.match(/<time itemprop="endDate" datetime="([^"]*)"/i);
  const start = startM ? startM[1].trim() : '';
  const end = endM ? endM[1].trim() : '';
  if (start) {
    const s = fmtStamp(start);
    if (!end) return s;
    const e = fmtStamp(end);
    if (!e) return s;
    const sDate = s.split(' ')[0];
    const eDate = e.split(' ')[0];
    const eTime = e.includes(' ') ? e.split(' ')[1] : '';
    // 同一天：结束时间只给时刻，跨天：带完整日期
    return sDate === eDate && eTime ? `${s} - ${eTime}` : `${s} - ${e}`;
  }
  const timeLi = block.match(/<li class="event-time"[^>]*>([\s\S]*?)<\/li>/i);
  if (timeLi) {
    const t = textOf(timeLi[1]).replace(/^时间[：:]\s*/, '').trim();
    if (t) return t;
  }
  return '';
}

/**
 * 解析豆瓣同城活动页。
 *
 * @param {string} html       页面 HTML
 * @param {string} cityName   城市中文名（做 tag，也用来切地点串）
 * @returns {Array} 契约条目（8 个字段），按开始时间升序、rank 连号
 */
export function parseDoubanEvents(html, cityName) {
  const src = String(html || '');
  const blocks = src.split('<li class="list-entry"').slice(1);
  const city = String(cityName || '').trim();

  const rows = [];
  for (const block of blocks) {
    const link = (block.match(/href="([^"]*\/event\/\d+\/)"/i) || [])[1] || '';

    let title = '';
    const sumM = block.match(/<span itemprop="summary"[^>]*>([\s\S]*?)<\/span>/i);
    if (sumM) title = textOf(sumM[1]);
    if (!title) {
      const titleM = block.match(/<a href="[^"]*\/event\/\d+\/"[^>]*title="([^"]*)"/i);
      if (titleM) title = decodeEntities(titleM[1]).trim();
    }
    if (!title) continue;

    // 海报在 data-lazy 里 —— src 是 blank.gif 占位图，不是真海报
    const picM = block.match(/<div class="pic">([\s\S]*?)<\/div>/i);
    const picHtml = picM ? picM[1] : block;
    const cover = (picHtml.match(/data-lazy="([^"]+)"/i) || [])[1] || '';

    const meta = eventMeta(block);

    const locM = block.match(/<li title="([^"]*)"/i);
    const loc = locM ? locM[1] : '';
    const { venue, address } = splitVenueAddress(loc, city);
    const subtitle = address ? `${venue} · ${address}` : venue;

    const startM = block.match(/<time itemprop="startDate" datetime="([^"]*)"/i);
    const key = startM ? tval(startM[1]) : Number.POSITIVE_INFINITY;

    rows.push({
      title,
      subtitle,
      meta,
      cover,
      link,
      source: EVENTS_SOURCE,
      tag: city,
      key,
    });
  }

  rows.sort(compareEvent);
  return rows.map((r, i) =>
    withKey(
      {
        rank: i + 1,
        title: r.title,
        subtitle: r.subtitle,
        meta: r.meta,
        cover: r.cover,
        link: r.link,
        source: r.source,
        tag: r.tag,
      },
      [r.key],
    ),
  );
}

/* ───────────────────────────── 解析：兜底通道 ───────────────────────────── */

/** 把页面上所有 URL 拆干净（兜底通道只许留纯文本元数据） */
function stripUrls(s) {
  return String(s)
    .replace(/<[^>]*>/g, ' ')
    .replace(/https?:\/\/[^\s"'<>]+/gi, ' ')
    .replace(/ftp:\/\/[^\s"'<>]+/gi, ' ')
    .replace(/(^|[\s(（])\/\/[^\s"'<>]+/g, '$1')
    .replace(/\bwww\.[^\s"'<>]+/gi, ' ')
    .replace(/magnet:\?[^\s"'<>]+/gi, ' ');
}

/** 豆瓣站内搜索（兜底 item 唯一允许出现的链接） */
export function doubanSearchLink(title) {
  return DOUBAN_SEARCH_BASE + encodeURIComponent(String(title || ''));
}

/** http:// → https://（TVmaze 的 officialSite 有一半是 http，站点是 https → mixed content） */
export function toHttps(url) {
  const s = String(url || '');
  return s.startsWith('http://') ? 'https://' + s.slice('http://'.length) : s;
}

/** 兜底行里「剧名 第N集 [集名] 日期」的认法 */
const FALLBACK_EP_RE =
  /([^\s][^\n]{0,80}?)\s*第\s*(\d+)\s*集\s*([^\n]{0,40}?)(\d{4}\s*[-/年.]\s*\d{1,2}\s*[-/月.]\s*\d{1,2}\s*日?|\d{1,2}\s*[-/月]\s*\d{1,2}\s*日?)/;

/** 兜底行里「剧名 日期」的认法（没有集数时） */
const FALLBACK_DATE_RE =
  /^([^\s][^\n]{1,80}?)\s*(\d{4}\s*[-/年.]\s*\d{1,2}\s*[-/月.]\s*\d{1,2}\s*日?|\d{1,2}\s*[-/月]\s*\d{1,2}\s*日?)/;

/** 从一行纯文本里认「剧名 / 集数 / 日期」 */
function parseFallbackLine(line, name, tag) {
  const t = String(line || '').trim();
  if (!t || t.length < 2) return null;

  const epM = FALLBACK_EP_RE.exec(t);
  let title = '';
  let subtitle = '';
  let meta = '';

  if (epM) {
    title = epM[1].replace(/[\s\-–—|:：·]+$/, '').trim();
    const epTitle = epM[3].replace(/[\s\-–—|:：·]+$/, '').trim();
    subtitle = epTitle ? `第${epM[2]}集 ${epTitle}` : `第${epM[2]}集`;
    meta = epM[4].replace(/\s+/g, '');
  } else {
    const dateM = FALLBACK_DATE_RE.exec(t);
    if (!dateM) return null;
    title = dateM[1].replace(/[\s\-–—|:：·]+$/, '').trim();
    meta = dateM[2].replace(/\s+/g, '');
  }

  if (!title) return null;

  return {
    title,
    subtitle,
    meta,
    cover: '',
    link: String((cfg && cfg.url) || 'https://play.example/' + encodeURIComponent(title)),
    source: name,
    tag,
  };
}

/**
 * 兜底输出的硬性自检：**绝不允许出现 URL**（豆瓣搜索链接除外）。
 *
 * 这条是整个兜底通道的命门 —— 兜底源是盗版聚合站，页面上全是播放地址，
 * 一旦漏出去，站点就会变成盗版站的外链跳板。所以宁可 throw 也不能放行。
 */
function assertNoUrls(items) {
  for (const it of items) {
    for (const [k, v] of Object.entries(it)) {
      if (typeof v !== 'string') continue;
      if (k === 'link') {
        if (!v.startsWith(DOUBAN_SEARCH_BASE)) throw new Error(`兜底 link 不是豆瓣搜索：${v}`);
        continue;
      }
      if (URL_RE.test(v)) throw new Error(`兜底输出含 URL：${k}=${v}`);
    }
  }
}

/**
 * 解析兜底源页面 → 纯文本元数据。
 *
 * @param {string} text  兜底列表页的原始 HTML / 文本
 * @param {object} cfg   { name, tag } —— 显示名与标签
 * @returns {Array} 契约条目（8 个字段）；输出里含 URL 直接 throw
 */
export function parseFallbackMeta(text, cfg = {}) {
  const name = String(cfg.name || '兜底').trim() || '兜底';
  const tag = String(cfg.tag || SCHEDULE_TAG).trim() || SCHEDULE_TAG;

  const raw = stripUrls(String(text || ''));
  const lines = [];
  for (const one of raw.split(/[\n\r]+/)) {
    const l = one.replace(/\s+/g, ' ').trim();
    if (l) lines.push(l);
  }

  const items = [];
  for (const c of lines) {
    const item = parseFallbackLine(c, name, tag);
    if (item) items.push(item);
  }

  assertNoUrls(items);

  return items.map((it, i) => ({
    rank: i + 1,
    title: it.title,
    subtitle: it.subtitle,
    meta: it.meta,
    cover: it.cover,
    link: it.link,
    source: it.source,
    tag: it.tag,
  }));
}

/* ───────────────────────────── 兜底配置 ───────────────────────────── */

/**
 * 读兜底配置。
 *
 * 文件不存在 = 整条通道关闭（**不是错误**，主流程照常跑）。
 * 文件坏掉 = 通道关闭 + 记一条错误，不让配置问题把主流程带崩。
 */
export function loadFallbackConfig(configPath = FALLBACK_CONFIG_PATH) {
  const p = configPath || FALLBACK_CONFIG_PATH;
  let raw;
  try {
    raw = fs.readFileSync(p, 'utf8');
  } catch {
    // 文件不存在 = 通道关闭（**不是错误**：主流程照常跑）
    return {
      enabled: false,
      fallbacks: [],
      path: p,
      missing: true,
      reason: '没有配置文件（兜底通道关闭）',
    };
  }
  let cfg;
  try {
    cfg = JSON.parse(raw);
  } catch (e) {
    return {
      enabled: false,
      fallbacks: [],
      path: p,
      missing: false,
      reason: `配置不是合法 JSON：${errMsg(e)}`,
    };
  }
  const list = Array.isArray(cfg && cfg.fallbacks) ? cfg.fallbacks : [];
  const fallbacks = list
    .filter((f) => f && typeof f.url === 'string' && f.url.trim())
    .map((f) => ({
      name: String(f.name || '兜底').trim() || '兜底',
      url: String(f.url).trim(),
    }));
  return {
    enabled: fallbacks.length > 0,
    fallbacks,
    path: p,
    missing: false,
    reason: fallbacks.length ? '' : '配置里没有可用的兜底源',
  };
}

/* ───────────────────────────── 输出契约 ───────────────────────────── */

const ITEM_FIELDS = ['rank', 'title', 'subtitle', 'meta', 'cover', 'link', 'source', 'tag'];

/** 条目归一化：字段名与顺序固定，rank 连号 */
function normalizeItem(it, i) {
  const o = it || {};
  return {
    rank: i + 1,
    title: String(o.title || '').trim(),
    subtitle: String(o.subtitle || '').trim(),
    meta: String(o.meta || '').trim(),
    cover: String(o.cover || '').trim(),
    link: String(o.link || '').trim(),
    source: String(o.source || '').trim(),
    tag: String(o.tag || '').trim(),
  };
}

/** cities 既可能是名字数组，也可能是 {name,slug} 数组 */
function cityNames(cities) {
  const list = Array.isArray(cities) ? cities : [];
  return list
    .map((c) => (typeof c === 'string' ? c : c && c.name ? String(c.name) : ''))
    .map((s) => s.trim())
    .filter(Boolean);
}

/**
 * 组装最终 JSON（build.mjs 按这个结构读，字段名一个都不能改）。
 *
 * { date, generatedAt, cities[], schedule[], events[], errors[] }
 * 条目 8 个字段：rank/title/subtitle/meta/cover/link/source/tag
 */
export function buildFollowPayload({ date = '', schedule = [], events = [], cities = [], errors = [] } = {}) {
  const d = isDate(date) ? String(date).trim() : beijingToday();
  const list = Array.isArray(cities) ? cities : [];
  const names = list.length ? cityNames(list) : CITIES.map((c) => c.name);
  return {
    date: d,
    generatedAt: `${d}T00:00:00.000Z`,
    cities: names,
    schedule: (Array.isArray(schedule) ? schedule : []).map(normalizeItem),
    events: (Array.isArray(events) ? events : []).map(normalizeItem),
    errors: (Array.isArray(errors) ? errors : []).map((e) => String(e)),
  };
}

/** 落盘位置：<SRC_LOCAL>/<date>/follow_<date>.json */
export function followFilePath(date, { root = SRC_LOCAL } = {}) {
  return path.join(root, String(date), `follow_${String(date)}.json`);
}

/** 历史位置也认（挪过盘的老目录），写还是写规范位置 */
export function followFileCandidates(date) {
  return srcSearchRoots().map((root) => followFilePath(date, { root }));
}

/** 写文件（dryRun 时只报路径，不落盘） */
export function writeFollowFile(payload, date, { root = SRC_LOCAL, dryRun = false } = {}) {
  const file = followFilePath(date, { root });
  if (dryRun) return { file, written: false };
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(payload, null, 2) + '\n', 'utf8');
  return { file, written: true };
}

/* ───────────────────────────── 编排 ───────────────────────────── */

/** 单个源失败只记 error，不炸整个命令 */
async function runSource(name, fn, errors, { allowEmpty = false } = {}) {
  const t0 = Date.now();
  try {
    const items = await fn();
    if (!items.length && !allowEmpty) throw new Error('解析出 0 条（源结构可能变了）');
    return { name, items, ms: Date.now() - t0, error: '' };
  } catch (e) {
    const msg = errMsg(e);
    errors.push(`${name}: ${msg}`);
    return { name, items: [], ms: Date.now() - t0, error: msg };
  }
}

/** 把兜底源抓一遍，解析成条目 */
async function collectFallback(cfg, { tag, fetchImpl, errors }) {
  const items = [];
  for (const fb of cfg.fallbacks || []) {
    try {
      const txt = await httpGet(fb.url, { fetchImpl });
      const parsed = parseFallbackMeta(txt, { name: fb.name, tag });
      items.push(...parsed);
    } catch (e) {
      errors.push(`兜底(${fb.name}): ${errMsg(e)}`);
    }
  }
  return items;
}

/**
 * 抓全部源，组装最终 payload。
 *
 * 失败隔离：单个城市失败不影响其它城市；单个国家失败不影响其它国家；
 * 全挂（schedule 和 events 都空）才算彻底失败。
 */
export async function fetchFollow({
  date = '',
  days = 2,
  cities = CITIES,
  dryRun = false,
  fetchImpl = null,
  fallbackConfig = undefined,
  countries = COUNTRIES,
  root = SRC_LOCAL,
} = {}) {
  const errors = [];
  const d = isDate(date) ? String(date).trim() : beijingToday();
  const doFetch = fetchImpl || globalThis.fetch;
  const cityList = Array.isArray(cities) && cities.length ? cities : CITIES;
  const nDays = Math.max(1, Number(days) || 2);
  const countryList = Array.isArray(countries) && countries.length ? countries : COUNTRIES;

  /* 1) 剧集更新：TVmaze 每天每个国家一张表，抓今天 + 明天
     ⚠️ **按国家分组**，不按时间全局混排：美剧黄金档 = UTC 次日凌晨，
     全局按时间排会把美剧全压到末尾（日本深夜档 00:00 排在最前），
     而用户要的就是「美剧更新」。组内仍按播出时间升序。 */
  const schedule = [];
  for (const country of countryList) {
    const perCountry = [];
    for (let i = 0; i < nDays; i++) {
      const day = addDays(d, i);
      const url = `${TVMAZE_BASE}/schedule?country=${encodeURIComponent(country)}&date=${day}`;
      const r = await runSource(
        `${SCHEDULE_SOURCE}(${country} ${day})`,
        async () => {
          const raw = await httpGet(url, { fetchImpl: doFetch });
          /* 结构自检用**不过滤**的解析：某个国家某天全是新闻/脱口秀（JP 2026-11-17 就是），
             过滤后自然是 0 条 —— 那不是「源结构变了」。 */
          const itemsAll = parseTvmazeSchedule(raw, { types: null });
          const items = parseTvmazeSchedule(raw);
          // 某国某天本来就可能一集没有（HK 常年稀疏）—— 那不是错误；
          // 但「源返回了一堆条目却一条都解析不出来」就是结构变了，必须报错。
          let arr = null;
          try {
            arr = JSON.parse(raw);
          } catch {
            arr = null;
          }
          if (Array.isArray(arr) && arr.length > 0 && !itemsAll.length) {
            throw new Error(`源结构可能变了（返回 ${arr.length} 条但解析出 0 条）`);
          }
          return items;
        },
        errors,
        { allowEmpty: true },
      );
      perCountry.push(...r.items);
    }
    perCountry.sort(compareKeys);
    schedule.push(...perCountry);
  }

  /* 2) 城市演艺活动：豆瓣同城，一个城市一个页面 */
  const events = [];
  for (const city of cityList) {
    const slug = city.slug;
    const url = `${DOUBAN_BASE}/location/${slug}/events`;
    const r = await runSource(
      `${EVENTS_SOURCE}(${city.name})`,
      async () =>
        parseDoubanEvents(
          await httpGet(url, { headers: { Referer: doubanReferer(slug) }, fetchImpl: doFetch }),
          city.name,
        ),
      errors,
    );
    events.push(...r.items);
  }
  events.sort(compareKeys);

  /* 3) 兜底通道：只在主源对应板块失败时启用 */
  let cfg;
  if (typeof fallbackConfig === 'string') cfg = loadFallbackConfig(fallbackConfig);
  else if (fallbackConfig && typeof fallbackConfig === 'object') cfg = fallbackConfig;
  else cfg = loadFallbackConfig();
  if (cfg.reason && !cfg.missing) errors.push(`兜底通道: ${cfg.reason}`);

  if (cfg.enabled) {
    if (!schedule.length) {
      const fb = await collectFallback(cfg, { tag: SCHEDULE_TAG, fetchImpl: doFetch, errors });
      if (fb.length) schedule.push(...fb);
    }
    if (!events.length) {
      const fb = await collectFallback(cfg, { tag: FALLBACK_EVENTS_TAG, fetchImpl: doFetch, errors });
      if (fb.length) events.push(...fb);
    }
  }

  const payload = buildFollowPayload({
    date: d,
    schedule,
    events,
    cities: cityList.map((c) => (typeof c === 'string' ? c : c.name)),
    errors,
  });

  const allFailed = !payload.schedule.length && !payload.events.length;
  let written = null;
  if (!allFailed) written = writeFollowFile(payload, d, { root, dryRun });

  return payload;
}

/* ───────────────────────────── CLI ───────────────────────────── */

function parseArgs(argv) {
  const out = { date: '', dryRun: false, help: false, days: 2, countries: COUNTRIES };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--date') out.date = String(argv[++i] || '').trim();
    else if (a.startsWith('--date=')) out.date = a.slice('--date='.length).trim();
    else if (a === '--dry-run' || a === '--dry') out.dryRun = true;
    else if (a === '--days') out.days = Number(argv[++i] || 2) || 2;
    else if (a.startsWith('--days=')) out.days = Number(a.slice('--days='.length)) || 2;
    else if (a === '--countries') out.countries = String(argv[++i] || '').split(',').map((s) => s.trim()).filter(Boolean);
    else if (a.startsWith('--countries=')) out.countries = a.slice('--countries='.length).split(',').map((s) => s.trim()).filter(Boolean);
    else if (a === '--help' || a === '-h') out.help = true;
  }
  return out;
}

function usage() {
  return [
    '用法：',
    '  node tools/fetch-follow.mjs --date 2026-11-16              抓取并写文件',
    '  node tools/fetch-follow.mjs --date 2026-11-16 --dry-run    只抓取并打印统计',
    '  node tools/fetch-follow.mjs --help                         打印本用法',
    '',
    '  --date <YYYY-MM-DD>   期号（缺省 = 北京今天）',
    '  --dry-run             不写文件',
    '  --days <N>            抓几天（默认 2 = 今天 + 明天）',
    '  --countries <a,b>     抓哪些国家的播出表（默认 US,CN,JP,KR,HK）',
  ].join('\n');
}

export async function main(argv = process.argv.slice(2)) {
  const args = parseArgs(argv);
  if (args.help) {
    console.log(usage());
    return 0;
  }
  const date = args.date || beijingToday();
  if (!isDate(date)) {
    console.error(`日期格式不对：${date}（要 YYYY-MM-DD）`);
    console.error(usage());
    return 2;
  }

  console.log(`\n追更抓取  ${date}\n`);
  const t0 = Date.now();
  const payload = await fetchFollow({
    date,
    days: args.days,
    countries: args.countries,
    dryRun: args.dryRun,
  });

  console.log(
    `  剧集更新 ${payload.schedule.length} 条 / 演艺活动 ${payload.events.length} 条 / 耗时 ${Date.now() - t0}ms`,
  );
  const cities = new Set(payload.events.map((e) => e.tag));
  console.log(`  城市 ${cities.size} 个：${[...cities].join('、')}`);
  if (payload.errors.length) {
    console.log('\n失败摘要：');
    for (const e of payload.errors) console.log(`  - ${e}`);
  }

  if (args.dryRun) {
    console.log('\n--dry-run：不写文件。');
  } else if (!payload.schedule.length && !payload.events.length) {
    console.error('\n两个板块都挂了 —— 没有内容可写。');
    return 1;
  } else {
    console.log(`\n写入  ${followFilePath(date)}`);
  }

  if (!payload.schedule.length && !payload.events.length) return 1;
  return 0;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  main()
    .then((code) => {
      process.exit(code);
    })
    .catch((err) => {
      console.error('追更抓取失败：', err && err.message ? err.message : err);
      process.exit(1);
    });
}
