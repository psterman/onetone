﻿import https from 'node:https';
function get(url){
  return new Promise((res)=>{
    const req=https.get(url,{headers:{'User-Agent':'Mozilla/5.0','Accept':'application/json'}},r=>{
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,body:d}));
    });
    req.on('error',e=>res({s:0,body:''}));
    req.setTimeout(20000,()=>{try{req.destroy();}catch(e){} res({s:0,body:''})});
  });
}
console.log('=== A. 一天 338 个更新 show 的完整语言/频道分布 ===');
const u=await get('https://api.tvmaze.com/updates/shows?since=day');
const ids=Object.keys(JSON.parse(u.body));
const langs={},chs={},types={}; let ok=0;
const CONC=12;
for(let i=0;i<ids.length;i+=CONC){
  const chunk=ids.slice(i,i+CONC);
  const rs=await Promise.all(chunk.map(id=>get('https://api.tvmaze.com/shows/'+id)));
  for(const r of rs){
    if(r.s!==200) continue;
    ok++;
    let s; try{ s=JSON.parse(r.body); }catch(e){ continue; }
    langs[s.language]=(langs[s.language]||0)+1;
    const ch=s.webChannel?s.webChannel.name:(s.network?s.network.name:'(无)');
    chs[ch]=(chs[ch]||0)+1;
    types[s.type]=(types[s.type]||0)+1;
  }
}
console.log('  成功='+ok+'/'+ids.length);
console.log('  语言: '+Object.entries(langs).sort((a,b)=>b[1]-a[1]).map(([k,v])=>k+'×'+v).join(', '));
console.log('  中文占比: '+(((langs.Chinese||0)/ok*100).toFixed(1))+'%');
console.log('  频道 Top25: '+Object.entries(chs).sort((a,b)=>b[1]-a[1]).slice(0,25).map(([k,v])=>k+'×'+v).join(', '));
console.log('  目标平台在列: '+['Netflix','Hulu','Disney+','HBO','Max','Peacock','Prime Video','TVB','myTV SUPER','Tencent QQ','Youku','CCTV-8','TV Tokyo','TVTM'].map(k=>k+'='+(chs[k]||0)).join(', '));
console.log('  类型: '+Object.entries(types).sort((a,b)=>b[1]-a[1]).map(([k,v])=>k+'×'+v).join(', '));
