/* 临时补丁：把听乐条目的 source 从「榜单名」改成发布方「网易云音乐」
   （原来 source 和 tag 都是榜单名，卡片上会出现两个一样的标签）。
   只改字段，不重新抓数据 —— 免得再刷一遍豆瓣同城被限流。 */
const fs = require('node:fs');
const P = 'E:/voice-pilot/daily-image-site/tools/.tmp-proto-v2/data.js';
const s = fs.readFileSync(P, 'utf8');
const j = JSON.parse(s.slice(s.indexOf('{'), s.lastIndexOf('}') + 1));

let n = 0;
for (const c of j.music.charts) {
  const isApple = c.key === 'apple_top';
  for (const it of c.items) {
    if (isApple) { it.source = 'Apple Music'; continue; }
    if (it.source !== '网易云音乐') { it.source = '网易云音乐'; n++; }
  }
}
fs.writeFileSync(P, 'window.__PROTO__ = ' + JSON.stringify(j) + ';\n', 'utf8');
console.log(`已改 ${n} 条 source · data.js ${(fs.statSync(P).size / 1024).toFixed(1)} KB`);
