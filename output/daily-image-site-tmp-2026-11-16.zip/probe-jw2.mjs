﻿import https from 'node:https';
function post(q,v){
  return new Promise((res)=>{
    const body=JSON.stringify({query:q,variables:v});
    const r=https.request('https://apis.justwatch.com/graphql',{method:'POST',headers:{'Content-Type':'application/json','X-Client-Id':'justwatch','Origin':'https://www.justwatch.com','Referer':'https://www.justwatch.com/','User-Agent':'Mozilla/5.0','Content-Length':Buffer.byteLength(body)}},(resp)=>{
      let d='';resp.on('data',c=>d+=c);resp.on('end',()=>res({s:resp.statusCode,body:d}));
    });
    r.on('error',e=>res({s:0,body:'ERR '+e.message}));
    r.setTimeout(25000,()=>{r.destroy();res({s:0,body:'TIMEOUT'})});
    r.write(body); r.end();
  });
}
async function hint(label,q,v){
  const r=await post(q,v);
  console.log('['+label+'] status='+r.s);
  console.log('   '+r.body.slice(0,700).replace(/\s+/g,' '));
  console.log('');
}
console.log('=== 用「故意写错字段」逼出 schema 提示 ===\n');
await hint('newTitles 字段提示','query($c:Country!){ newTitles(first:3,country:$c){ zzz } }',{c:'CN'});
await hint('MovieOrSeason 字段提示','query($c:Country!){ newTitles(first:3,country:$c){ edges { node { zzz } } } }',{c:'CN'});
await hint('packages 字段提示','query($c:Country!){ packages(country:$c){ zzz } }',{c:'CN'});
await hint('Query 顶层字段提示','query{ zzz }',{});
