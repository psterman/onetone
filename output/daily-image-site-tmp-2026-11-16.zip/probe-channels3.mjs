﻿import https from 'node:https';
function req(url, method='GET', headers={}, body=null) {
  return new Promise((res)=>{
    const h=Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)','Accept':'*/*'},headers);
    const r=https.request(url,{method,headers:h},(resp)=>{
      let d='';resp.on('data',c=>d+=c);resp.on('end',()=>res({s:resp.statusCode,ct:resp.headers['content-type'],body:d}));
    });
    r.on('error',e=>res({s:0,body:'ERR '+e.message}));
    r.setTimeout(20000,()=>{r.destroy();res({s:0,body:'TIMEOUT'})});
    if(body) r.write(body);
    r.end();
  });
}
console.log('=== 1. JustWatch GraphQL POST ===');
const qw=JSON.stringify({query:"query { getAllTitles(first: 5, country: \"CN\", language: \"ZH\") { edges { node { id title { id titleText { text } } } } } }"});
let r=await req('https://apis.justwatch.com/graphql','POST',{'Content-Type':'application/json','X-Client-Id':'justwatch','Origin':'https://www.justwatch.com','Referer':'https://www.justwatch.com/'},qw);
console.log('status='+r.s+' body='+r.body.slice(0,400));

console.log('\n=== 2. JustWatch content API ===');
r=await req('https://apis.justwatch.com/content/titles/tt0903747?country=CN&language=ZH&IncludeTrailers=false','GET',{'X-Client-Id':'justwatch','Origin':'https://www.justwatch.com'});
console.log('status='+r.s+' len='+r.body.length+' head='+r.body.slice(0,200));

console.log('\n=== 3. Netflix Tudum HTML ===');
r=await req('https://www.netflix.com/tudum/top10','GET',{'Accept':'text/html'});
console.log('status='+r.s+' len='+r.body.length);
const m=r.body.match(/tudum-top10-global-tv[^"']{0,40}/g);
console.log('embedded refs: '+JSON.stringify((m||[]).slice(0,5)));

console.log('\n=== 4. TVmaze show.webChannel 抽样（查 Netflix/Hulu/Disney+） ===');
for(const q of ['stranger things','the handmaid','the mandalorian','succession','tvb']){
  const rr=await req('https://api.tvmaze.com/search/shows?q='+encodeURIComponent(q),'GET');
  try{
    const j=JSON.parse(rr.body);
    const s=j[0]&&j[0].show;
    if(s) console.log('  q='+q+' -> id='+s.id+' "'+s.name+'" network='+(s.network&&s.network.name)+' webChannel='+(s.webChannel&&s.webChannel.name)+' type='+s.type+' lang='+s.language);
    else console.log('  q='+q+' -> no hit');
  }catch(e){ console.log('  q='+q+' -> parse fail status='+rr.s); }
}
