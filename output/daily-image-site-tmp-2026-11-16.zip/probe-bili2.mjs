const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
const SEC = { Accept: "image/avif,image/webp,image/apng,image/*,*/*;q=0.8", "Sec-Fetch-Dest": "image", "Sec-Fetch-Mode": "no-cors", "Sec-Fetch-Site": "cross-site" };
const u = "https://i1.hdslb.com/bfs/archive/5a202db2daa18fc4ffbdef57b233b587dad063e7.jpg";
for (const [l, extra] of [
  ["浏览器默认(带本站origin)", { Referer: "https://daily.onetone.app/" }],
  ["no-referrer 策略", {}],
  ["referrer=no-referrer", { "Referrer-Policy": "no-referrer" }],
]) {
  const r = await fetch(u, { headers: { "User-Agent": UA, ...SEC, ...extra } });
  console.log(l.padEnd(24), "->", r.status, r.headers.get("content-type"));
}