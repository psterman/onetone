﻿import https from 'node:https';
function get(url, headers={}) {
  return new Promise((res)=>{
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','Accept':'text/html,*/*','Accept-Language':'en-US,en;q=0.9'},headers)},r=>{
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(25000,()=>{try{req.destroy();}catch(e){} res({s:0,body:'TIMEOUT'})});
  });
}
const r=await get('https://www.tiktok.com/trending',{Referer:'https://www.tiktok.com/'});
console.log('status='+r.s+' len='+r.body.length);
const m=r.body.match(/__UNIVERSAL_DATA_FOR_REHYDRATION\s*=\s*(\{.*?\});/s);
if(!m){ console.log('未匹配到 UNIVERSAL_DATA'); }
else{
  let j=null; try{ j=JSON.parse(m[1]); }catch(e){ console.log('JSON parse fail: '+e.message+' 前200: '+m[1].slice(0,200)); }
  if(j){
    const keys=Object.keys(j);
    console.log('顶层键('+keys.length+'): '+keys.join(','));
    const dump=(o,path,d)=>{
      if(d>3||!o||typeof o!=='object') return;
      for(const k of Object.keys(o)){
        const v=o[k];
        if(Array.isArray(v)&&v.length&&typeof v[0]==='object'){
          const ks=Object.keys(v[0]).slice(0,12).join(',');
          console.log('  '+path+'.'+k+' = 数组['+v.length+']  首项键: '+ks);
          dump(v[0],path+'.'+k+'[0]',d+1);
        } else if(v&&typeof v==='object'){
          console.log('  '+path+'.'+k+' = 对象{'+Object.keys(v).slice(0,10).join(',')+'}');
          dump(v,path+'.'+k,d+1);
        }
      }
    };
    dump(j,'',0);
  }
}
