﻿import https from 'node:https';
function get(url, headers={}) {
  return new Promise((res)=>{
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)','Accept':'*/*'},headers)},r=>{
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(20000,()=>{try{req.destroy();}catch(e){} res({s:0,body:'TIMEOUT'})});
  });
}
console.log('=== TVmaze 到底有没有港剧 ===');
for(const q of ['衝上雲霄','使徒行者','愛回家','tvb','hbo max','disney plus','paramount+','peacock']){
  const r=await get('https://api.tvmaze.com/search/shows?q='+encodeURIComponent(q));
  try{ const j=JSON.parse(r.body);
    const s=j[0]&&j[0].show;
    console.log('  q='+q.padEnd(12)+' hits='+j.length+(s?(' | top: "'+s.name+'" network='+(s.network&&s.network.name)+' web='+(s.webChannel&&s.webChannel.name)+' lang='+s.language+' type='+s.type):''));
  }catch(e){ console.log('  q='+q+' status='+r.s); }
}
console.log('\n=== TVmaze 按 webChannel 精确搜（用 shows?page 抽样统计频道分布） ===');
const r=await get('https://api.tvmaze.com/shows?page=0');
try{ const j=JSON.parse(r.body);
  const wc={},nw={};
  for(const s of j){ if(s.webChannel) wc[s.webChannel.name]=(wc[s.webChannel.name]||0)+1; if(s.network) nw[s.network.name]=(nw[s.network.name]||0)+1; }
  console.log('  page0 共 '+j.length+' 部；webChannel 分布: '+JSON.stringify(wc));
  console.log('  network Top12: '+Object.entries(nw).sort((a,b)=>b[1]-a[1]).slice(0,12).map(([k,v])=>k+'×'+v).join(', '));
}catch(e){ console.log('  status='+r.s); }
