﻿import https from 'node:https';
function get(url, headers={}) {
  return new Promise((res)=>{
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','Accept':'*/*','Accept-Language':'en-US,en;q=0.9'},headers)},r=>{
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(25000,()=>{try{req.destroy();}catch(e){} res({s:0,body:'TIMEOUT'})});
  });
}
console.log('=== A. YouTube ytInitialData 正确解析 ===');
let r=await get('https://www.youtube.com/feed/trending',{Accept:'text/html'});
const body=r.body;
console.log('  len='+body.length+' 含 ytInitialData='+body.includes('ytInitialData'));
const vids=[...body.matchAll(/"videoId":"([A-Za-z0-9_-]{11})"/g)].map(m=>m[1]);
const uniq=[...new Set(vids)];
console.log('  videoId 唯一数='+uniq.length+' 样例='+JSON.stringify(uniq.slice(0,8)));
// 标题：runs 模式
const tt=[...body.matchAll(/"title":\{"runs":\[\{"text":"((?:[^"\\]|\\.){2,120})"/g)].map(m=>m[1]);
console.log('  title(runs) 数='+tt.length+' 样例='+JSON.stringify(tt.slice(0,6)));
const thumb=[...body.matchAll(/"thumbnails":\[\{"url":"(https:\/\/i\.ytimg\.com\/vi\/[^"]+)"/g)].map(m=>m[1]);
console.log('  缩略图数='+thumb.length+' 样例='+JSON.stringify(thumb.slice(0,3)));
const owner=[...body.matchAll(/"ownerText":\{"runs":\[\{"text":"([^"]+)"/g)].map(m=>m[1]);
console.log('  作者数='+owner.length+' 样例='+JSON.stringify(owner.slice(0,6)));
const vc=[...body.matchAll(/"viewCountText":\{"simpleText":"([^"]+)"/g)].map(m=>m[1]);
console.log('  播放量样例='+JSON.stringify(vc.slice(0,6)));
const pub=[...body.matchAll(/"publishedTimeText":\{"simpleText":"([^"]+)"/g)].map(m=>m[1]);
console.log('  发布时间样例='+JSON.stringify(pub.slice(0,6)));

console.log('\n=== B. 抖音封面不带签名能否直连 ===');
const d=await get('https://www.douyin.com/aweme/v1/web/hot/search/list/?device_platform=webapp&aid=6383&channel=channel_pc_web&detail_list=1',{Referer:'https://www.douyin.com/'});
try{
  const j=JSON.parse(d.body); const wl=j.data.word_list||[];
  const cov=wl[0].word_cover&&wl[0].word_cover.url_list;
  console.log('  封面 url 数='+(cov?cov.length:0));
  if(cov&&cov.length){
    const bare=cov[0].replace(/^https:\/\/[^/]+/,'');
    for(const [n,u] of [['原样(带签名)',cov[0]],['去掉域名换p3',cov[0].replace(/^https:\/\/[^/]+/,'https://p3-sign.douyinpic.com')],['只留path',bare]]){
      const rr=await get(u,{Referer:'https://www.douyin.com/'});
      console.log('   ['+n+'] status='+rr.s+' len='+rr.body.length+' ct='+(rr.ct||'').slice(0,22));
    }
    console.log('   x-expires='+((cov[0].match(/x-expires=(\d+)/)||[])[1])+' now='+Math.floor(Date.now()/1000));
  }
}catch(e){ console.log('  '+e.message); }

console.log('\n=== C. TikTok：Creative Center 页面内嵌数据 ===');
const t=await get('https://ads.tiktok.com/business/creativecenter/inspiration/popular/hashtag/pc/en?period=7',{Referer:'https://ads.tiktok.com/'});
console.log('  status='+t.s+' len='+t.body.length);
for(const k of ['__NEXT_DATA__','SIGI_STATE','__NUXT__','application/json','hashtagName','trend']){
  console.log('   含 "'+k+'": '+t.body.includes(k));
}
