﻿import https from 'node:https';
function post(q,v){
  return new Promise((res)=>{
    const body=JSON.stringify({query:q,variables:v});
    const r=https.request('https://apis.justwatch.com/graphql',{method:'POST',headers:{'Content-Type':'application/json','X-Client-Id':'justwatch','Origin':'https://www.justwatch.com','Referer':'https://www.justwatch.com/','User-Agent':'Mozilla/5.0','Content-Length':Buffer.byteLength(body)}},(resp)=>{
      let d='';resp.on('data',c=>d+=c);resp.on('end',()=>res({s:resp.statusCode,body:d}));
    });
    r.on('error',e=>res({s:0,body:'ERR '+e.message}));
    r.setTimeout(25000,()=>{r.destroy();res({s:0,body:'TIMEOUT'})});
    r.write(body); r.end();
  });
}
const JH={'Content-Type':'application/json','X-Client-Id':'justwatch','Origin':'https://www.justwatch.com','Referer':'https://www.justwatch.com/'};
console.log('=== A. Query 顶层更多候选（合法=没被报错） ===');
const Q=['content','titles','getTitle','getTitles','titleDetails','contentDetails','getContent','contentByIds','titleById','getTitleById','bundle','editorial','editorialNewTitles','newReleases','releases','episodes','seasons','genres','countries','languages','providers','contentRatings','productionStatus','package','packages','newTitles','searchTitles'];
let r=await post('query{ '+Q.join(' ')+' }',{});
try{ const j=JSON.parse(r.body); const bad=(j.errors||[]).map(e=>(e.message.match(/field "([^"]+)"/)||[])[1]).filter(Boolean);
  console.log('   合法顶层字段: '+JSON.stringify(Q.filter(x=>!bad.includes(x))));
}catch(e){ console.log(r.body.slice(0,300)); }

console.log('\n=== B. MovieOrSeason 是否走 interface（inline fragment 探测） ===');
for(const frag of ['on Title','on Content','on Movie','on ShowSeason','on MovieOrSeason']){
  const rr=await post('query($c:Country!){ newTitles(first:1,country:$c){ edges { node { id '+frag+' { id } } } } }',{c:'HK'});
  const s=rr.s===200?'OK':(rr.body.match(/"message":"([^"]+)"/)||[])[1];
  console.log('   '+frag+' -> '+s);
}

console.log('\n=== C. searchTitles 参数反推 ===');
r=await post('query{ searchTitles(source:"zzz",zzz:1){ edges { node { id } } } }',{});
try{ const j=JSON.parse(r.body); console.log('   '+JSON.stringify((j.errors||[]).map(e=>e.message)).slice(0,400)); }catch(e){ console.log(r.body.slice(0,300)); }
