﻿import https from 'node:https';
function post(q,v){
  return new Promise((res)=>{
    const body=JSON.stringify({query:q,variables:v});
    const r=https.request('https://apis.justwatch.com/graphql',{method:'POST',headers:{'Content-Type':'application/json','X-Client-Id':'justwatch','Origin':'https://www.justwatch.com','Referer':'https://www.justwatch.com/','User-Agent':'Mozilla/5.0','Content-Length':Buffer.byteLength(body)}},(resp)=>{
      let d='';resp.on('data',c=>d+=c);resp.on('end',()=>res({s:resp.statusCode,body:d}));
    });
    r.on('error',e=>res({s:0,body:'ERR '+e.message}));
    r.setTimeout(25000,()=>{try{r.destroy();}catch(e){} res({s:0,body:'TIMEOUT'})});
    r.write(body); r.end();
  });
}
const JH={'Content-Type':'application/json','X-Client-Id':'justwatch','Origin':'https://www.justwatch.com','Referer':'https://www.justwatch.com/'};
console.log('=== A. 具体类型 Season / Movie 能否 spread + 有哪些字段 ===');
for(const t of ['Season','Movie']){
  const r=await post('query($c:Country!){ newTitles(first:1,country:$c){ edges { node { id ... on '+t+' { id } } } } }',{c:'HK'});
  console.log('  ... on '+t+' -> '+(r.s===200?'可 spread':((r.body.match(/"message":"([^"]+)"/)||[])[1]||'').slice(0,150)));
}
const C=['id','objectType','titleText','title','name','releaseYear','releaseDate','originalTitleText','contentRating','productionStatus','posterUrl','imageUrl','poster','mainPoster','shortDescription','description','genres','episodes','seasons','number','productionCountry','showTitle','firstAirDate'];
for(const t of ['Season','Movie']){
  const r=await post('query($c:Country!){ newTitles(first:1,country:$c){ edges { node { id ... on '+t+' { '+C.join(' ')+' } } } } }',{c:'HK'});
  try{ const j=JSON.parse(r.body); const bad=(j.errors||[]).map(e=>(e.message.match(/field "([^"]+)"/)||[])[1]).filter(Boolean);
    console.log('  '+t+' 合法字段: '+JSON.stringify(C.filter(x=>!bad.includes(x))));
    if(j.data) console.log('     DATA: '+JSON.stringify(j.data).slice(0,700));
  }catch(e){ console.log('  '+t+' '+r.body.slice(0,200)); }
}
console.log('\n=== B. newTitles 按平台过滤实取 ===');
for(const p of ['netflix','max','disneyplus','viu','iqiyi']){
  const r=await post('query($c:Country!){ newTitles(first:3,country:$c,package:"'+p+'"){ edges { node { id objectType } } } }',{c:'HK'});
  let out='';
  try{ const j=JSON.parse(r.body); out='edges='+(j.data&&j.data.newTitles?j.data.newTitles.edges.length:'?')+' '+JSON.stringify(j.data&&j.data.newTitles&&j.data.newTitles.edges.slice(0,3)); }catch(e){ out=r.body.slice(0,160); }
  console.log('  package='+p+' status='+r.s+' '+out.slice(0,260));
}
