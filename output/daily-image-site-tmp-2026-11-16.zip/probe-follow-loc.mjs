const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
  '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

async function main() {
  for (const slug of ['hangzhou', 'wuhan']) {
    const url = `https://www.douban.com/location/${slug}/events`;
    const r = await fetch(url, {
      headers: { 'User-Agent': UA, Referer: `https://www.douban.com/location/${slug}/` },
    });
    const html = await r.text();
    const blocks = html.split('<li class="list-entry"').slice(1);
    console.log('=====', slug, blocks.length);
    for (const b of blocks) {
      const id = (b.match(/href="https:\/\/www\.douban\.com\/event\/(\d+)\//) || [])[1];
      const loc = (b.match(/<li title="([^"]*)"/) || [])[1];
      const st = (b.match(/<time itemprop="startDate" datetime="([^"]*)"/) || [])[1];
      const en = (b.match(/<time itemprop="endDate" datetime="([^"]*)"/) || [])[1];
      const title = (b.match(/<span itemprop="summary">([\s\S]*?)<\/span>/) || [])[1];
      console.log(
        `${id} | start=${st} end=${en} | loc=${JSON.stringify(loc)} | title=${(title || '').slice(0, 40)}`,
      );
    }
  }
}

main().catch((e) => console.error('ERR', e && e.message));
