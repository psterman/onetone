﻿import https from 'node:https';
function get(url, headers={}, depth=0){
  return new Promise((res)=>{
    if(depth>6) return res({s:0,body:'TOO_MANY_REDIRECT'});
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','Accept':'text/html,application/json,*/*','Accept-Language':'zh-CN,zh;q=0.9'},headers)},r=>{
      if([301,302,303,307,308].includes(r.statusCode)&&r.headers.location){
        return get(new URL(r.headers.location,url).href,headers,depth+1).then(x=>res({...x,chain:(x.chain||[]).concat(url+' -> '+r.headers.location)}));
      }
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(25000,()=>{try{req.destroy();}catch(e){} res({s:0,body:'TIMEOUT'})});
  });
}
console.log('=== A. 豆瓣「正在热映」/「即将上映」 ===');
for(const [n,u] of [['正在热映','https://movie.douban.com/cinema/nowplaying'],['即将上映','https://movie.douban.com/cinema/coming']]){
  const r=await get(u,{Referer:'https://movie.douban.com/'});
  console.log('  ['+n+'] status='+r.s+' len='+r.body.length+' ct='+(r.ct||'').slice(0,25));
  if(r.s===200){
    const items=r.body.match(/<div class="item"[\s\S]{0,3000}?<\/div>\s*<\/div>\s*<\/div>/g)||[];
    console.log('     item 块数='+items.length);
    const t=r.body.match(/<span class="title">[\s\S]{0,300}?<\/span>/)||[];
    console.log('     title 样例: '+JSON.stringify((t[0]||'').replace(/\s+/g,' ')));
    console.log('     img 样例: '+JSON.stringify((r.body.match(/<img[^>]*src="(https:\/\/img\d+\.doubanio\.com[^"]*)"/)||[])[1]));
  }
}
console.log('\n=== B. 猫眼系 ===');
for(const [n,u,h] of [
  ['猫眼内地热映API','https://api.maoyan.com/mmdb/movie/v5/list/hot.json?ci=1',{Referer:'https://www.maoyan.com/'}],
  ['猫眼即将上映API','https://api.maoyan.com/mmdb/movie/v5/list/coming.json?ci=1&limit=20',{Referer:'https://www.maoyan.com/'}],
  ['猫眼票房dashboard','https://piaofang.maoyan.com/dashboard-ajax?orderType=0',{Referer:'https://piaofang.maoyan.com/'}],
  ['猫眼films/box','https://www.maoyan.com/films/box',{Referer:'https://www.maoyan.com/'}],
  ['猫眼新片预告','https://www.maoyan.com/films/coming-soon',{Referer:'https://www.maoyan.com/'}],
]){
  const r=await get(u,h);
  let out='status='+r.s+' len='+r.body.length+' '+r.body.slice(0,130).replace(/\s+/g,' ');
  console.log('  ['+n+'] '+out);
}
