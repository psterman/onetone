﻿import https from 'node:https';
function get(url, headers={}) {
  return new Promise((res)=>{
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','Accept':'*/*','Accept-Language':'zh-CN,zh;q=0.9'},headers)},r=>{
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(25000,()=>{try{req.destroy();}catch(e){} res({s:0,body:'TIMEOUT'})});
  });
}
console.log('=== A. 猫眼 hot+coming 字段结构 ===');
let r=await get('https://api.maoyan.com/mmdb/movie/v5/list/hot.json?ci=1',{Referer:'https://www.maoyan.com/'});
try{
  const j=JSON.parse(r.body); const d=j.data||{};
  console.log('  顶层键: '+Object.keys(d).join(','));
  console.log('  hot='+(d.hot||[]).length+'  coming='+(d.coming||[]).length);
  if(d.hot&&d.hot[0]){
    const h=d.hot[0];
    console.log('  hot[0] 键: '+Object.keys(h).join(','));
    console.log('  hot[0]: '+JSON.stringify({id:h.id,title:h.title,score:h.score,star:h.star,showInfo:h.showInfo,releaseInfo:h.releaseInfo,img:h.img,version:h.version,rt:h.rt,globalReleased:h.globalReleased}).slice(0,600));
    console.log('  hot[0].ctors: '+JSON.stringify((h.actors||[]).slice(0,3)));
  }
  if(d.coming&&d.coming[0]){
    const c=d.coming[0];
    console.log('  coming[0] 键: '+Object.keys(c).join(','));
    console.log('  coming[0]: '+JSON.stringify({id:c.id,title:c.title,img:c.img,releaseInfo:c.releaseInfo,showInfo:c.showInfo,rt:c.rt,version:c.version}).slice(0,600));
  }
}catch(e){ console.log('  parse fail '+r.body.slice(0,200)); }

console.log('\n=== B. 猫眼封面可达性（裸连 / 带 Referer） ===');
try{
  const j=JSON.parse(r.body); const h=(j.data.hot||[])[0]||{};
  const pic=h.img||'';
  console.log('  pic url = '+(pic||'(无)'));
  if(pic){
    const a=await get(pic);
    const b=await get(pic,{Referer:'https://www.maoyan.com/'});
    console.log('  裸连 status='+a.s+' len='+a.body.length+' ct='+(a.ct||'').slice(0,24));
    console.log('  带Referer status='+b.s+' len='+b.body.length+' ct='+(b.ct||'').slice(0,24));
  }
}catch(e){ console.log('  '+e.message); }
