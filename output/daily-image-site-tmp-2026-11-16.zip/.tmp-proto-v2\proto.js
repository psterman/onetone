/* v2 形态原型渲染器 —— 过滤算法就是未来 site/app.js 要实现的那套 */
(function () {
  var D = window.__PROTO__ || {};
  var tabsEl = document.getElementById('tabs');
  var gridsEl = document.getElementById('grids');
  var countPill = document.getElementById('countPill');
  var inkEl = document.getElementById('tabInk');
  var loading = document.getElementById('loading');

  var TABS = [
    { key: 'music', label: '听乐', accent: '#3ddc97' },
    { key: 'movie', label: '看片', accent: '#a78bfa' },
    { key: 'follow', label: '追更', accent: '#f472b6' },
  ];

  /* ── 每个 tab 的层级定义 ──
     level1 固定；level2 随 level1 变；level3 只有追更·本地演出有（城市→区/类型）。 */
  function levels(tabKey, sel) {
    if (tabKey === 'music') {
      var groups = [['cn', '中文榜'], ['intl', '国际榜'], ['scene', '场景榜']];
      var l1 = [{ label: '全部', tag: null }].concat(groups.map(function (g) { return { label: g[1], tag: '@g:' + g[0] }; }));
      var l2 = [];
      if (sel.l1 && sel.l1.indexOf('@g:') === 0) {
        var gk = sel.l1.slice(3);
        (D.music.charts || []).filter(function (c) { return c.group === gk; }).forEach(function (c) {
          l2.push({ label: c.label, tag: c.label, key: c.key });
        });
      }
      return [l1, l2];
    }
    if (tabKey === 'movie') {
      /* 看片 = 电影 + 视频 合成一个 tab：
         L1 全部│电影│视频 → L2 电影给「正在放映/近期即将上映」，视频给「B站热门/抖音热门」 */
      var l1 = [
        { label: '全部', tag: null },
        { label: '电影', tag: '@k:movie' },
        { label: '视频', tag: '@k:video' },
      ];
      var l2 = [];
      if (sel.l1 === '@k:movie') {
        l2 = (D.movie.sections || []).map(function (s) { return { label: s.label, tag: s.label }; });
      } else if (sel.l1 === '@k:video') {
        l2 = (D.video.sections || []).map(function (s) { return { label: s.label, tag: s.label }; });
      }
      return [l1, l2];
    }
    /* follow */
    var l1 = [{ label: '全部', tag: null }, { label: '频道新更', tag: '@f:ch' }, { label: '本地演出', tag: '@f:city' }];
    var l2 = [];
    if (sel.l1 === '@f:ch') {
      (D.follow.channels || []).forEach(function (c) { l2.push({ label: c.label, tag: c.label }); });
    } else if (sel.l1 === '@f:city') {
      (D.follow.cities || []).forEach(function (c) { l2.push({ label: c.name, tag: c.name }); });
    }
    var l3 = [];
    if (sel.l1 === '@f:city' && sel.l2 && sel.l2 !== '全部') {
      var city = (D.follow.cities || []).filter(function (c) { return c.name === sel.l2; })[0];
      if (city) {
        l3 = [{ label: '全部区', tag: null }].concat(city.districts.map(function (d) { return { label: d, tag: d }; }));
        l3 = l3.concat(city.types.map(function (t) { return { label: t, tag: t }; }));
      }
    }
    return [l1, l2, l3];
  }

  /* ── 取当前选中条件下的条目 ── */
  function itemsFor(tabKey, sel) {
    if (tabKey === 'music') {
      var charts = D.music.charts || [];
      if (sel.l2 && sel.l2 !== '全部') {
        var c = charts.filter(function (x) { return x.label === sel.l2; })[0];
        return c ? c.items.slice() : [];
      }
      var out = [];
      charts.forEach(function (c) {
        if (sel.l1 && sel.l1.indexOf('@g:') === 0 && c.group !== sel.l1.slice(3)) return;
        out = out.concat(c.items);
      });
      return out;
    }
    if (tabKey === 'movie') {
      var msec = D.movie.sections || [];
      var vsec = D.video.sections || [];
      var picked = function (secs) {
        if (sel.l2 && sel.l2 !== '全部') {
          var one = secs.filter(function (s) { return s.label === sel.l2; })[0];
          return one ? one.items.slice() : [];
        }
        return secs.reduce(function (a, s) { return a.concat(s.items); }, []);
      };
      if (sel.l1 === '@k:movie') return picked(msec);
      if (sel.l1 === '@k:video') return picked(vsec);
      return picked(msec).concat(picked(vsec));
    }
    /* follow */
    if (sel.l1 === '@f:ch') {
      if (sel.l2 && sel.l2 !== '全部') {
        var ch = (D.follow.channels || []).filter(function (c) { return c.label === sel.l2; })[0];
        return ch ? ch.items.slice() : [];
      }
      return (D.follow.channels || []).reduce(function (a, c) { return a.concat(c.items); }, []);
    }
    if (sel.l1 === '@f:city') {
      if (sel.l2 && sel.l2 !== '全部') {
        var city = (D.follow.cities || []).filter(function (c) { return c.name === sel.l2; })[0];
        if (!city) return [];
        var items = city.items.slice();
        if (sel.l3 && sel.l3 !== '全部区') {
          items = items.filter(function (it) { return (it.tags || []).indexOf(sel.l3) >= 0; });
        }
        return items;
      }
      return (D.follow.cities || []).reduce(function (a, c) { return a.concat(c.items); }, []);
    }
    var all = (D.follow.channels || []).reduce(function (a, c) { return a.concat(c.items); }, [])
      .concat((D.follow.cities || []).reduce(function (a, c) { return a.concat(c.items); }, []));
    return all;
  }

  /* ── 渲染 ── */
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  }

  function safeHref(u) {
    var s = String(u || '');
    return /^https?:\/\//i.test(s) ? s : '';
  }

  /* ── 封面懒加载 ──
     真站的 .news-thumb-img 默认 opacity:0，靠 IntersectionObserver 把
     data-src 换成 src、图片 load 后给父框加 .is-loaded 才显影。
     不抄这一段 → 550 个封面全是空白框。 */
  var io = ('IntersectionObserver' in window)
    ? new IntersectionObserver(function (entries) {
        entries.forEach(function (e) {
          if (!e.isIntersecting) return;
          var img = e.target;
          var u = img.getAttribute('data-src');
          if (u) { img.removeAttribute('data-src'); img.src = u; }
          io.unobserve(img);
        });
      }, { rootMargin: '300px' })
    : null;

  function rankRow(it, idx) {
    var li = el('li', 'news-item rank-item');
    li.setAttribute('data-tags', (it.tags || []).join(' '));
    var href = safeHref(it.link);
    var box;
    if (href) {
      box = el('a', 'news-link has-thumb');
      box.href = href; box.target = '_blank'; box.rel = 'noopener noreferrer';
    } else {
      box = el('span', 'news-link news-link-plain has-thumb');
    }
    box.appendChild(el('span', 'rank-no', String(it.rank || idx + 1)));
    if (it.cover) {
      var cov = el('span', 'news-thumb rank-cover');
      var img = document.createElement('img');
      img.className = 'news-thumb-img';
      img.alt = '';
      img.setAttribute('data-src', it.cover);
      img.width = 56; img.height = 56; img.decoding = 'async';
      img.referrerPolicy = 'no-referrer';
      img.addEventListener('load', function () { cov.className += ' is-loaded'; });
      img.addEventListener('error', function () { cov.className += ' is-failed'; });
      cov.appendChild(img);
      box.appendChild(cov);
      if (io) io.observe(img); else img.src = it.cover;
    } else {
      var ph = el('span', 'news-thumb rank-cover rank-cover-empty', (it.title || '?').charAt(0));
      box.appendChild(ph);
    }
    var body = el('span', 'news-body');
    body.appendChild(el('span', 'news-title', it.title || ''));
    if (it.subtitle || it.meta) body.appendChild(el('span', 'news-desc', [it.subtitle, it.meta].filter(Boolean).join(' · ')));
    var meta = el('span', 'news-meta');
    if (it.source) meta.appendChild(el('span', 'news-src', it.source));
    if (it.tag) meta.appendChild(el('span', 'news-tag', it.tag));
    body.appendChild(meta);
    box.appendChild(body);
    li.appendChild(box);
    return li;
  }

  var state = { tab: 'music', sel: { music: { l1: '全部', l2: '全部' }, movie: { l1: '全部', l2: '全部' }, follow: { l1: '全部', l2: '全部', l3: '全部区' } } };

  function moveInk() {
    var b = tabsEl.querySelector('.tab.is-active');
    if (!b || !inkEl) return;
    var host = document.getElementById('topbar');
    var pr = host.getBoundingClientRect();
    var r = b.getBoundingClientRect();
    inkEl.style.width = r.width + 'px';
    inkEl.style.transform = 'translateX(' + (r.left - pr.left) + 'px)';
  }

  function renderTabs() {
    tabsEl.innerHTML = '';
    TABS.forEach(function (t) {
      var b = el('button', 'tab');
      b.type = 'button';
      b.setAttribute('role', 'tab');
      b.setAttribute('data-tab', t.key);
      b.textContent = t.label;
      if (t.key === state.tab) b.className = 'tab is-active';
      tabsEl.appendChild(b);
    });
    moveInk();
  }

  function renderChips(grid, tabKey, sel, items) {
    var lv = levels(tabKey, sel);
    var captions = ['板块', '分类', '细分'];
    lv.forEach(function (opts, i) {
      if (!opts.length) return;
      var box = el('div', 'chips chips-tags');
      var cap = el('span', 'chips-cap', captions[i] || '分类');
      box.appendChild(cap);
      opts.forEach(function (o) {
        var c = el('button', 'chip', o.label);
        c.type = 'button';
        c.setAttribute('data-tag', o.tag === null ? '' : o.tag);
        c.addEventListener('click', function () {
          if (i === 0) { sel.l1 = o.tag === null ? '全部' : o.tag; sel.l2 = '全部'; sel.l3 = '全部区'; }
          else if (i === 1) { sel.l2 = o.tag === null ? '全部' : o.tag; sel.l3 = '全部区'; }
          else { sel.l3 = o.tag === null ? '全部区' : o.tag; }
          render();
        });
        box.appendChild(c);
      });
      grid.appendChild(box);
    });
  }

  function render() {
    var tabKey = state.tab;
    var tab = TABS.filter(function (t) { return t.key === tabKey; })[0];
    var sel = state.sel[tabKey];
    gridsEl.innerHTML = '';
    var grid = el('section', 'grid grid-rank is-active');
    grid.id = 'grid-' + tabKey;
    grid.setAttribute('role', 'tabpanel');
    grid.style.setProperty('--tab-accent', tab.accent);

    var items = itemsFor(tabKey, sel);
    renderChips(grid, tabKey, sel, items);

    var sep = el('div', 'rank-sep', items.length + ' 条');
    grid.appendChild(sep);

    var list = el('ul', 'news-list rank-list');
    items.forEach(function (it, i) { list.appendChild(rankRow(it, i)); });
    grid.appendChild(list);
    gridsEl.appendChild(grid);

    countPill.textContent = items.length + ' 条';
    document.getElementById('brandDate').textContent =
      '原型 · 真实数据 · ' + new Date(D.generatedAt || Date.now()).toLocaleString('zh-CN');
  }

  tabsEl.addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('[data-tab]') : null;
    if (!b) return;
    state.tab = b.getAttribute('data-tab');
    renderTabs();
    render();
  });

  if (loading) loading.remove();
  renderTabs();
  render();
})();
