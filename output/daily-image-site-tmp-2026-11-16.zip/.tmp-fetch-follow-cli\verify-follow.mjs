/** 真实抓取后的核对脚本（打印契约要点 + 封面落盘情况） */
import fs from 'node:fs';
import path from 'node:path';
import { SRC_LOCAL } from '../paths.mjs';

const date = process.argv[2] || '2026-11-16';
const file = path.join(SRC_LOCAL, date, `follow_${date}.json`);

if (!fs.existsSync(file)) {
  console.log('文件不存在：', file);
  process.exit(1);
}

const raw = fs.readFileSync(file, 'utf8');
const p = JSON.parse(raw);

console.log('=== 文件 ===');
console.log('  路径：', file);
console.log('  字节：', Buffer.byteLength(raw), `(${(Buffer.byteLength(raw) / 1024).toFixed(1)} KB)`);
console.log('  顶层键：', JSON.stringify(Object.keys(p)));
console.log('  date：', p.date, '| generatedAt：', p.generatedAt);

console.log('\n=== 条目数 ===');
console.log('  schedule：', p.schedule.length, '条');
console.log('  events：', p.events.length, '条');
console.log('  cities：', p.cities.length, '个 →', p.cities.join('、'));

console.log('\n=== channels（平台 chip 的有序清单）===');
p.channels.forEach((c, i) => {
  const n = p.schedule.filter((x) => x.tags.includes(`@2:${c}`)).length;
  console.log(`  ${String(i + 1).padStart(2)}. ${c}（${n} 条）`);
});
const must = ['Netflix', 'HBO Max', '迪士尼+', 'Hulu', 'Peacock', 'Prime Video', 'Paramount+', 'Apple TV', '腾讯视频', '优酷', '爱奇艺', '芒果TV', 'B站番剧', '港剧'];
console.log('  用户点名的平台是否都在：', must.map((m) => `${m}=${p.channels.includes(m) ? '有' : '缺'}`).join(' '));
console.log('  每个 chip 都有条目：', p.channels.every((c) => p.schedule.some((x) => x.tags.includes(`@2:${c}`))));

console.log('\n=== languages（语言 chip 的有序清单）===');
p.languages.forEach((l, i) => {
  const n = p.schedule.filter((x) => x.tags.includes(`@3:${l}`)).length;
  console.log(`  ${String(i + 1).padStart(2)}. ${l}（${n} 条）`);
});

console.log('\n=== 演出的区 / 类型 ===');
const dist = new Map();
const types = new Map();
for (const e of p.events) {
  for (const t of e.tags) {
    if (t.startsWith('@3:')) dist.set(t.slice(3), (dist.get(t.slice(3)) || 0) + 1);
    if (t.startsWith('@4:')) types.set(t.slice(3), (types.get(t.slice(3)) || 0) + 1);
  }
}
console.log('  行政区（@3）：', dist.size, '个 →', [...dist.entries()].map(([k, v]) => `${k}(${v})`).join(' '));
console.log('  类型（@4）：', types.size, '个 →', [...types.entries()].map(([k, v]) => `${k}(${v})`).join(' '));
console.log('  没写 @3 的条目：', p.events.filter((e) => !e.tags.some((t) => t.startsWith('@3:'))).length, '条');
console.log('  没写 @4 的条目：', p.events.filter((e) => !e.tags.some((t) => t.startsWith('@4:'))).length, '条');

console.log('\n=== 封面本地化 ===');
const coverDir = path.join(SRC_LOCAL, date, 'follow-covers');
const files = fs.existsSync(coverDir) ? fs.readdirSync(coverDir) : [];
const localMarks = [...p.schedule, ...p.events].filter((x) => x.cover.startsWith('local:follow-covers/'));
const remoteDouban = [...p.schedule, ...p.events].filter((x) => /doubanio\.com/i.test(x.cover));
const emptyCover = [...p.schedule, ...p.events].filter((x) => !x.cover);
console.log('  follow-covers/ 里的文件：', files.length);
console.log('  条目里 local: 标记：', localMarks.length);
console.log('  还残留 doubanio 远程 URL 的条目：', remoteDouban.length);
console.log('  封面为空的条目：', emptyCover.length);
const bytes = files.reduce((n, f) => n + fs.statSync(path.join(coverDir, f)).size, 0);
console.log('  封面总字节：', bytes, `(${(bytes / 1024 / 1024).toFixed(2)} MB)`);

console.log('\n=== errors ===');
console.log('  条数：', p.errors.length);
for (const e of p.errors) console.log('   -', e);

console.log('\n=== 契约抽查 ===');
console.log('  条目字段（9 个）：', JSON.stringify(Object.keys(p.schedule[0] || p.events[0] || {})));
console.log('  tags 样例：', JSON.stringify((p.schedule[0] || {}).tags), JSON.stringify((p.events[0] || {}).tags));
const bad = [...p.schedule, ...p.events].filter((x) => {
  const layers = x.tags.map((t) => Number(t.slice(1, t.indexOf(':'))));
  return new Set(layers).size !== layers.length || layers.some((n, i) => i > 0 && n <= layers[i - 1]);
});
console.log('  tags 层号异常的条目：', bad.length);
console.log('  rank 连号（schedule）：', p.schedule.every((x, i) => x.rank === i + 1), '（events）：', p.events.every((x, i) => x.rank === i + 1));
console.log('  有没有 http:// 的 link：', [...p.schedule, ...p.events].filter((x) => x.link.startsWith('http://')).length);
