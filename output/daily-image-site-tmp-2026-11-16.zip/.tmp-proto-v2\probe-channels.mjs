/* 临时探针：核查 TVmaze schedule 里各频道的真实分布（原型为什么没出现 Netflix/HBO Max） */
const BASE = '2026-11-16';

async function main() {
  const agg = new Map();
  for (const country of ['US', 'CN', 'JP', 'KR', 'GB']) {
    for (let k = 0; k < 3; k++) {
      const d = new Date(Date.parse(BASE + 'T00:00:00Z') + k * 86400000).toISOString().slice(0, 10);
      const url = `https://api.tvmaze.com/schedule?country=${country}&date=${d}`;
      let j = [];
      try {
        j = await fetch(url).then((r) => r.json());
      } catch (e) {
        console.log(`${country} ${d} ERR ${e.message}`);
        continue;
      }
      const day = new Map();
      for (const e of j) {
        const s = e.show || (e._embedded && e._embedded.show);
        if (!s) continue;
        const w = s.webChannel && s.webChannel.name;
        const n = s.network && s.network.name;
        const key = w || n || '(none)';
        day.set(key, (day.get(key) || 0) + 1);
        agg.set(key, (agg.get(key) || 0) + 1);
      }
      const top = [...day.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6)
        .map(([k, v]) => `${k}:${v}`).join(', ');
      console.log(`${country} ${d} total=${j.length} | ${top}`);
    }
  }
  console.log('--- 3 天 5 国合计 ---');
  console.log([...agg.entries()].sort((a, b) => b[1] - a[1])
    .map(([k, v]) => `${k}=${v}`).join(' | '));

  /* 全量 schedule（不限国家）：看 Netflix / HBO Max / Prime Video 到底有没有 */
  console.log('--- 全量 schedule（不限国家）---');
  const all = new Map();
  for (let k = 0; k < 3; k++) {
    const d = new Date(Date.parse(BASE + 'T00:00:00Z') + k * 86400000).toISOString().slice(0, 10);
    const j = await fetch(`https://api.tvmaze.com/schedule?date=${d}`).then((r) => r.json());
    const day = new Map();
    for (const e of j) {
      const s = e.show || {};
      const key = (s.webChannel && s.webChannel.name) || (s.network && s.network.name) || '(none)';
      day.set(key, (day.get(key) || 0) + 1);
      all.set(key, (all.get(key) || 0) + 1);
    }
    console.log(`ALL ${d} total=${j.length} | 频道数=${day.size}`);
  }
  const named = ['Netflix', 'HBO Max', 'HBO', 'Disney+', 'Hulu', 'Peacock', 'Prime Video', 'Apple TV+', 'Paramount+'];
  console.log('用户点名的平台 -> ' + named.map((n) => `${n}=${all.get(n) || 0}`).join(' | '));
  console.log('全量合计 top20 -> ' + [...all.entries()].sort((a, b) => b[1] - a[1]).slice(0, 20)
    .map(([k, v]) => `${k}=${v}`).join(' | '));
  console.log(`全量频道总数=${all.size} · 3 天总条目=${[...all.values()].reduce((a, b) => a + b, 0)}`);
}

main().catch((e) => { console.error(e); process.exit(1); });
