/** 临时：检查变异锚点在源码里是否唯一命中 */
import fs from 'node:fs';

const src = fs.readFileSync('E:/voice-pilot/daily-image-site/tools/fetch-follow.mjs', 'utf8');

const anchors = [
  ['M1 兜底 URL 自检', 'if (URL_RE.test(v)) throw new Error(`兜底输出含 URL：${k}=${v}`);'],
  ['M2 兜底剥 URL', `.replace(/https?:\\/\\/[^\\s"'<>]+/gi, ' ')`],
  ['M3 L1 板块名', "export const L1_SCHEDULE = '频道新更';"],
  ['M4 别名表失效', 'if (b.match.some((m) => name === m || name.startsWith(m))) return b.label;'],
  ['M5 腾讯视频改名', "{ label: '腾讯视频', match: ['Tencent QQ', 'Tencent Video', 'Tencent'] },"],
  ['M6 换回 /schedule', 'const raw = await httpGet(`${TVMAZE_BASE}/schedule/full?date=${d}`, {'],
  ['M7 去掉 airdate 过滤', "if (target && String(ep.airdate || '') !== target) continue;"],
  ['M8 _embedded 顺序', 'const show = (ep._embedded && ep._embedded.show) || ep.show;'],
  ['M9 同剧去重', 'if (prev) {'],
  ['M10 类型白名单失效', 'if (types && showType && !types.includes(showType)) continue;'],
  ['M11 type 缺失被丢', "if (types && showType && !types.includes(showType)) continue;"],
  ['M12 行政区被切掉', 'district = parts[0];'],
  ['M13 演出不写 @3', 'if (district) tags.push(`@3:${district}`);'],
  ['M14 演出瞎写 @4', 'if (type) tags.push(`@4:${type}`);'],
  ['M15 封面不本地化', "it.cover = 'local:follow-covers/' + name;"],
  ['M16 封面不带 Referer', 'const buf = await httpBinary(u, { Referer: DOUBAN_IMAGE_REFERER }, { fetchImpl: opts.fetchImpl });'],
  ['M17 同城不带 Referer', 'await httpGet(url, { headers: { Referer: doubanReferer(slug) }, fetchImpl: doFetch })'],
  ['M18 城市 slug', "{ name: '北京', slug: 'beijing' },"],
  ['M19 去掉 rank 字段', 'function normalizeItem(it, i) {\n  const o = it || {};\n  return {\n    rank: i + 1,'],
  ['M20 rank 不从 1 开始', 'rank: i + 1,'],
  ['M21 顶层少 channels', 'channels: Array.isArray(channels) && channels.length ? channels.map((c) => String(c)) : deriveChannels(sched),'],
  ['M22 languages 不排序', 'const d = (count.get(b) || 0) - (count.get(a) || 0);'],
  ['M23 兜底配置误开', '      enabled: false,\n      fallbacks: [],\n      path: p,\n      missing: true,'],
  ['M24 不升 https', "export function toHttps(url) {\n  const s = String(url || '');\n  return s.startsWith('http://') ? 'https://' + s.slice('http://'.length) : s;\n}"],
  ['M25 平台顺序', 'for (const ch of CHANNEL_PRIORITY) {'],
  ['M26 港剧混排', "export const CHANNEL_SOURCES = ['B站番剧', '港剧'];"],
  ['M27 类型判定失效', 'if (rule.re.test(t)) return rule.type;'],
  ['M28 events tag', 'tag: city,'],
  ['M29 兜底 link', 'link: doubanSearchLink(title),'],
  ['M30 其他平台封顶', 'for (const it of merged.slice(0, OTHER_MAX_TOTAL)) out.push(retagChannel(it, OTHER_CHANNEL));'],
  ['M31 B站多写语言层', "tags: normalizeTags([`@1:${L1_SCHEDULE}`, '@2:B站番剧']),"],
  ['M32 301 不跟随', 'if (REDIRECT_CODES.has(res.status) && loc) {'],
  ['M33 重试次数', 'attempts = HTTP_ATTEMPTS,'],
  ['M34 去掉 UA', "headers: { 'User-Agent': UA, Accept: '*/*', ...headers },"],
  ['M35 _key 可枚举', 'enumerable: false,'],
  ['M36 封面失败留远程 URL', "it.cover = '';"],
  ['M37 分组里长尾顺序', 'const rest = [...byChannel.entries()]'],
  ['M38 演出 source', 'source: EVENTS_SOURCE,'],
];

for (const [name, a] of anchors) {
  const n = src.split(a).length - 1;
  console.log((n === 1 ? 'OK  ' : '!!  ') + n + '  ' + name);
}
