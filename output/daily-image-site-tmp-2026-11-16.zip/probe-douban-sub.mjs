﻿import https from 'node:https';
function get(url, headers={}, depth=0) {
  return new Promise((res)=>{
    if(depth>4) return res({s:0,body:'TOO_MANY_REDIRECT'});
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)','Accept':'text/html,*/*'},headers)},r=>{
      if([301,302,303,307,308].includes(r.statusCode) && r.headers.location){
        return get(new URL(r.headers.location,url).href, headers, depth+1).then(x=>res({...x,chain:(x.chain||[]).concat(url+' -> '+r.headers.location)}));
      }
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(20000,()=>{req.destroy();res({s:0,body:'TIMEOUT'})});
  });
}
console.log('=== A. 豆瓣同城 跟随重定向 ===');
let r=await get('https://www.douban.com/location/beijing/events',{Referer:'https://www.douban.com/location/beijing/'});
console.log('status='+r.s+' len='+r.body.length);
console.log('  重定向链: '+JSON.stringify(r.chain||[]));
console.log('  标题: '+(r.body.match(/<title>([^<]*)<\/title>/)||[])[1]);
// 找行政区/分类入口
const dlinks=[...new Set((r.body.match(/href="([^"]*\/location\/beijing[^"]*)"/g)||[]).map(x=>x.replace(/^href="|"$/g,'')))];
console.log('  同城子链接('+dlinks.length+'): '+JSON.stringify(dlinks.slice(0,30)));
const catLinks=[...new Set((r.body.match(/class="[^"]*(?:tag|category)[^"]*"[^>]*>\s*([^<]{1,18})/g)||[]))];
console.log('  分类/标签片段: '+JSON.stringify(catLinks.slice(0,15)));
// 一条 item 的完整结构
const items=r.body.match(/<div class="item">[\s\S]{0,3000}?<\/div>\s*<\/div>/g)||[];
console.log('  item 数='+items.length);
if(items[0]) console.log('  首条 item:\n'+items[0].slice(0,1500).replace(/\n\s*\n/g,'\n'));
