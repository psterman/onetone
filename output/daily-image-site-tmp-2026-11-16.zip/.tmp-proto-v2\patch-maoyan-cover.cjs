/* 临时补丁：把猫眼封面换成裁剪后的小图参数（原图 430 KB → 39 KB） */
const fs = require('node:fs');
const P = 'E:/voice-pilot/daily-image-site/tools/.tmp-proto-v2/data.js';
const s = fs.readFileSync(P, 'utf8');
const j = JSON.parse(s.slice(s.indexOf('{'), s.lastIndexOf('}') + 1));

const Q = '?imageMogr2/thumbnail/200x200^/gravity/center/crop/200x200/quality/80';
let n = 0;
for (const sec of j.movie.sections) {
  for (const it of sec.items) {
    if (!it.cover || !/pipi\.cn/i.test(it.cover)) continue;
    const base = it.cover.replace(/\?.*$/, '');
    if (it.cover !== base + Q) { it.cover = base + Q; n++; }
  }
}
fs.writeFileSync(P, 'window.__PROTO__ = ' + JSON.stringify(j) + ';\n', 'utf8');
console.log(`已改 ${n} 个猫眼封面 URL · data.js ${(fs.statSync(P).size / 1024).toFixed(1)} KB`);
