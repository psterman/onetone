/* 临时探针 3：/schedule/full 里按剧去重后的 webChannel 分布（找 Netflix / HBO Max） */
const DAY = '2026-11-17';

async function main() {
  for (const country of ['US', 'GB', 'CN']) {
    const j = await fetch(`https://api.tvmaze.com/schedule/full?country=${country}&date=${DAY}`).then((r) => r.json());
    if (!Array.isArray(j)) { console.log(`${country} 非数组`); continue; }
    const shows = new Map();
    const web = new Map();
    const net = new Map();
    for (const e of j) {
      const s = (e._embedded && e._embedded.show) || e.show || {};
      const id = s.id || s.name;
      if (!shows.has(id)) shows.set(id, s);
      if (s.webChannel && s.webChannel.name) {
        web.set(s.webChannel.name, (web.get(s.webChannel.name) || 0) + 1);
      } else if (s.network && s.network.name) {
        net.set(s.network.name, (net.get(s.network.name) || 0) + 1);
      }
    }
    /* 按剧去重后再看 webChannel */
    const byShow = new Map();
    for (const s of shows.values()) {
      const w = s.webChannel && s.webChannel.name;
      if (w) byShow.set(w, (byShow.get(w) || 0) + 1);
    }
    console.log(`\n=== ${country} ${DAY} ===`);
    console.log(`条目 ${j.length} · 去重剧 ${shows.size} · webChannel 种类 ${byShow.size}`);
    console.log('按剧去重 webChannel: ' + [...byShow.entries()].sort((a, b) => b[1] - a[1])
      .map(([k, v]) => `${k}=${v}`).join(' | '));
    console.log('按剧去重 network top10: ' + [...net.entries()].sort((a, b) => b[1] - a[1]).slice(0, 10)
      .map(([k, v]) => `${k}=${v}`).join(' | '));
  }
}

main().catch((e) => { console.error(e); process.exit(1); });
