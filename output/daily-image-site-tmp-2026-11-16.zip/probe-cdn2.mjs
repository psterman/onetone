const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
const SEC = { Accept: "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8", "Sec-Fetch-Dest": "image", "Sec-Fetch-Mode": "no-cors", "Sec-Fetch-Site": "cross-site" };
const urls = [
  ["douban", "https://img3.doubanio.com/view/photo/m_ratio_poster/public/p2936346968.jpg"],
  ["bili",   "https://i1.hdslb.com/bfs/archive/5a202db2daa18fc4ffbdef57b233b587dad063e7.jpg"],
  ["netease","https://p1.music.126.net/Enhy6dPn4gpyqrKhVEQvgA==/109951170483249998.jpg"],
];
const refs = [
  ["no-ref", {}],
  ["3rd-party-origin", { Referer: "https://example.com/" }],
  ["our-site-origin", { Referer: "https://daily-image-site.pages.dev/" }],
];
for (const [lbl, u] of urls) {
  for (const [rl, extra] of refs) {
    const r = await fetch(u, { headers: { "User-Agent": UA, ...SEC, ...extra } });
    console.log(lbl.padEnd(8), rl.padEnd(18), "->", r.status, r.headers.get("content-type"));
  }
}