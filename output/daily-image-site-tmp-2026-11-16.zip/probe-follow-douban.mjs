const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
  '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

async function probe() {
  for (const slug of ['beijing', 'shanghai', 'hangzhou']) {
    const url = `https://www.douban.com/location/${slug}/events`;
    const r = await fetch(url, {
      headers: {
        'User-Agent': UA,
        Referer: `https://www.douban.com/location/${slug}/`,
      },
    });
    const html = await r.text();
    console.log('=== ', slug, r.status, 'len', html.length);
    const blocks = html.split('<li class="list-entry"').slice(1);
    console.log('   list-entry blocks:', blocks.length);
    if (blocks[0]) console.log('   block0:\n' + blocks[0].slice(0, 2200));
  }
}

probe().catch((e) => console.error('ERR', e && e.message));
