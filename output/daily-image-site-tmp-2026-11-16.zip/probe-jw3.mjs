﻿import https from 'node:https';
function req(url, method='POST', headers={}, body=null) {
  return new Promise((res)=>{
    const h=Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)','Accept':'*/*'},headers);
    const r=https.request(url,{method,headers:h},(resp)=>{
      let d='';resp.on('data',c=>d+=c);resp.on('end',()=>res({s:resp.statusCode,ct:resp.headers['content-type'],body:d}));
    });
    r.on('error',e=>res({s:0,body:'ERR '+e.message}));
    r.setTimeout(25000,()=>{r.destroy();res({s:0,body:'TIMEOUT'})});
    if(body) r.write(body);
    r.end();
  });
}
const JH={'Content-Type':'application/json','X-Client-Id':'justwatch','Origin':'https://www.justwatch.com','Referer':'https://www.justwatch.com/'};
console.log('=== JustWatch packages：试 platform 枚举 ===');
for(const p of ['WEB','MOBILE_WEB','ANDROID_TV','IOS','ANDROID']){
  const r=await req('https://apis.justwatch.com/graphql','POST',JH,JSON.stringify({query:'query($c:Country!,$p:Platform!){ packages(country:$c,platform:$p){ id technicalName name } }',variables:{c:'CN',p}}));
  let out=r.body.slice(0,260).replace(/\s+/g,' ');
  if(r.s===200){ try{ const j=JSON.parse(r.body); out='OK packages='+j.data.packages.length+' -> '+j.data.packages.map(x=>x.technicalName).join(', '); }catch(e){} }
  console.log('  platform='+p+' status='+r.s+' '+out);
}
console.log('\n=== JustWatch newTitles：试不带 language ===');
let r=await req('https://apis.justwatch.com/graphql','POST',JH,JSON.stringify({query:'query($c:Country!){ newTitles(first:3,country:$c){ edges { node { id titleText releaseYear } } } }',variables:{c:'CN'}}));
console.log('  status='+r.s+' '+(r.s===200?r.body.slice(0,400):r.body.slice(0,300)));
