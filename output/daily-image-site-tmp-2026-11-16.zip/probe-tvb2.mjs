﻿import https from 'node:https';
function get(url){
  return new Promise((res)=>{
    const req=https.get(url,{headers:{'User-Agent':'Mozilla/5.0','Accept':'application/json'}},r=>{
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,body:d}));
    });
    req.on('error',e=>res({s:0,body:''}));
    req.setTimeout(20000,()=>{try{req.destroy();}catch(e){} res({s:0,body:''})});
  });
}
console.log('=== A. TVB 剧（使徒行者 id=32664）能否拿到剧集 ===');
let r=await get('https://api.tvmaze.com/shows/32664/episodes');
console.log('  /shows/32664/episodes status='+r.s+' len='+r.body.length);
if(r.s===200){ try{ const a=JSON.parse(r.body); console.log('   集数='+a.length+' 最后3集: '+a.slice(-3).map(e=>'S'+e.season+'E'+e.number+' '+e.name+' ['+e.airdate+']').join(' | ')); }catch(e){ console.log('   '+r.body.slice(0,150)); } }
r=await get('https://api.tvmaze.com/shows/32664');
if(r.s===200){ const s=JSON.parse(r.body);
  console.log('  show: name='+s.name+' lang='+s.language+' type='+s.type+' status='+s.status);
  console.log('  network='+(s.network&&s.network.name)+' web='+(s.webChannel&&s.webChannel.name));
  console.log('  officialSite='+s.officialSite+' image='+(s.image&&s.image.medium));
  console.log('  premiered='+s.premiered+' 官方首页='+s.url);
}
console.log('\n=== B. TVmaze schedule 多国扩展（含 TW/GB/香港台） ===');
for(const c of ['US','CN','JP','KR','TW','GB','HK','SG']){
  const rr=await get('https://api.tvmaze.com/schedule?country='+c+'&date=2026-11-17');
  if(rr.s!==200){ console.log('  '+c+' status='+rr.s); continue; }
  let j=[]; try{ j=JSON.parse(rr.body); }catch(e){}
  const chs={}; for(const e of j){ const k=e.show.webChannel?e.show.webChannel.name:(e.show.network?e.show.network.name:'无'); chs[k]=(chs[k]||0)+1; }
  console.log('  '+c+' 条数='+String(j.length).padEnd(4)+' 频道: '+Object.entries(chs).sort((a,b)=>b[1]-a[1]).slice(0,8).map(([k,v])=>k+'×'+v).join(', '));
}
