const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
const u = "https://img3.doubanio.com/view/photo/m_ratio_poster/public/p2936346968.jpg";
const cases = [
  ["no referer", {}],
  ["referer=douban", { Referer: "https://movie.douban.com/" }],
  ["referer=example.com", { Referer: "https://example.com/" }],
  ["referer=site-like", { Referer: "https://daily-image-site.pages.dev/" }],
  ["accept img + no referer", { Accept: "image/avif,image/webp,image/apng,image/*,*/*;q=0.8", "Sec-Fetch-Dest": "image", "Sec-Fetch-Mode": "no-cors", "Sec-Fetch-Site": "cross-site" }],
];
for (const [label, extra] of cases) {
  try {
    const r = await fetch(u, { headers: { "User-Agent": UA, ...extra } });
    console.log(label.padEnd(26), "->", r.status, r.headers.get("content-type"));
  } catch (e) { console.log(label.padEnd(26), "-> ERR", e.message); }
}