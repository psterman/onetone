﻿import https from 'node:https';
function get(url, headers={}, depth=0){
  return new Promise((res)=>{
    if(depth>6) return res({s:0,body:'TOO_MANY_REDIRECT'});
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','Accept':'*/*','Accept-Language':'en-US,en;q=0.9'},headers)},r=>{
      if([301,302,303,307,308].includes(r.statusCode)&&r.headers.location){
        return get(new URL(r.headers.location,url).href,headers,depth+1).then(x=>res({...x,chain:(x.chain||[]).concat(r.headers.location)}));
      }
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(25000,()=>{try{req.destroy();}catch(e){} res({s:0,body:'TIMEOUT'})});
  });
}
function post(url, data, headers={}) {
  return new Promise((res)=>{
    const req=https.request(url,{method:'POST',headers:Object.assign({'Content-Type':'application/json','User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)','Content-Length':Buffer.byteLength(data)},headers),timeout:25000},(rp)=>{let d='';rp.on('data',c=>d+=c);rp.on('end',()=>res({s:rp.statusCode,body:d}));});
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.write(data); req.end();
  });
}
console.log('=== YouTube innertube：带 visitorData + 各种 browseId ===');
const yt=await get('https://www.youtube.com/feed/trending',{Accept:'text/html'});
const body=yt.body;
const key=(body.match(/"INNERTUBE_API_KEY":"([^"]+)"/)||[])[1];
let ctx=null;
try{ ctx=JSON.parse(body.match(/"INNERTUBE_CONTEXT":(\{"client":\{[\s\S]*?\}\})/)[1]).client; }catch(e){}
const vd=(body.match(/"visitorData":"([^"]+)"/)||[])[1];
console.log('  key='+(key?'有':'无')+' ctx='+(ctx?'有':'无')+' visitorData='+(vd?vd.slice(0,10)+'…':'无'));
if(ctx&&key){
  if(vd) ctx.visitorData=vd;
  const H={'Origin':'https://www.youtube.com','Referer':'https://www.youtube.com/feed/trending'};
  if(vd) H['X-Goog-Visitor-Id']=vd;
  const tries=[
    ['browse FEtrending', 'https://www.youtube.com/youtubei/v1/browse?key='+key+'&prettyPrint=false', {context:ctx,browseId:'FEtrending'}],
    ['browse FEwhat_to_watch', 'https://www.youtube.com/youtubei/v1/browse?key='+key+'&prettyPrint=false', {context:ctx,browseId:'FEwhat_to_watch'}],
    ['next FEtrending', 'https://www.youtube.com/youtubei/v1/next?key='+key+'&prettyPrint=false', {context:ctx,browseId:'FEtrending'}],
    ['browse FEtrending+params', 'https://www.youtube.com/youtubei/v1/browse?key='+key+'&prettyPrint=false', {context:ctx,browseId:'FEtrending',params:Buffer.from('{"browseId":"FEtrending"}').toString('base64')}],
  ];
  for(const [n,u,pay] of tries){
    const r=await post(u,JSON.stringify(pay),H);
    let o='status='+r.s+' len='+r.body.length;
    if(r.s===200){
      const vids=[...new Set([...r.body.matchAll(/"videoId":"([A-Za-z0-9_-]{11})"/g)].map(m=>m[1]))];
      const tt=[...r.body.matchAll(/"title":\{"runs":\[\{"text":"((?:[^"\\]|\\.){2,110})"/g)].map(m=>m[1]);
      const vc=[...r.body.matchAll(/"viewCountText":\{"simpleText":"([^"]+)"/g)].map(m=>m[1]);
      const ow=[...r.body.matchAll(/"ownerText":\{"runs":\[\{"text":"([^"]+)"/g)].map(m=>m[1]);
      const th=[...r.body.matchAll(/"thumbnails":\[\{"url":"(https:\/\/i\.ytimg\.com\/vi\/[^"]+)"/g)].map(m=>m[1]);
      o+=' videoId='+vids.length+' 标题='+tt.length+' 作者='+ow.length+' 封面='+th.length+' 播放量='+JSON.stringify(vc.slice(0,3));
      if(tt.length) o+=' 标题样例='+JSON.stringify(tt.slice(0,4));
    } else o+=' '+r.body.slice(0,110).replace(/\s+/g,' ');
    console.log('  ['+n+'] '+o);
  }
}
console.log('\n=== TikTok：跟重定向后的页面 + 完整参数 item_list ===');
let t=await get('https://ads.tiktok.com/business/creativecenter/inspiration/popular/hashtag/pc/en?period=7',{Referer:'https://ads.tiktok.com/'});
console.log('  CreativeCenter status='+t.s+' len='+t.body.length+' chain='+JSON.stringify(t.chain||[]));
for(const k of ['__NEXT_DATA__','SIGI_STATE','__NUXT__','hashtagName','challengeInfo','trend']){
  console.log('   含 "'+k+'": '+t.body.includes(k));
}
const tl=await get('https://www.tiktok.com/api/explore/item_list/?aid=1988&app_language=en&app_name=tiktok_web&browser_language=en-US&browser_name=Mozilla&browser_online=true&browser_platform=Win32&browser_version=5.0%20(Windows)&channel=tiktok_web&cookie_enabled=true&count=30&device_id=0&device_platform=web_pc&focus_state=true&from_page=explore&history_len=2&is_fullscreen=false&is_page_visible=true&os=windows&priority_region=&referer=&region=US&screen_height=1080&screen_width=1920&tz_name=Asia%2FTokyo&webcast_language=en',{Referer:'https://www.tiktok.com/explore'});
console.log('  tiktok item_list(全参数) status='+tl.s+' len='+tl.body.length+' '+tl.body.slice(0,160).replace(/\s+/g,' '));
const tr=await get('https://www.tiktok.com/trending',{Referer:'https://www.tiktok.com/'});
console.log('  tiktok /trending status='+tr.s+' len='+tr.body.length+' 含SIGI='+tr.body.includes('SIGI_STATE')+' 含__UNIVERSAL_DATA='+tr.body.includes('__UNIVERSAL_DATA_FOR_REHYDRATION'));
