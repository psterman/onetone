﻿import https from 'node:https';
function get(url, headers={}) {
  return new Promise((res)=>{
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','Accept':'text/html,*/*'},headers)},r=>{
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,body:d,url:r.url}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(20000,()=>{try{req.destroy();}catch(e){} res({s:0,body:'TIMEOUT'})});
  });
}
const r=await get('https://www.douban.com/location/wuhan/events',{Referer:'https://www.douban.com/location/wuhan/'});
console.log('status='+r.s+' 最终URL='+r.url+' len='+r.body.length);
const b=r.body;
const i=b.indexOf('week-music');
console.log('week-music 位置='+i);
if(i>0) console.log('片段: '+JSON.stringify(b.slice(i-160,i+160)));
console.log('匹配 week- 次数: '+[...b.matchAll(/\/events\/week-/g)].length);
for(const m of b.matchAll(/.{0,80}\/events\/week-[a-z]+.{0,60}/g)){ console.log('  '+JSON.stringify(m[0])); break; }
