const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
const H = { "User-Agent": UA, Referer: "https://movie.douban.com/" };
let total = 0, noRating = 0, noLink = 0, noCover = 0, oneTitle = 0, twoTitle = 0;
const single = [];
for (let p = 0; p < 10; p++) {
  const start = p * 25;
  const r = await fetch("https://movie.douban.com/top250?start=" + start, { headers: H });
  const t = await r.text();
  const raw = t.match(/<li\b[\s\S]*?<\/li>/gi) || [];
  const blocks = raw.filter(b => /movie\.douban\.com\/subject\/\d+/.test(b) && /class="title"/.test(b));
  total += blocks.length;
  for (const b of blocks) {
    if (!/<span class="rating_num"[^>]*>\s*([\d.]+)\s*<\/span>/i.test(b)) noRating++;
    if (!/<a\b[^>]*\bhref="(https?:\/\/movie\.douban\.com\/subject\/\d+\/)"/i.test(b)) noLink++;
    if (!/<img\b[^>]*\bsrc="([^"]+doubanio[^"]*)"/i.test(b)) noCover++;
    const ts = b.match(/<span class="title"[^>]*>([\s\S]*?)<\/span>/gi) || [];
    if (ts.length >= 2) twoTitle++; else { oneTitle++; if (single.length < 3) single.push({ p, start, titles: ts, snippet: b.slice(0, 400) }); }
  }
  console.log("page", p, "raw li=", raw.length, "movie blocks=", blocks.length);
  await new Promise(x => setTimeout(x, 500));
}
console.log("TOTAL movie blocks:", total, "| noRating", noRating, "noLink", noLink, "noCover", noCover, "| twoTitle", twoTitle, "oneTitle", oneTitle);
console.log("--- single-title sample ---");
console.log(JSON.stringify(single[0] || null, null, 1).slice(0, 900));