﻿import https from 'node:https';
function get(url, headers={}) {
  return new Promise((res)=>{
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)','Accept':'text/html,*/*'},headers)},r=>{
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d,loc:r.headers.location}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(20000,()=>{req.destroy();res({s:0,body:'TIMEOUT'})});
  });
}
console.log('=== A. 豆瓣同城：北京页里的「区/分类」链接 ===');
let r=await get('https://www.douban.com/location/beijing/events',{Referer:'https://www.douban.com/location/beijing/'});
console.log('status='+r.s+' len='+r.body.length);
const district=r.body.match(/href="[^"]*\/location\/beijing\/events\?[^"]*"[^>]*>([^<]{1,14})</g)||[];
const tagLinks=r.body.match(/<a[^>]*class="[^"]*(?:tag|category|subject)[^"]*"[^>]*>([^<]{1,16})</g)||[];
console.log('  events?参数链接: '+JSON.stringify(district.slice(0,20)));
console.log('  tag/category 类: '+JSON.stringify(tagLinks.slice(0,20)));
// 抽一条 item 看字段
const li=r.body.match(/<li[^>]*class="[^"]*list-entry[^"]*"[\s\S]{0,2500}?<\/li>/i);
if(li) console.log('  首条片段(前1200):\n'+li[0].slice(0,1200).replace(/\n\s*/g,'\n'));

console.log('\n=== B. 港剧候选源 ===');
const cands=[
  ['TVB节目表','https://programme.tvb.com/'],
  ['MyDramaList-release','https://mydramalist.com/release/?type=drama'],
  ['MyDramaList-search','https://mydramalist.com/search?q=cantonese'],
  ['豆瓣剧集榜','https://movie.douban.com/j/search_subjects?type=tv&tag=%E6%B8%AF%E5%89%A7&page_limit=20&page_start=0'],
  ['Viki','https://www.viki.com/'],
];
for(const [n,u] of cands){
  const rr=await get(u,{Referer:'https://movie.douban.com/'});
  console.log('  ['+n+'] status='+rr.s+' len='+rr.body.length+' ct='+(rr.ct||'').slice(0,30)+' head='+rr.body.slice(0,110).replace(/\s+/g,' '));
}
