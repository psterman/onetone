﻿import https from 'node:https';
function get(url, headers={}) {
  return new Promise((res)=>{
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','Accept':'text/html,application/json,*/*','Accept-Language':'zh-CN,zh;q=0.9'},headers)},r=>{
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(20000,()=>{try{req.destroy();}catch(e){} res({s:0,body:'TIMEOUT'})});
  });
}
console.log('=== A. 豆瓣 /coming 结构 ===');
const r=await get('https://movie.douban.com/coming',{Referer:'https://movie.douban.com/'});
console.log('  status='+r.s+' len='+r.body.length);
const items=r.body.match(/<div class="item"[\s\S]{0,4000}?<\/div>\s*<\/div>\s*<\/div>/g)||[];
console.log('  item 块='+items.length);
const titles=[...r.body.matchAll(/class="title"[^>]*>\s*(?:<span[^>]*>)?([^<]{2,40})/g)].map(m=>m[1].trim());
console.log('  标题数='+titles.length+' 样例='+JSON.stringify(titles.slice(0,10)));
const dates=[...r.body.matchAll(/class="release"[^>]*>([\s\S]{0,120}?)<\/div>/g)].map(m=>m[1].replace(/<[^>]+>/g,'').trim());
console.log('  上映日期数='+dates.length+' 样例='+JSON.stringify(dates.slice(0,8)));
const wish=[...r.body.matchAll(/(\d[\d,]*)\s*人想看/g)].map(m=>m[1]);
console.log('  想看人数样例='+JSON.stringify(wish.slice(0,8)));
const imgs=[...r.body.matchAll(/<img[^>]*src="(https:\/\/img\d+\.doubanio\.com\/view\/photo\/[^"]+)"/g)].map(m=>m[1]);
console.log('  封面数='+imgs.length+' 样例='+JSON.stringify(imgs.slice(0,2)));

console.log('\n=== B. 豆瓣 /cinema/nowplaying 结构（对照） ===');
const r2=await get('https://movie.douban.com/cinema/nowplaying',{Referer:'https://movie.douban.com/'});
const t2=[...r2.body.matchAll(/class="title"[^>]*>\s*(?:<span[^>]*>)?([^<]{2,40})/g)].map(m=>m[1].trim());
console.log('  标题数='+t2.length+' 样例='+JSON.stringify(t2.slice(0,10)));
const sc2=[...r2.body.matchAll(/class="rating_num"[^>]*>([\d.]+)/g)].map(m=>m[1]);
console.log('  评分样例='+JSON.stringify(sc2.slice(0,8)));

console.log('\n=== C. 猫眼按 movieIds 批量取详情（扩量） ===');
const mj=JSON.parse((await get('https://api.maoyan.com/mmdb/movie/v5/list/hot.json?ci=1',{Referer:'https://www.maoyan.com/'})).body);
const ids=(mj.data.movieIds||[]).slice(0,12);
console.log('  movieIds 总数='+(mj.data.movieIds||[]).length+' 取前12试');
for(const u of [
  'https://api.maoyan.com/mmdb/movie/v5/list/hot.json?ci=1&movieIds='+ids.join(','),
  'https://m.maoyan.com/ajax/movieOnInfoList?token=&movieIds='+ids.join(','),
]){
  const rr=await get(u,{Referer:'https://www.maoyan.com/'});
  let o='status='+rr.s+' len='+rr.body.length;
  try{ const k=JSON.parse(rr.body); const h=k.data&&k.data.hot; o+=' hot='+(h?h.length:'-'); if(h&&h[0]) o+=' 首条nm='+h[0].nm+' rt='+h[0].rt+' globalReleased='+h[0].globalReleased; }catch(e){ o+=' '+rr.body.slice(0,90); }
  console.log('  '+u.slice(30,80)+' -> '+o);
}
