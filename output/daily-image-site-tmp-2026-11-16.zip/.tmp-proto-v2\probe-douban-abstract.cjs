/* 临时探针 12：豆瓣单片 JSON 接口能不能补出「即将上映」的海报 */
const https = require('node:https');
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
const ID = '37150166'; // 琴弓师

const PATHS = [
  `/j/subject_abstract?subject_id=${ID}`,
  `/j/subject_abstract?subject_id=${ID}&ck=&for_mobile=1`,
  `/j/subject_abstract?subject_id=${ID}&_=`,
];

function get(url) {
  return new Promise((resolve) => {
    const req = https.get(url, { headers: { 'User-Agent': UA, Referer: 'https://movie.douban.com/', Accept: 'application/json, text/plain, */*' } }, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { body += c; });
      res.on('end', () => resolve({ status: res.statusCode, body }));
    });
    req.on('error', (e) => resolve({ status: 0, body: '', err: e.message }));
    req.setTimeout(15000, () => { try { req.destroy(); } catch { /* ignore */ } });
  });
}

(async () => {
  for (const p of PATHS) {
    const r = await get('https://movie.douban.com' + p);
    let cov = '';
    try {
      const j = JSON.parse(r.body);
      const s = j.subject || j;
      cov = (s.cover && (s.cover.url || s.cover)) || (s.pic && (s.pic.normal || s.pic.large)) || '';
    } catch (e) { cov = '(不是 JSON)'; }
    console.log(`${p}\n  HTTP ${r.status} · ${r.body.length} 字节 · cover=${String(cov).slice(0, 90)}`);
    if (r.status === 200 && r.body.length < 4000) console.log('  body: ' + r.body.slice(0, 300));
  }
})();
