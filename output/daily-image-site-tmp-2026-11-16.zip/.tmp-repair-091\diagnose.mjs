#!/usr/bin/env node
/* 一次性诊断脚本：找出 2026-11-14 见她 tab 里 id=091 对应的源图，
   并按 build.mjs 的 nonce 算法核对随机段是不是 962bbae53f。
   只读，不改任何东西。 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const ROOT = 'E:\\voice-pilot\\daily-image-site';
const SRC = 'D:\\daily-images\\src\\2026-11-14\\见她';
const R2 = 'D:\\daily-images\\r2\\2026-11-14\\jianshe';
const ID = '091';

const salt = fs.readFileSync(path.join(ROOT, '.img-salt'), 'utf8').trim();
console.log('salt =', salt);

const files = fs
  .readdirSync(SRC, { withFileTypes: true })
  .filter((d) => d.isFile() && /\.(jpe?g|png|gif|webp|bmp)$/i.test(d.name))
  .map((d) => d.name)
  .sort((a, b) => a.localeCompare(b, 'zh-CN', { numeric: true }));
console.log('源图张数 =', files.length);

const name = files[Number(ID) - 1];
const src = path.join(SRC, name);
const st = fs.statSync(src);
const buf = fs.readFileSync(src);
const h = crypto.createHash('sha256');
h.update(buf.subarray(0, 65536));
h.update(String(st.size));
const contentHash = h.digest('hex').slice(0, 16);
const nonce = crypto
  .createHash('sha256')
  .update(`${salt}|jianshe|${ID}|${contentHash}`)
  .digest('hex')
  .slice(0, 10);

console.log('id=' + ID + ' 的源图 =', name);
console.log('源图大小 =', st.size, 'B');
console.log('算出来的随机段 =', nonce, nonce === '962bbae53f' ? '✓ 与线上一致' : '✗ 与线上不一致');

for (const f of fs.readdirSync(R2)) {
  if (f.startsWith(nonce)) {
    const s = fs.statSync(path.join(R2, f));
    console.log('  产物', f, '=', s.size, 'B', s.size === 0 ? '★ 0 字节（坏的）' : '');
  }
}
