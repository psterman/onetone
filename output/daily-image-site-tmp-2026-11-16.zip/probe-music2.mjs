﻿import https from 'node:https';
function get(url, headers={}, depth=0){
  return new Promise((res)=>{
    if(depth>5) return res({s:0,body:'TOO_MANY_REDIRECT'});
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)','Accept':'*/*'},headers)},r=>{
      if([301,302,303,307,308].includes(r.statusCode)&&r.headers.location){
        return get(new URL(r.headers.location,url).href,headers,depth+1).then(x=>res({...x,chain:(x.chain||[]).concat(r.statusCode+' '+url+' -> '+r.headers.location)}));
      }
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(20000,()=>{try{req.destroy();}catch(e){} res({s:0,body:'TIMEOUT'})});
  });
}
console.log('=== A. 网易云官方全榜单（toplist/detail 权威清单） ===');
let r=await get('https://music.163.com/api/toplist/detail',{Referer:'https://music.163.com/'});
console.log('  status='+r.s+' len='+r.body.length);
try{
  const j=JSON.parse(r.body); const list=j.list||[];
  console.log('  榜单数='+list.length);
  for(const x of list){ console.log('    id='+String(x.id).padEnd(9)+' name='+String(x.name).padEnd(12)+' tracks='+String(x.trackCount).padEnd(5)+' update='+String(x.updateTime||'').slice(0,10)); }
}catch(e){ console.log('  parse fail '+r.body.slice(0,150)); }

console.log('\n=== B. Apple Music 官方 RSS（跟随重定向） ===');
for(const u of [
  'https://rss.applemarketingtools.com/api/v2/us/music/most-played/30/songs.json',
  'https://rss.applemarketingtools.com/api/v2/us/music/new-albums/30/albums.json',
  'https://rss.applemarketingtools.com/api/v2/us/music/playlists.json',
  'https://rss.applemarketingtools.com/api/v2/cn/music/most-played/30/songs.json',
]){
  const rr=await get(u);
  let out='status='+rr.s+' len='+rr.body.length;
  if(rr.s===200){ try{ const j=JSON.parse(rr.body); const f=j.feed&&j.feed.results&&j.feed.results[0]; out+=' feed='+(j.feed&&j.feed.title)+' 首条='+(f?(f.name||f.artistName||'?'):'无'); }catch(e){ out+=' '+rr.body.slice(0,80); } }
  if(rr.chain&&rr.chain.length) out+=' | 链: '+rr.chain.join(' ; ');
  console.log('  '+u.replace('https://rss.applemarketingtools.com/api/v2/','')+' -> '+out);
}

console.log('\n=== C. 其他平台榜单 ===');
for(const [n,u,h] of [
  ['QQ音乐热歌榜','https://c.y.qq.com/v8/fcg-bin/fcg_v8_toplist_cp.fcg?topid=26&format=json',{Referer:'https://y.qq.com/'}],
  ['QQ音乐新歌榜','https://c.y.qq.com/v8/fcg-bin/fcg_v8_toplist_cp.fcg?topid=27&format=json',{Referer:'https://y.qq.com/'}],
  ['酷狗热歌榜','https://mobilecdn.kugou.com/api/v5/rank/list?rank_type=1&page=1&pagesize=5',{Referer:'https://www.kugou.com/'}],
]){
  const rr=await get(u,h);
  let out='status='+rr.s+' len='+rr.body.length+' '+rr.body.slice(0,120).replace(/\s+/g,' ');
  console.log('  ['+n+'] '+out);
}
