﻿import https from 'node:https';
function get(url, headers={}) {
  return new Promise((res)=>{
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','Accept':'text/html,*/*'},headers)},r=>{
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(20000,()=>{try{req.destroy();}catch(e){} res({s:0,body:'TIMEOUT'})});
  });
}
const r=await get('https://movie.douban.com/coming',{Referer:'https://movie.douban.com/'});
const b=r.body;
const ti=b.lastIndexOf('<table');
console.log('table 位置='+ti);
const seg=b.slice(ti, ti+3000).replace(/\n\s*\n/g,'\n');
console.log(seg);
console.log('\n--- 行数 ---');
const rows=b.match(/<tr[^>]*>[\s\S]*?<\/tr>/g)||[];
console.log('tr 数='+rows.length);
if(rows[2]) console.log('\n--- 第3行 ---\n'+rows[2].replace(/\n\s*\n/g,'\n'));
