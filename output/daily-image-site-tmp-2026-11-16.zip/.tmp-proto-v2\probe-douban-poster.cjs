/* 临时探针 9：豆瓣「即将上映」条目能不能用 subject id 补出海报（og:image） */
const https = require('node:https');
const fs = require('node:fs');
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

const s = fs.readFileSync('E:/voice-pilot/daily-image-site/tools/.tmp-proto-v2/data.js', 'utf8');
const j = JSON.parse(s.slice(s.indexOf('{'), s.lastIndexOf('}') + 1));
const soon = (j.movie.sections.find((x) => x.label === '近期即将上映') || {}).items || [];
const douban = soon.filter((i) => /douban\.com\/subject\/(\d+)/.test(i.link));
console.log(`近期即将上映 ${soon.length} 条 · 豆瓣来源 ${douban.length} 条`);

function get(url) {
  return new Promise((resolve) => {
    const req = https.get(url, { headers: { 'User-Agent': UA, Referer: 'https://movie.douban.com/' } }, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { body += c; });
      res.on('end', () => resolve({ status: res.statusCode, body }));
    });
    req.on('error', (e) => resolve({ status: 0, body: '', err: e.message }));
    req.setTimeout(15000, () => { try { req.destroy(); } catch { /* ignore */ } });
  });
}

(async () => {
  for (const it of douban.slice(0, 5)) {
    const r = await get(it.link);
    const og = (r.body.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i) ||
      r.body.match(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i) || [])[1];
    console.log(`${it.title.padEnd(16)} HTTP ${r.status} og:image = ${og || '(无)'}`);
  }
})();
