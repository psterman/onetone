﻿import https from 'node:https';
function get(url, headers={}) {
  return new Promise((res)=>{
    const req=https.get(url,{headers:Object.assign({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','Accept':'*/*','Accept-Language':'zh-CN,zh;q=0.9'},headers)},r=>{
      let d='';r.on('data',c=>d+=c);r.on('end',()=>res({s:r.statusCode,ct:r.headers['content-type'],body:d}));
    });
    req.on('error',e=>res({s:0,body:'ERR '+e.message}));
    req.setTimeout(25000,()=>{try{req.destroy();}catch(e){} res({s:0,body:'TIMEOUT'})});
  });
}
console.log('=== A. 抖音热榜 JSON 结构（有没有视频信息） ===');
let r=await get('https://www.douyin.com/aweme/v1/web/hot/search/list/?device_platform=webapp&aid=6383&channel=channel_pc_web&detail_list=1',{Referer:'https://www.douyin.com/'});
try{
  const j=JSON.parse(r.body);
  console.log('  顶层键: '+Object.keys(j).join(','));
  const wl=j.data&&j.data.word_list;
  console.log('  data 键: '+(j.data?Object.keys(j.data).join(','):'-'));
  if(wl){ console.log('  word_list 条数='+wl.length);
    console.log('  首条键: '+Object.keys(wl[0]).join(','));
    console.log('  首条: '+JSON.stringify(wl[0]).slice(0,700));
  }
  const wl2=j.word_list;
  if(wl2){ console.log('  顶层 word_list='+wl2.length+' 首条键: '+Object.keys(wl2[0]).join(',')); console.log('  '+JSON.stringify(wl2[0]).slice(0,700)); }
}catch(e){ console.log('  parse fail '+r.body.slice(0,200)); }

console.log('\n=== B. 抖音 iesdouyin 热词榜结构 ===');
r=await get('https://www.iesdouyin.com/web/api/v2/hotsearch/billboard/word/',{Referer:'https://www.douyin.com/'});
try{ const j=JSON.parse(r.body); console.log('  键: '+Object.keys(j).join(',')+' word_list='+((j.word_list||[]).length));
  if(j.word_list&&j.word_list[0]) console.log('  首条: '+JSON.stringify(j.word_list[0]).slice(0,400));
}catch(e){ console.log('  '+r.body.slice(0,150)); }

console.log('\n=== C. YouTube feed/trending 里能不能抽出 trending 数据 ===');
r=await get('https://www.youtube.com/feed/trending',{Accept:'text/html'});
console.log('  status='+r.s+' len='+r.body.length);
const has=r.body.includes('ytInitialData');
console.log('  含 ytInitialData = '+has);
if(has){
  const i=r.body.indexOf('var ytInitialData = ');
  console.log('  位置='+i);
  // 抽 trendingRenderer 里的视频
  const vids=[...r.body.matchAll(/"videoId":"([A-Za-z0-9_-]{11})"[^}]{0,400}?"text":"([^"]{1,90})"/g)].slice(0,8);
  console.log('  抽出 videoId+标题: '+vids.length);
  vids.forEach(v=>console.log('     '+v[1]+' | '+v[2]));
  const thumbs=[...r.body.matchAll(/"videoId":"([A-Za-z0-9_-]{11})"[\s\S]{0,600}?https:\/\/i\.ytimg\.com\/vi\/([A-Za-z0-9_-]{11})/g)].slice(0,5);
  console.log('  缩略图对: '+thumbs.length+' '+JSON.stringify(thumbs.map(t=>t[1]+'->'+t[2])));
  const views=[...r.body.matchAll(/"viewCountText":\{"simpleText":"([^"]+)"/g)].slice(0,8).map(m=>m[1]);
  console.log('  播放量: '+JSON.stringify(views));
}

console.log('\n=== D. TikTok 后台 API（Creative Center） ===');
for(const u of [
  'https://ads.tiktok.com/creative_radar_api/v1/popular_trend/hashtag/list?period=7&page=1&limit=20&country_code=US',
  'https://ads.tiktok.com/creative_radar_api/v1/popular_trend/hashtag/list?period=7&limit=10&sort_by=popular',
]){
  const rr=await get(u,{Referer:'https://ads.tiktok.com/business/creativecenter/'});
  console.log('  '+u.slice(38,100)+' -> status='+rr.s+' len='+rr.body.length+' '+rr.body.slice(0,200).replace(/\s+/g,' '));
}
