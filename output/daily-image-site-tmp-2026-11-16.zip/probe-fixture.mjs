const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
const out = [];

// --- douban: take item 1 (two titles) and item 25 (single title?) ---
const r = await fetch("https://movie.douban.com/top250", { headers: { "User-Agent": UA, Referer: "https://movie.douban.com/" } });
const t = await r.text();
const blocks = t.match(/<li\b[\s\S]*?<\/li>/gi) || [];
out.push("=== DOUBAN block 1 ===");
out.push(blocks[0]);
out.push("=== DOUBAN block 25 ===");
out.push(blocks[24]);

// --- netease: 2 tracks, trimmed ---
const rn = await fetch("https://music.163.com/api/playlist/detail?id=3778678", { headers: { "User-Agent": UA } });
const jn = JSON.parse(await rn.text());
const pick = (x) => ({ id: x.id, name: x.name, artists: x.artists.map(a => ({ name: a.name })), album: { name: x.album.name, picUrl: x.album.picUrl }, duration: x.duration });
out.push("=== NETEASE 2 tracks ===");
out.push(JSON.stringify({ code: 200, result: { tracks: [pick(jn.result.tracks[0]), pick(jn.result.tracks[1])] } }, null, 2));

// --- bili: 2 items, trimmed ---
const rb = await fetch("https://api.bilibili.com/x/web-interface/popular?ps=50&pn=1", { headers: { "User-Agent": UA, Referer: "https://www.bilibili.com/" } });
const jb = JSON.parse(await rb.text());
const pickB = (x) => ({ title: x.title, pic: x.pic, bvid: x.bvid, owner: { name: x.owner.name }, stat: { view: x.stat.view }, duration: x.duration, short_link_v2: x.short_link_v2 });
out.push("=== BILI 2 items ===");
out.push(JSON.stringify({ code: 0, message: "0", data: { list: [pickB(jb.data.list[0]), pickB(jb.data.list[1])] } }, null, 2));

const fs = await import("node:fs");
const p = process.env.FIX_OUT;
fs.writeFileSync(p, out.join("\n"), "utf8");
console.log("written", p, fs.statSync(p).size);