const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
  '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

async function main() {
  const slug = 'hangzhou';
  const url = `https://www.douban.com/location/${slug}/events`;
  const r = await fetch(url, {
    headers: { 'User-Agent': UA, Referer: `https://www.douban.com/location/${slug}/` },
  });
  const html = await r.text();
  const blocks = html.split('<li class="list-entry"').slice(1);
  console.log('blocks:', blocks.length);
  for (const i of [10, 11, 13]) {
    console.log(`\n===== block ${i} =====`);
    console.log(blocks[i].slice(0, 700).replace(/\n\s*/g, '\n'));
  }
}

main().catch((e) => console.error('ERR', e && e.message));
