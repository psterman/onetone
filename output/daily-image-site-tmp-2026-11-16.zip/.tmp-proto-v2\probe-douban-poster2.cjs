/* 临时探针 9b：豆瓣 subject 页跟跳转后能不能拿到 og:image 海报 */
const https = require('node:https');
const fs = require('node:fs');
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

const s = fs.readFileSync('E:/voice-pilot/daily-image-site/tools/.tmp-proto-v2/data.js', 'utf8');
const j = JSON.parse(s.slice(s.indexOf('{'), s.lastIndexOf('}') + 1));
const soon = (j.movie.sections.find((x) => x.label === '近期即将上映') || {}).items || [];
const douban = soon.filter((i) => /douban\.com\/subject\/(\d+)/.test(i.link));

function get(url, depth) {
  return new Promise((resolve) => {
    const req = https.get(url, { headers: { 'User-Agent': UA, Referer: 'https://movie.douban.com/' } }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && depth < 6) {
        res.resume();
        get(new URL(res.headers.location, url).href, depth + 1).then(resolve);
        return;
      }
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { body += c; });
      res.on('end', () => resolve({ status: res.statusCode, body, url }));
    });
    req.on('error', (e) => resolve({ status: 0, body: '', err: e.message }));
    req.setTimeout(15000, () => { try { req.destroy(); } catch { /* ignore */ } });
  });
}

(async () => {
  let ok = 0;
  for (const it of douban.slice(0, 6)) {
    const r = await get(it.link, 0);
    const og = (r.body.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i) ||
      r.body.match(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i) || [])[1];
    if (og) ok++;
    console.log(`${it.title.padEnd(16)} HTTP ${r.status} len=${r.body.length} og=${og ? og.slice(0, 70) : '(无)'}`);
  }
  console.log(`\n命中 ${ok}/6`);
})();
