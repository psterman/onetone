﻿import https from 'node:https';
function post(q,v){
  return new Promise((res)=>{
    const body=JSON.stringify({query:q,variables:v});
    const r=https.request('https://apis.justwatch.com/graphql',{method:'POST',headers:{'Content-Type':'application/json','X-Client-Id':'justwatch','Origin':'https://www.justwatch.com','Referer':'https://www.justwatch.com/','User-Agent':'Mozilla/5.0','Content-Length':Buffer.byteLength(body)}},(resp)=>{
      let d='';resp.on('data',c=>d+=c);resp.on('end',()=>res({s:resp.statusCode,body:d}));
    });
    r.on('error',e=>res({s:0,body:'ERR '+e.message}));
    r.setTimeout(25000,()=>{r.destroy();res({s:0,body:'TIMEOUT'})});
    r.write(body); r.end();
  });
}
const JH={'Content-Type':'application/json','X-Client-Id':'justwatch','Origin':'https://www.justwatch.com','Referer':'https://www.justwatch.com/'};
// 候选字段：没被报错的 = 合法
const MOVIE_CANDS=['id','title','titleText','name','text','originalTitleText','releaseYear','releaseDate','contentRating','productionStatus','poster','image','packageOptions','seasons','episodes','ids','origins','shortDescription','description'];
const PKG_CANDS=['id','technicalName','name','title','provider','icon','slug','url','packageType','monetizationType'];
async function probe(label, q, v){
  const r=await post(q,v);
  console.log('['+label+'] status='+r.s);
  try{
    const j=JSON.parse(r.body);
    const errs=(j.errors||[]).map(e=>e.message);
    const bad=errs.filter(m=>m.startsWith('Cannot query field'));
    const other=errs.filter(m=>!m.startsWith('Cannot query field'));
    const badNames=bad.map(m=>(m.match(/field "([^"]+)"/)||[])[1]).filter(Boolean);
    console.log('   非法字段: '+JSON.stringify(badNames));
    if(other.length) console.log('   其他错误: '+JSON.stringify(other).slice(0,300));
    if(j.data) console.log('   DATA: '+JSON.stringify(j.data).slice(0,600));
  }catch(e){ console.log('   raw: '+r.body.slice(0,300)); }
  console.log('');
}
await probe('MovieOrSeason 字段',
  'query($c:Country!){ newTitles(first:2,country:$c){ edges { node { '+MOVIE_CANDS.join(' ')+' } } } }',{c:'HK'});
await probe('Package 字段',
  'query($c:Country!,$p:Platform!){ packages(country:$c,platform:$p){ '+PKG_CANDS.join(' ')+' } }',{c:'HK',p:'WEB'});
await probe('Query 顶层字段',
  'query{ '+['newTitles','searchTitles','packages','content','title','titles','episodes','popular','getAllTitles'].join(' ')+' }',{});
