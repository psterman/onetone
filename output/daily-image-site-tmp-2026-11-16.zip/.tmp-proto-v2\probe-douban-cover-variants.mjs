// 探针：豆瓣图床能不能直接出「小尺寸 + WebP」，这样封面就不用过 ffmpeg。
// 关注四件事：状态码 / Content-Type / 字节数 / 尺寸。
import fs from 'node:fs/promises';

const ORIG = 'https://img2.doubanio.com/pview/event_poster/median/public/cf2eb13b2ca95ce.jpg';
const BASE = 'https://img2.doubanio.com/pview/event_poster';

const variants = [
  ['原样 median', ORIG],
  ['large', `${BASE}/large/public/cf2eb13b2ca95ce.jpg`],
  ['small', `${BASE}/small/public/cf2eb13b2ca95ce.jpg`],
  ['?fm=webp', `${ORIG}?fm=webp`],
  ['webp 路径', `${BASE}/median/webp/public/cf2eb13b2ca95ce.jpg`],
  ['s_ratio_poster', 'https://img2.doubanio.com/view/photo/s_ratio_poster/public/cf2eb13b2ca95ce.jpg'],
];

async function probe(label, url, withReferer) {
  const headers = { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' };
  if (withReferer) headers.Referer = 'https://www.douban.com/';
  try {
    const res = await fetch(url, { headers, redirect: 'follow' });
    const buf = Buffer.from(await res.arrayBuffer());
    const w = await pngSize(buf);
    console.log(
      `${label.padEnd(16)} referer=${withReferer ? 'Y' : 'n'}  ${res.status}  ` +
        `${(res.headers.get('content-type') || '-').padEnd(12)}  ${String(buf.length).padStart(7)}B  ${w}`,
    );
  } catch (e) {
    console.log(`${label.padEnd(16)} referer=${withReferer ? 'Y' : 'n'}  ERR ${e.message}`);
  }
}

// 只解 PNG/JPEG 的宽高，够用就行
async function pngSize(buf) {
  if (buf.length < 24) return '?';
  if (buf[0] === 0xff && buf[1] === 0xd8) {
    let i = 2;
    while (i < buf.length - 9) {
      if (buf[i] !== 0xff) { i++; continue; }
      const m = buf[i + 1];
      const len = buf.readUInt16BE(i + 2);
      if (m >= 0xc0 && m <= 0xcf && m !== 0xc4 && m !== 0xc8 && m !== 0xcc) {
        return `${buf.readUInt16BE(i + 7)}x${buf.readUInt16BE(i + 5)} jpeg`;
      }
      i += 2 + len;
    }
    return 'jpeg?';
  }
  if (buf.toString('ascii', 1, 4) === 'PNG') {
    return `${buf.readUInt32BE(16)}x${buf.readUInt32BE(20)} png`;
  }
  if (buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP') {
    return 'webp';
  }
  return '?';
}

await fs.writeFile(new URL('./.probe-cover-variants.log', import.meta.url), '');
for (const [label, url] of variants) {
  await probe(label, url, true);
  await probe(label, url, false);
}
